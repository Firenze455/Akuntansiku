<?php
require_once __DIR__ . '/includes/config.php';
checkLogin();
if (isAdmin()) {
    $_SESSION['error'] = 'Admin tidak memiliki akses ke halaman ini.';
    header('Location: manage_users.php');
    exit();
}

$conn = getDBConnection();

$id = (int)($_GET['id'] ?? 0);

if ($id <= 0) {
    $_SESSION['error'] = 'ID hutang tidak valid!';
    header('Location: payables.php');
    exit();
}

// Get payable data
$stmt = $conn->prepare("SELECT p.*, u.full_name as creator_name, u2.full_name as approver_name, s.address AS supplier_address
                        FROM payables p 
                        LEFT JOIN users u ON p.created_by = u.id
                        LEFT JOIN users u2 ON p.approved_by = u2.id
                        LEFT JOIN suppliers s ON p.supplier_id = s.id
                        WHERE p.id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$payable = $stmt->get_result()->fetch_assoc();

if (!$payable) {
    $_SESSION['error'] = 'Hutang tidak ditemukan!';
    header('Location: payables.php');
    exit();
}

// Get payment history (ascending)
$payments = $conn->query("SELECT pp.*, u.full_name as paid_by_name 
                          FROM payable_payments pp
                          LEFT JOIN users u ON pp.created_by = u.id
                          WHERE pp.payable_id = $id
                          ORDER BY pp.payment_date ASC, pp.created_at ASC");

// Hitung total dibayar dan sisa hutang
$paidRow = $conn->query("SELECT COALESCE(SUM(amount),0) AS paid FROM payable_payments WHERE payable_id = $id")->fetch_assoc();
$total_paid = (float)($paidRow['paid'] ?? 0);
$outstanding = max(0, (float)$payable['total_amount'] - $total_paid);

// Helper: nama bulan Indonesia
function namaBulanIndo($date) {
    $months = ['','Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
    $m = (int)date('n', strtotime($date));
    return $months[$m];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Hutang - <?php echo htmlspecialchars($payable['ref_code']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <?php include __DIR__ . '/includes/header.php'; ?>
    
    <div class="container mx-auto px-4 py-6">
        <div class="mb-6">
            <a href="payables.php" class="text-blue-600 hover:text-blue-800 flex items-center gap-2 mb-4">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
                </svg>
                Kembali ke Daftar Hutang
            </a>
            <h2 class="text-2xl font-bold text-gray-800">Kartu Hutang</h2>
            <p class="text-gray-600">Detail dan riwayat pembayaran hutang</p>
        </div>

        <!-- KARTU HUTANG -->
        <div class="bg-white rounded-lg shadow-lg p-6">
            <h3 class="text-center text-xl font-bold mb-4">KARTU HUTANG</h3>
            <table class="w-full text-sm border mb-4">
                <tbody>
                    <tr>
                        <td class="border p-2 w-1/4">Nomor Akun</td>
                        <td class="border p-2 w-1/4 font-semibold">2-2100</td>
                        <td class="border p-2 w-1/4">Syarat</td>
                        <td class="border p-2 w-1/4 font-semibold"><?php echo !empty($payable['notes']) ? htmlspecialchars($payable['notes']) : '-'; ?></td>
                    </tr>
                    <tr>
                        <td class="border p-2">Nama</td>
                        <td class="border p-2 font-semibold"><?php echo htmlspecialchars($payable['supplier_name']); ?></td>
                        <td class="border p-2">Batas Kredit</td>
                        <td class="border p-2 font-semibold">-</td>
                    </tr>
                    <tr>
                        <td class="border p-2">Alamat</td>
                        <td class="border p-2 font-semibold"><?php echo !empty($payable['supplier_address']) ? htmlspecialchars($payable['supplier_address']) : '-'; ?></td>
                        <td class="border p-2">Tanggal Jatuh Tempo</td>
                        <td class="border p-2 font-semibold"><?php echo formatTanggal($payable['due_date']); ?></td>
                    </tr>
                    <tr>
                        <td class="border p-2">Jumlah Hutang</td>
                        <td class="border p-2 font-semibold"><?php echo formatRupiah($payable['total_amount']); ?></td>
                        <td class="border p-2">Sisa Hutang</td>
                        <td class="border p-2 font-semibold"><?php echo formatRupiah($outstanding); ?></td>
                    </tr>
                </tbody>
            </table>

            <?php
            // Ledger: faktur (kredit) lalu pembayaran (debet)
            $entries = [];
            $entries[] = [
                'date' => date('Y-m-d', strtotime($payable['created_at'] ?? $payable['approved_at'] ?? $payable['due_date'])),
                'desc' => 'Faktur ' . $payable['ref_code'],
                'fol'  => $payable['ref_code'],
                'debit'=> 0.0,
                'credit'=> (float)$payable['total_amount']
            ];
            while ($p = $payments->fetch_assoc()) {
                $desc = 'Pembayaran hutang (' . ucfirst($p['payment_method']) . ')';
                if (!empty($p['notes'])) $desc .= ' - ' . $p['notes'];
                $entries[] = [
                    'date' => $p['payment_date'],
                    'desc' => $desc,
                    'fol'  => 'PMT',
                    'debit'=> (float)$p['amount'],
                    'credit'=> 0.0
                ];
            }
            $running = 0.0;
            $current_month = '';
            ?>

            <div class="overflow-x-auto">
                <table class="w-full text-sm border">
                    <thead>
                        <tr class="bg-gray-50">
                            <th class="border px-2 py-2 w-16">Tgl.</th>
                            <th class="border px-2 py-2">Keterangan</th>
                            <th class="border px-2 py-2 w-20">Fol</th>
                            <th class="border px-2 py-2 w-28 text-right">Mutasi Debet</th>
                            <th class="border px-2 py-2 w-28 text-right">Mutasi Kredit</th>
                            <th class="border px-2 py-2 w-28 text-right">Saldo Debet</th>
                            <th class="border px-2 py-2 w-28 text-right">Saldo Kredit</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($entries as $e): 
                            $month = namaBulanIndo($e['date']);
                            if ($month !== $current_month): $current_month = $month; ?>
                                <tr>
                                    <td class="border px-2 py-1 font-semibold" colspan="7"><?php echo $current_month; ?></td>
                                </tr>
                            <?php endif;
                            $running += ($e['debit'] - $e['credit']);
                            $saldo_debet = $running > 0 ? $running : 0;
                            $saldo_kredit = $running < 0 ? abs($running) : 0;
                        ?>
                        <tr>
                            <td class="border px-2 py-1"><?php echo date('j', strtotime($e['date'])); ?></td>
                            <td class="border px-2 py-1"><?php echo htmlspecialchars($e['desc']); ?></td>
                            <td class="border px-2 py-1 text-center"><?php echo htmlspecialchars($e['fol']); ?></td>
                            <td class="border px-2 py-1 text-right"><?php echo $e['debit'] > 0 ? formatRupiah($e['debit']) : '--'; ?></td>
                            <td class="border px-2 py-1 text-right"><?php echo $e['credit'] > 0 ? formatRupiah($e['credit']) : '--'; ?></td>
                            <td class="border px-2 py-1 text-right"><?php echo $saldo_debet > 0 ? formatRupiah($saldo_debet) : '--'; ?></td>
                            <td class="border px-2 py-1 text-right"><?php echo $saldo_kredit > 0 ? formatRupiah($saldo_kredit) : '--'; ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
<?php $conn->close(); ?>
