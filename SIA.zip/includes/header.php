<nav class="bg-white shadow-lg fixed top-0 left-0 right-0 z-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16">
            <div class="flex items-center">
                <div class="flex-shrink-0 flex items-center">
                    <div class="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center mr-3">
                        <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z"></path>
                        </svg>
                    </div>
                    <span class="text-xl font-bold text-gray-800">SIA</span>
                </div>
                <div class="hidden md:ml-10 md:flex md:space-x-8">
                    <?php
                    $current_page = basename($_SERVER['PHP_SELF']);
                    $active_class = 'border-blue-500 text-gray-900';
                    $inactive_class = 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700';
                    $link_base_class = 'inline-flex items-center px-1 py-2 border-b-2 text-sm font-medium';
                    ?>
                    
                    <?php if (isAdmin()): ?>
                        <!-- Admin Menu -->
                        <a href="manage_users.php" class="<?php echo $current_page == 'manage_users.php' ? $active_class : $inactive_class; ?> <?php echo $link_base_class; ?>">
                            Kelola User
                        </a>
                    
                    <?php else: ?>
                        <!-- Supervisor, Staff, Head Menu -->
                        
                        <?php if (checkPermission('dashboard', 'view')): ?>
                        <a href="index.php" class="<?php echo $current_page == 'index.php' ? $active_class : $inactive_class; ?> <?php echo $link_base_class; ?>">
                            Dashboard
                        </a>
                        <?php endif; ?>
                        
                        <?php 
                        // Dropdown Keuangan dan Transaksi
                        $finance_pages = ['cashflow.php','receivables.php','receivable_history.php','payables.php','payable_history.php','assets.php','accounts.php'];
                        $finance_active = in_array($current_page, $finance_pages);
                        $hasFinance = checkPermission('cashflow', 'view') 
                                      || checkPermission('receivables', 'view') 
                                      || checkPermission('payables', 'view') 
                                      || checkPermission('assets', 'view');
                        ?>
                        <?php if ($hasFinance): ?>
                        <div class="relative group flex items-center">
                            <a href="#" class="<?php echo $finance_active ? $active_class : $inactive_class; ?> <?php echo $link_base_class; ?>">
                                Keuangan dan Transaksi
                                <svg class="w-4 h-4 ml-1 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                                </svg>
                            </a>
                            <div class="absolute left-0 top-full pt-2 w-64 bg-white shadow-lg rounded-md border border-gray-200 z-40 opacity-0 pointer-events-none group-hover:opacity-100 group-hover:pointer-events-auto group-focus-within:opacity-100 group-focus-within:pointer-events-auto transition">
                                <?php if (checkPermission('cashflow', 'view')): ?>
                                <a href="cashflow.php" class="block px-4 py-2 text-sm <?php echo $current_page=='cashflow.php' ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-50'; ?>">Cashflow</a>
                                <?php endif; ?>
                                <?php if (checkPermission('receivables', 'view')): ?>
                                <a href="receivables.php" class="block px-4 py-2 text-sm <?php echo in_array($current_page, ['receivables.php','receivable_history.php']) ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-50'; ?>">Piutang</a>
                                <?php endif; ?>
                                <?php if (checkPermission('payables', 'view')): ?>
                                <a href="payables.php" class="block px-4 py-2 text-sm <?php echo in_array($current_page, ['payables.php','payable_history.php']) ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-50'; ?>">Hutang</a>
                                <?php endif; ?>
                                <?php if (checkPermission('assets', 'view')): ?>
                                <a href="assets.php" class="block px-4 py-2 text-sm <?php echo $current_page=='assets.php' ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-50'; ?>">Aset</a>
                                <?php endif; ?>
                                <?php if (isSupervisor() || isAdmin()): ?>
                                <a href="accounts.php" class="block px-4 py-2 text-sm <?php echo $current_page=='accounts.php' ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-50'; ?>">Master Akun</a>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php 
                        // Dropdown Laporan
                        $report_pages = ['journal.php', 'ledger.php', 'trial_balance.php']; // Hapus 'reports.php'
                        $report_active = in_array($current_page, $report_pages);
                        ?>
                        <?php if (checkPermission('journal', 'view')): ?>
                        <div class="relative group flex items-center">
                            <a href="#" onclick="return false;" class="<?php echo $report_active ? $active_class : $inactive_class; ?> <?php echo $link_base_class; ?>">
                                Laporan
                                <svg class="w-4 h-4 ml-1 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                                </svg>
                            </a>
                            <div class="absolute left-0 top-full pt-2 w-72 bg-white shadow-lg rounded-md border border-gray-200 z-40 opacity-0 pointer-events-none group-hover:opacity-100 group-hover:pointer-events-auto group-focus-within:opacity-100 group-focus-within:pointer-events-auto transition">
                                <a href="journal.php" class="block px-4 py-2 text-sm <?php echo $current_page=='journal.php' ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-50'; ?>">Jurnal Umum</a>
                                <a href="ledger.php" class="block px-4 py-2 text-sm <?php echo $current_page=='ledger.php' ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-50'; ?>">Buku Besar</a>
                                <a href="trial_balance.php" class="block px-4 py-2 text-sm <?php echo $current_page=='trial_balance.php' ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-50'; ?>">Neraca Saldo</a>
                                <div class="px-4 py-2 text-sm text-gray-400 cursor-not-allowed">Jurnal Penyesuaian (Segera)</div>
                                <div class="px-4 py-2 text-sm text-gray-400 cursor-not-allowed">BBSP (Segera)</div>
                                <div class="px-4 py-2 text-sm text-gray-400 cursor-not-allowed">NSSP (Segera)</div>
                                <div class="px-4 py-2 text-sm text-gray-400 cursor-not-allowed">Laporan Laba Rugi (Segera)</div>
                                <div class="px-4 py-2 text-sm text-gray-400 cursor-not-allowed">Laporan Ekuitas (Segera)</div>
                                <div class="px-4 py-2 text-sm text-gray-400 cursor-not-allowed">Neraca Akhir (Segera)</div>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php 
                        // Dropdown External (selalu ada)
                        $external_pages = ['customers.php','suppliers.php'];
                        $external_active = in_array($current_page, $external_pages);
                        ?>
                        <div class="relative group flex items-center">
                            <a href="#" class="<?php echo $external_active ? $active_class : $inactive_class; ?> <?php echo $link_base_class; ?>">
                                External
                                <svg class="w-4 h-4 ml-1 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                                </svg>
                            </a>
                            <div class="absolute left-0 top-full pt-2 w-56 bg-white shadow-lg rounded-md border border-gray-200 z-40 opacity-0 pointer-events-none group-hover:opacity-100 group-hover:pointer-events-auto group-focus-within:opacity-100 group-focus-within:pointer-events-auto transition">
                                <a href="customers.php" class="block px-4 py-2 text-sm <?php echo $current_page=='customers.php' ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-50'; ?>">Customer</a>
                                <a href="suppliers.php" class="block px-4 py-2 text-sm <?php echo $current_page=='suppliers.php' ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-50'; ?>">Supplier</a>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="flex items-center">
                <div class="flex items-center space-x-4">
                    <span class="text-sm text-gray-700 hidden md:block">
                        <span class="font-medium"><?php echo htmlspecialchars($_SESSION['full_name']); ?></span>
                        <?php
                        $role_badges = [
                            'admin' => '<span class="ml-2 px-2 py-0.5 text-xs font-semibold rounded-full bg-purple-100 text-purple-800">Admin</span>',
                            'supervisor' => '<span class="ml-2 px-2 py-0.5 text-xs font-semibold rounded-full bg-blue-100 text-blue-800">Supervisor</span>',
                            'staff' => '<span class="ml-2 px-2 py-0.5 text-xs font-semibold rounded-full bg-green-100 text-green-800">Staff</span>',
                            'head' => '<span class="ml-2 px-2 py-0.5 text-xs font-semibold rounded-full bg-yellow-100 text-yellow-800">Head</span>'
                        ];
                        echo $role_badges[$_SESSION['role']] ?? '';
                        ?>
                    </span>
                    <a href="logout.php" 
                       onclick="return confirm('Yakin ingin logout?')"
                       class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 transition-colors">
                        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path>
                        </svg>
                        Logout
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Mobile menu -->
    <div class="md:hidden border-t border-gray-200">
        <div class="pt-2 pb-3 space-y-1">
            <?php if (isAdmin()): ?>
                <!-- Admin Mobile Menu -->
                <a href="manage_users.php" class="<?php echo $current_page == 'manage_users.php' ? 'bg-blue-50 border-blue-500 text-blue-700' : 'border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800'; ?> block pl-3 pr-4 py-2 border-l-4 text-base font-medium">
                    Kelola User
                </a>
            <?php else: ?>
                <!-- Other Roles Mobile Menu -->
                
                <?php if (checkPermission('dashboard', 'view')): ?>
                <a href="index.php" class="<?php echo $current_page == 'index.php' ? 'bg-blue-50 border-blue-500 text-blue-700' : 'border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800'; ?> block pl-3 pr-4 py-2 border-l-4 text-base font-medium">
                    Dashboard
                </a>
                <?php endif; ?>

                <?php 
                $finance_pages = ['cashflow.php','receivables.php','receivable_history.php','payables.php','payable_history.php','assets.php','accounts.php'];
                $finance_active = in_array($current_page, $finance_pages);
                $hasFinance = checkPermission('cashflow', 'view') 
                              || checkPermission('receivables', 'view') 
                              || checkPermission('payables', 'view') 
                              || checkPermission('assets', 'view');
                ?>
                <?php if ($hasFinance): ?>
                <details class="border-l-4 block pl-3 pr-4 py-2 text-base font-medium <?php echo $finance_active ? 'bg-blue-50 border-blue-500 text-blue-700' : 'border-transparent text-gray-700'; ?>" <?php echo $finance_active ? 'open' : ''; ?>>
                    <summary class="cursor-pointer">Keuangan dan Transaksi</summary>
                    <div class="mt-2 ml-2 space-y-1">
                        <?php if (checkPermission('cashflow', 'view')): ?>
                        <a href="cashflow.php" class="block pl-3 pr-4 py-2 text-sm <?php echo $current_page=='cashflow.php' ? 'bg-blue-100 text-blue-800' : 'text-gray-700 hover:bg-gray-50'; ?>">Cashflow</a>
                        <?php endif; ?>
                        <?php if (checkPermission('receivables', 'view')): ?>
                        <a href="receivables.php" class="block pl-3 pr-4 py-2 text-sm <?php echo in_array($current_page,['receivables.php','receivable_history.php']) ? 'bg-blue-100 text-blue-800' : 'text-gray-700 hover:bg-gray-50'; ?>">Piutang</a>
                        <?php endif; ?>
                        <?php if (checkPermission('payables', 'view')): ?>
                        <a href="payables.php" class="block pl-3 pr-4 py-2 text-sm <?php echo in_array($current_page,['payables.php','payable_history.php']) ? 'bg-blue-100 text-blue-800' : 'text-gray-700 hover:bg-gray-50'; ?>">Hutang</a>
                        <?php endif; ?>
                        <?php if (checkPermission('assets', 'view')): ?>
                        <a href="assets.php" class="block pl-3 pr-4 py-2 text-sm <?php echo $current_page=='assets.php' ? 'bg-blue-100 text-blue-800' : 'text-gray-700 hover:bg-gray-50'; ?>">Aset</a>
                        <?php endif; ?>
                    </div>
                    <?php if (isSupervisor() || isAdmin()): ?>
                    <a href="accounts.php" class="block pl-3 pr-4 py-2 text-sm <?php echo $current_page=='accounts.php' ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-50'; ?>">Master Akun</a>
                    <?php endif; ?>
                </details>
                <?php endif; ?>

                <?php 
                $report_pages = ['journal.php', 'ledger.php', 'trial_balance.php']; // Hapus 'reports.php'
                $report_active = in_array($current_page, $report_pages);
                ?>
                <?php if (checkPermission('journal', 'view')): ?>
                <details class="border-l-4 block pl-3 pr-4 py-2 text-base font-medium <?php echo $report_active ? 'bg-blue-50 border-blue-500 text-blue-700' : 'border-transparent text-gray-700'; ?>" <?php echo $report_active ? 'open' : ''; ?>>
                    <summary class="cursor-pointer">Laporan</summary>
                    <div class="mt-2 ml-2 space-y-1">
                        <a href="journal.php" class="block pl-3 pr-4 py-2 text-sm <?php echo $current_page=='journal.php' ? 'bg-blue-100 text-blue-800' : 'text-gray-700 hover:bg-gray-50'; ?>">Jurnal Umum</a>
                        <a href="ledger.php" class="block pl-3 pr-4 py-2 text-sm <?php echo $current_page=='ledger.php' ? 'bg-blue-100 text-blue-800' : 'text-gray-700 hover:bg-gray-50'; ?>">Buku Besar</a>
                        <span class="block pl-3 pr-4 py-2 text-sm text-gray-400">Neraca Saldo</span>
                        <span class="block pl-3 pr-4 py-2 text-sm text-gray-400">Jurnal Penyesuaian (Segera)</span>
                        <span class="block pl-3 pr-4 py-2 text-sm text-gray-400">BBSP (Segera)</span>
                        <span class="block pl-3 pr-4 py-2 text-sm text-gray-400">NSSP (Segera)</span>
                        <span class="block pl-3 pr-4 py-2 text-sm text-gray-400">Laporan Laba Rugi (Segera)</span>
                        <span class="block pl-3 pr-4 py-2 text-sm text-gray-400">Laporan Ekuitas (Segera)</span>
                        <span class="block pl-3 pr-4 py-2 text-sm text-gray-400">Neraca Akhir (Segera)</span>
                    </div>
                </details>
                <?php endif; ?>

                <?php 
                $external_pages = ['customers.php','suppliers.php'];
                $external_active = in_array($current_page, $external_pages);
                ?>
                <details class="border-l-4 block pl-3 pr-4 py-2 text-base font-medium <?php echo $external_active ? 'bg-blue-50 border-blue-500 text-blue-700' : 'border-transparent text-gray-700'; ?>" <?php echo $external_active ? 'open' : ''; ?>>
                    <summary class="cursor-pointer">External</summary>
                    <div class="mt-2 ml-2 space-y-1">
                        <a href="customers.php" class="block pl-3 pr-4 py-2 text-sm <?php echo $current_page=='customers.php' ? 'bg-blue-100 text-blue-800' : 'text-gray-700 hover:bg-gray-50'; ?>">Customer</a>
                        <a href="suppliers.php" class="block pl-3 pr-4 py-2 text-sm <?php echo $current_page=='suppliers.php' ? 'bg-blue-100 text-blue-800' : 'text-gray-700 hover:bg-gray-50'; ?>">Supplier</a>
                    </div>
                </details>
            <?php endif; ?>
        </div>
        
        <div class="pt-4 pb-3 border-t border-gray-200">
            <div class="flex items-center px-4">
                <div class="flex-shrink-0">
                    <div class="h-10 w-10 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold">
                        <?php echo strtoupper(substr($_SESSION['full_name'], 0, 1)); ?>
                    </div>
                </div>
                <div class="ml-3">
                    <div class="text-base font-medium text-gray-800"><?php echo htmlspecialchars($_SESSION['full_name']); ?></div>
                    <div class="text-sm font-medium text-gray-500">
                        <?php echo getRoleDisplayName($_SESSION['role']); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</nav>

<!-- SPACER: Menambahkan ruang agar konten tidak tertutup header -->
<div class="h-16"></div>