<?php
// Konfigurasi Database (standar MySQL)
// Gunakan environment vars jika tersedia, atau fallback ke default lokal
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_PORT', (int)(getenv('DB_PORT') ?: 3306));
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');
define('DB_NAME', getenv('DB_NAME') ?: 'sia');
define('DB_CHARSET', getenv('DB_CHARSET') ?: 'utf8mb4');

// Koneksi ke database
function getDBConnection() {
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT);

    // Set charset standar
    $conn->set_charset(DB_CHARSET);
    return $conn;
}

// Fungsi untuk format currency
function formatRupiah($angka) {
    return 'Rp ' . number_format($angka, 0, ',', '.');
}

// Fungsi untuk format tanggal
function formatTanggal($tanggal) {
    $bulan = [
        1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
        'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
    ];
    
    $split = explode('-', $tanggal);
    return $split[2] . ' ' . $bulan[(int)$split[1]] . ' ' . $split[0];
}

// Start session
session_start();

// Cek login
function checkLogin() {
    if (!isset($_SESSION['user_id'])) {
        header('Location: login.php');
        exit();
    }
}

// Cek apakah user adalah admin
function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

// Cek login khusus admin
function checkAdminLogin() {
    checkLogin();
    if (!isAdmin()) {
        header('Location: index.php');
        exit();
    }
}

// Check permission untuk module tertentu
function checkPermission($module, $action = 'view') {
    if (!isset($_SESSION['role'])) {
        return false;
    }
    
    $conn = getDBConnection();
    $role = $_SESSION['role'];
    
    $column_map = [
        'view' => 'can_view',
        'create' => 'can_create',
        'edit' => 'can_edit',
        'delete' => 'can_delete',
        'approve' => 'can_approve'
    ];
    
    $column = $column_map[$action] ?? 'can_view';
    
    $stmt = $conn->prepare("SELECT $column FROM permissions WHERE role = ? AND module = ?");
    $stmt->bind_param("ss", $role, $module);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        return (bool)$row[$column];
    }
    
    $conn->close();
    return false;
}

// Redirect jika tidak ada permission
function requirePermission($module, $action = 'view') {
    if (!checkPermission($module, $action)) {
        $_SESSION['error'] = 'Anda tidak memiliki akses ke halaman ini!';
        header('Location: index.php');
        exit();
    }
}

// Get role display name
function getRoleDisplayName($role) {
    $names = [
        'admin' => 'Administrator',
        'supervisor' => 'Supervisor',
        'staff' => 'Staff',
        'head' => 'Head/Manager'
    ];
    return $names[$role] ?? $role;
}

// Check if user is supervisor
function isSupervisor() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'supervisor';
}

// Check if user is staff
function isStaff() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'staff';
}

// Check if user is head
function isHead() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'head';
}

function formatAccountCodeDisplay($code) {
    if (preg_match('/^[1-5][0-9]{3}$/', $code)) {
        return substr($code, 0, 1) . '-' . $code;
    }
    return $code;
}
?>
