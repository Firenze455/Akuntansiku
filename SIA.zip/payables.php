<?php
require_once __DIR__ . '/includes/config.php';
checkLogin();
if (isAdmin()) {
    $_SESSION['error'] = 'Admin tidak memiliki akses ke halaman ini.';
    header('Location: manage_users.php');
    exit();
}

$conn = getDBConnection();
$success = isset($_SESSION['success']) ? $_SESSION['success'] : '';
$error = isset($_SESSION['error']) ? $_SESSION['error'] : '';
unset($_SESSION['success'], $_SESSION['error']);

// Generate ref code
function generatePayableRefCode($conn, $prefix = 'PAY') {
    $date = date('Ymd');
    $stmt = $conn->prepare("SELECT ref_code FROM payables WHERE ref_code LIKE ? ORDER BY ref_code DESC LIMIT 1");
    $pattern = $prefix . $date . '%';
    $stmt->bind_param("s", $pattern);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $last_code = $result->fetch_assoc()['ref_code'];
        $last_num = intval(substr($last_code, -4));
        $new_num = str_pad($last_num + 1, 4, '0', STR_PAD_LEFT);
    } else {
        $new_num = '0001';
    }
    
    return $prefix . $date . $new_num;
}

// Handle form submission - Add Payable
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_payable'])) {
    $supplier_name = trim($_POST['supplier_name']);
    $description = trim($_POST['description']);
    $total_amount = floatval($_POST['total_amount']);
    $due_date = $_POST['due_date'];
    $user_id = $_SESSION['user_id'];
    
    $ref_code = generatePayableRefCode($conn);
    $status = isSupervisor() ? 'pending' : 'pending';
    
    $stmt = $conn->prepare("INSERT INTO payables (ref_code, supplier_name, description, total_amount, remaining_amount, due_date, status, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssddssi", $ref_code, $supplier_name, $description, $total_amount, $total_amount, $due_date, $status, $user_id);
    
    if ($stmt->execute()) {
        $payable_id = $stmt->insert_id;
        
        // Auto-approve if supervisor
        if (isSupervisor()) {
            $stmt2 = $conn->prepare("UPDATE payables SET approved_by = ?, approved_at = NOW() WHERE id = ?");
            $stmt2->bind_param("ii", $user_id, $payable_id);
            $stmt2->execute();
            
            // Create journal entry
            $journal_desc = "Hutang dari " . $supplier_name . " - " . $description;
            $stmt3 = $conn->prepare("INSERT INTO general_journal (journal_date, description, reference_id, reference_type) VALUES (CURDATE(), ?, ?, 'payable')");
            $stmt3->bind_param("si", $journal_desc, $payable_id);
            $stmt3->execute();
            $journal_id = $stmt3->insert_id;
            
            // Debit: Hutang Usaha
            $stmt4 = $conn->prepare("INSERT INTO journal_entries (journal_id, account_code, account_name, debit, credit) VALUES (?, '2-2100', 'Hutang Usaha', ?, 0)");
            $stmt4->bind_param("id", $journal_id, $total_amount);
            $stmt4->execute();
            
            // Credit: Beban Operasional
            $stmt4 = $conn->prepare("INSERT INTO journal_entries (journal_id, account_code, account_name, debit, credit) VALUES (?, '5-5100', 'Beban Operasional', 0, ?)");
            $stmt4->bind_param("id", $journal_id, $total_amount);
            $stmt4->execute();
        }
        
        $success = 'Hutang berhasil ditambahkan! Ref: ' . $ref_code;
    } else {
        $error = 'Gagal menambahkan hutang!';
    }
}

// Get filter
$filter_status = $_GET['status'] ?? '';
$filter_supplier = $_GET['supplier'] ?? '';

// Build query - FIXED: Only show approved payables for non-supervisors
$query = "SELECT r.*, u.full_name as creator_name 
          FROM payables r 
          LEFT JOIN users u ON r.created_by = u.id 
          WHERE 1=1";

// Only supervisor can see unapproved payables
if (!isSupervisor()) {
    $query .= " AND r.approved_at IS NOT NULL";
}

$params = [];
$types = "";

if (!empty($filter_status)) {
    $query .= " AND r.status = ?";
    $params[] = $filter_status;
    $types .= "s";
}

if (!empty($filter_supplier)) {
    $query .= " AND r.supplier_name LIKE ?";
    $params[] = '%' . $filter_supplier . '%';
    $types .= "s";
}

$query .= " ORDER BY r.due_date ASC, r.created_at DESC";

if (!empty($params)) {
    $stmt = $conn->prepare($query);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $payables = $stmt->get_result();
} else {
    $payables = $conn->query($query);
}

// Update overdue status
$conn->query("UPDATE payables SET status = 'overdue' WHERE status IN ('pending', 'partial') AND due_date < CURDATE()");

// Count pending for supervisor
$pending_count = 0;
if (isSupervisor()) {
    $result = $conn->query("SELECT COUNT(*) as count FROM payables WHERE approved_at IS NULL");
    $pending_count = $result->fetch_assoc()['count'];
}

// Summary - FIXED: Calculate paid from total-remaining, only count approved
$summary_query = "SELECT 
    COALESCE(SUM(total_amount), 0) as total,
    COALESCE(SUM(total_amount - remaining_amount), 0) as paid,
    COALESCE(SUM(remaining_amount), 0) as remaining,
    COUNT(CASE WHEN status = 'overdue' THEN 1 END) as overdue_count
    FROM payables WHERE status != 'lunas'";

// Only count approved for non-supervisors
if (!isSupervisor()) {
    $summary_query .= " AND approved_at IS NOT NULL";
}

$summary_result = $conn->query($summary_query);

$summary = $summary_result ? $summary_result->fetch_assoc() : [
    'total' => 0,
    'paid' => 0,
    'remaining' => 0,
    'overdue_count' => 0
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hutang - Sistem Informasi Akuntansi</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">

    <?php include __DIR__ . '/includes/header.php'; ?>

<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-6">
    <!-- Header Section -->
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 class="text-3xl font-bold text-gray-800">Manajemen Hutang</h1>
            <p class="text-gray-600 mt-1">Kelola hutang usaha perusahaan</p>
        </div>
        <?php if (checkPermission('payables', 'create')): ?>
            <button onclick="toggleInputForm()" 
                    class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium shadow-lg">
                + Tambah Hutang Baru
            </button>
        <?php endif; ?>
    </div>

    <!-- Alert Messages -->
    <?php if ($success): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6 rounded" role="alert">
            <p class="font-medium">✓ Berhasil!</p>
            <p><?php echo $success; ?></p>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded" role="alert">
            <p class="font-medium">✕ Error!</p>
            <p><?php echo $error; ?></p>
        </div>
    <?php endif; ?>

    <!-- Pending Approval Badge for Supervisor -->
    <?php if (isSupervisor() && $pending_count > 0): ?>
        <div class="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 mb-6 rounded">
            <p class="font-medium">⚠️ Perlu Persetujuan</p>
            <p>Ada <?php echo $pending_count; ?> hutang yang menunggu persetujuan Anda.</p>
        </div>
    <?php endif; ?>

    <!-- Summary Cards -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div class="bg-white rounded-lg shadow p-6">
            <div class="flex items-center">
                <div class="flex-shrink-0 bg-blue-100 rounded-md p-3">
                    <svg class="h-6 w-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                </div>
                <div class="ml-4">
                    <p class="text-sm text-gray-600 font-medium">Total Hutang</p>
                    <p class="text-xl font-bold text-gray-900"><?php echo formatRupiah($summary['total']); ?></p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow p-6">
            <div class="flex items-center">
                <div class="flex-shrink-0 bg-green-100 rounded-md p-3">
                    <svg class="h-6 w-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                </div>
                <div class="ml-4">
                    <p class="text-sm text-gray-600 font-medium">Terbayar</p>
                    <p class="text-xl font-bold text-green-600"><?php echo formatRupiah($summary['paid']); ?></p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow p-6">
            <div class="flex items-center">
                <div class="flex-shrink-0 bg-orange-100 rounded-md p-3">
                    <svg class="h-6 w-6 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                </div>
                <div class="ml-4">
                    <p class="text-sm text-gray-600 font-medium">Belum Dibayar</p>
                    <p class="text-xl font-bold text-orange-600"><?php echo formatRupiah($summary['remaining']); ?></p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow p-6">
            <div class="flex items-center">
                <div class="flex-shrink-0 bg-red-100 rounded-md p-3">
                    <svg class="h-6 w-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>
                    </svg>
                </div>
                <div class="ml-4">
                    <p class="text-sm text-gray-600 font-medium">Overdue</p>
                    <p class="text-xl font-bold text-red-600"><?php echo $summary['overdue_count']; ?> Hutang</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Input Form (Hidden by default) -->
    <?php if (checkPermission('payables', 'create')): ?>
    <div id="inputForm" class="hidden bg-white rounded-lg shadow-lg p-6 mb-8">
        <h2 class="text-xl font-semibold text-gray-800 mb-4">Tambah Hutang Baru</h2>
        <form method="POST" action="">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Nama Supplier <span class="text-red-500">*</span></label>
                    <input type="text" name="supplier_name" required
                           class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Total Nominal <span class="text-red-500">*</span></label>
                    <input type="number" name="total_amount" required step="1" min="0"
                           class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Tanggal Jatuh Tempo <span class="text-red-500">*</span></label>
                    <input type="date" name="due_date" required
                           class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                </div>
                
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Deskripsi <span class="text-red-500">*</span></label>
                    <textarea name="description" required rows="3"
                              class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"></textarea>
                </div>
            </div>
            
            <div class="mt-4 flex justify-end gap-2">
                <button type="button" onclick="toggleInputForm()" 
                        class="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300">
                    Batal
                </button>
                <button type="submit" name="add_payable" 
                        class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
                    Simpan Hutang
                </button>
            </div>
        </form>
    </div>
    <?php endif; ?>
    
    <!-- Payables List with Filters -->
    <div class="bg-white rounded-lg shadow">
        <!-- Filter Bar -->
        <div class="p-4 bg-gray-50 border-b border-gray-200">
            <form method="GET" class="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div>
                    <input type="text" name="supplier" value="<?php echo htmlspecialchars($filter_supplier); ?>" placeholder="Cari supplier..."
                           class="w-full px-3 py-2 text-sm border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500">
                </div>
                
                <div>
                    <select name="status" class="w-full px-3 py-2 text-sm border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500">
                        <option value="">Semua Status</option>
                        <option value="pending" <?php echo $filter_status === 'pending' ? 'selected' : ''; ?>>Pending</option>
                        <option value="partial" <?php echo $filter_status === 'partial' ? 'selected' : ''; ?>>Partial</option>
                        <option value="paid" <?php echo $filter_status === 'paid' ? 'selected' : ''; ?>>Lunas</option>
                        <option value="overdue" <?php echo $filter_status === 'overdue' ? 'selected' : ''; ?>>Overdue</option>
                    </select>
                </div>
                
                <div class="col-span-2 flex gap-2">
                    <button type="submit" class="flex-1 bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors text-sm font-medium">
                        Filter
                    </button>
                    <a href="payables.php" class="flex-1 text-center bg-gray-200 text-gray-800 py-2 px-4 rounded-md hover:bg-gray-300 transition-colors text-sm font-medium">
                        Reset
                    </a>
                </div>
            </form>
        </div>
        
        <!-- Payables List -->
        <div class="p-6">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Daftar Hutang</h3>
            <div class="space-y-3">
                <?php if ($payables->num_rows > 0): ?>
                    <?php while ($row = $payables->fetch_assoc()): 
                        $status_colors = [
                            'pending' => 'border-yellow-500 bg-yellow-50',
                            'partial' => 'border-blue-500 bg-blue-50',
                            'paid' => 'border-green-500 bg-green-50',
                            'overdue' => 'border-red-500 bg-red-50'
                        ];
                        $color = $status_colors[$row['status']] ?? 'border-gray-500';
                    ?>
                        <div class="border-l-4 <?php echo $color; ?> pl-4 py-3 rounded-r-lg hover:shadow-md transition-shadow">
                            <div class="flex items-start justify-between">
                                <div class="flex-1">
                                    <div class="flex items-center gap-2">
                                        <h4 class="font-semibold text-gray-800"><?php echo htmlspecialchars($row['supplier_name']); ?></h4>
                                        <code class="text-xs bg-gray-200 px-2 py-1 rounded"><?php echo $row['ref_code']; ?></code>
                                        <span class="text-xs px-2 py-0.5 rounded-full <?php 
                                            echo $row['status'] === 'paid' ? 'bg-green-100 text-green-800' : 
                                                ($row['status'] === 'overdue' ? 'bg-red-100 text-red-800' : 
                                                ($row['status'] === 'partial' ? 'bg-blue-100 text-blue-800' : 'bg-yellow-100 text-yellow-800')); 
                                        ?>">
                                            <?php echo ucfirst($row['status']); ?>
                                        </span>
                                    </div>
                                    <p class="text-sm text-gray-600 mt-1"><?php echo htmlspecialchars($row['description']); ?></p>
                                    <p class="text-xs text-gray-500 mt-1">
                                        Jatuh tempo: <?php echo formatTanggal($row['due_date']); ?>
                                        <?php if ($row['creator_name']): ?>
                                            • oleh <?php echo htmlspecialchars($row['creator_name']); ?>
                                        <?php endif; ?>
                                    </p>
                                </div>
                                <div class="text-right ml-4">
                                    <div class="space-y-1">
                                        <div>
                                            <p class="text-xs text-gray-500">Total</p>
                                            <p class="font-bold text-gray-800"><?php echo formatRupiah($row['total_amount']); ?></p>
                                        </div>
                                        <div>
                                            <p class="text-xs text-gray-500">Terbayar</p>
                                            <p class="font-medium text-green-600"><?php echo formatRupiah($row['total_amount'] - $row['remaining_amount']); ?></p>
                                        </div>
                                        <div>
                                            <p class="text-xs text-gray-500">Sisa</p>
                                            <p class="font-bold text-orange-600"><?php echo formatRupiah($row['remaining_amount']); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Action Buttons -->
                            <div class="mt-3 flex gap-2 flex-wrap">
                                <?php if ($row['status'] !== 'paid' && $row['approved_at'] !== null): ?>
                                    <button onclick="showPaymentModal(<?php echo htmlspecialchars(json_encode($row)); ?>)"
                                            class="text-xs bg-green-600 text-white px-4 py-1.5 rounded hover:bg-green-700 font-medium">
                                        💰 Bayar Hutang
                                    </button>
                                <?php endif; ?>
                                
                                <!-- FIX: tombol kartu hutang -->
                                <a href="payable_history_page.php?id=<?php echo $row['id']; ?>"
                                   class="text-xs bg-blue-600 text-white px-4 py-1.5 rounded hover:bg-blue-700 font-medium">
                                    📋 Kartu Hutang
                                </a>
                                <?php if (isSupervisor() && $row['approved_at'] === null): ?>
                                    <!-- Approve Button -->
            <form method="POST" action="handlers/payable_return_handler.php" class="inline">
                                        <input type="hidden" name="action" value="approve">
                                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                        <button type="submit" onclick="return confirm('Approve hutang ini?')"
                                                class="text-xs bg-purple-600 text-white px-4 py-1.5 rounded hover:bg-purple-700 font-medium">
                                            ✓ Approve
                                        </button>
                                    </form>
                                    
                                    <!-- Return Button -->
                                    <button onclick="showReturnModal(<?php echo $row['id']; ?>)"
                                            class="text-xs bg-yellow-600 text-white px-4 py-1.5 rounded hover:bg-yellow-700 font-medium">
                                        🔄 Return
                                    </button>
                                    
                                    <!-- Reject Button -->
                                    <button onclick="showRejectModal(<?php echo $row['id']; ?>)"
                                            class="text-xs bg-red-600 text-white px-4 py-1.5 rounded hover:bg-red-700 font-medium">
                                        ✕ Reject
                                    </button>
                                
                            
                                <?php endif; ?>
                                <?php if ($row['status'] == 'returned' && $row['created_by'] == $_SESSION['user_id']): ?>
                                    <button onclick="showEditModal(<?php echo htmlspecialchars(json_encode($row)); ?>)"
                                            class="text-xs bg-orange-600 text-white px-4 py-1.5 rounded hover:bg-orange-700 font-medium">
                                            ✏️ Edit & Resubmit
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p class="text-center text-gray-500 py-8">Belum ada hutang yang terdaftar</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Payment Modal -->
<div id="paymentModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <h3 class="text-lg font-semibold text-gray-900 mb-4">Bayar Hutang</h3>
            <form method="POST" action="handlers/payable_payment_handler.php">
            <input type="hidden" name="payable_id" id="payment_payable_id">
            
            <div class="mb-3 p-3 bg-gray-50 rounded">
                <p class="text-sm text-gray-600">Supplier: <span id="payment_supplier" class="font-semibold"></span></p>
                <p class="text-sm text-gray-600">Ref: <code id="payment_ref" class="bg-gray-200 px-2 py-0.5 rounded"></code></p>
                <p class="text-sm text-gray-600 mt-1">Sisa Hutang: <span id="payment_remaining" class="font-bold text-orange-600"></span></p>
            </div>
            
            <div class="mb-3">
                <label class="block text-sm font-medium text-gray-700 mb-1">Tanggal Bayar</label>
                <input type="date" name="payment_date" value="<?php echo date('Y-m-d'); ?>" required
                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500">
            </div>
            
            <div class="mb-3">
                <label class="block text-sm font-medium text-gray-700 mb-1">Jumlah Bayar</label>
                <input type="number" name="amount" id="payment_amount" step="1" min="1" required
                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                       placeholder="Masukkan jumlah">
            </div>
            
            <div class="mb-3">
                <label class="block text-sm font-medium text-gray-700 mb-1">Metode Pembayaran</label>
                <select name="payment_method" required
                        class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500">
                    <option value="tunai">Tunai</option>
                    <option value="transfer">Transfer</option>
                </select>
            </div>
            
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-1">Catatan (opsional)</label>
                <textarea name="notes" rows="2"
                          class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                          placeholder="Catatan pembayaran..."></textarea>
            </div>
            
            <div class="flex justify-end gap-2">
                <button type="button" onclick="closePaymentModal()" 
                        class="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300">
                    Batal
                </button>
                <button type="submit" 
                        class="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700">
                    Proses Pembayaran
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Return Modal -->
<div id="returnModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <h3 class="text-lg font-semibold text-gray-900 mb-4">Return untuk Revisi</h3>
            <form method="POST" action="handlers/payable_return_handler.php">
            <input type="hidden" name="action" value="return">
            <input type="hidden" name="id" id="return_id">
            
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    Alasan Pengembalian <span class="text-red-500">*</span>
                </label>
                <textarea name="reason" required minlength="10" rows="4"
                          class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-yellow-500"
                          placeholder="Jelaskan apa yang perlu diperbaiki (min. 10 karakter)"></textarea>
                <p class="text-xs text-gray-500 mt-1">Data akan dikembalikan ke staff untuk diedit</p>
            </div>
            
            <div class="flex justify-end gap-2">
                <button type="button" onclick="closeReturnModal()" 
                        class="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300">
                    Batal
                </button>
                <button type="submit" 
                        class="px-4 py-2 bg-yellow-600 text-white rounded-md hover:bg-yellow-700">
                    🔄 Return
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Reject Modal -->
<div id="rejectModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <h3 class="text-lg font-semibold text-gray-900 mb-4">Reject Hutang</h3>
            <form method="POST" action="handlers/payable_return_handler.php">
            <input type="hidden" name="action" value="reject">
            <input type="hidden" name="id" id="reject_id">
            
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    Alasan Penolakan <span class="text-red-500">*</span>
                </label>
                <textarea name="reason" required minlength="10" rows="4"
                          class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-red-500"
                          placeholder="Jelaskan alasan penolakan (min. 10 karakter)"></textarea>
                <p class="text-xs text-red-500 mt-1">Data yang ditolak tidak dapat diedit lagi</p>
            </div>
            
            <div class="flex justify-end gap-2">
                <button type="button" onclick="closeRejectModal()" 
                        class="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300">
                    Batal
                </button>
                <button type="submit" 
                        class="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700">
                    ✕ Reject
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Edit Modal for Returned Data -->
<div id="editModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
    <div class="relative top-10 mx-auto p-5 border w-full max-w-2xl shadow-lg rounded-md bg-white">
        <h3 class="text-lg font-semibold text-gray-900 mb-4">Edit & Resubmit Hutang</h3>
            <form method="POST" action="handlers/payable_return_handler.php">
            <input type="hidden" name="action" value="resubmit">
            <input type="hidden" name="id" id="edit_id">
            
            <div class="mb-4 p-3 bg-yellow-50 border border-yellow-200 rounded">
                <p class="text-sm font-medium text-yellow-800">📝 Alasan Pengembalian:</p>
                <p class="text-sm text-yellow-700 mt-1" id="edit_return_reason"></p>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Nama Supplier <span class="text-red-500">*</span></label>
                    <input type="text" name="supplier_name" id="edit_supplier_name" required
                           class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500">
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Total Nominal <span class="text-red-500">*</span></label>
                    <input type="number" name="total_amount" id="edit_total_amount" required step="1" min="0"
                           class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500">
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Tanggal Jatuh Tempo <span class="text-red-500">*</span></label>
                    <input type="date" name="due_date" id="edit_due_date" required
                           class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500">
                </div>
                
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Deskripsi <span class="text-red-500">*</span></label>
                    <textarea name="description" id="edit_description" required rows="3"
                              class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"></textarea>
                </div>
            </div>
            
            <div class="mt-4 flex justify-end gap-2">
                <button type="button" onclick="closeEditModal()" 
                        class="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300">
                    Batal
                </button>
                <button type="submit" 
                        class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
                    💾 Simpan & Kirim Ulang
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    function toggleInputForm() {
        const form = document.getElementById('inputForm');
        form.classList.toggle('hidden');
        if (!form.classList.contains('hidden')) {
            form.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }
    
    function showPaymentModal(payable) {
        document.getElementById('payment_payable_id').value = payable.id;
        document.getElementById('payment_supplier').textContent = payable.supplier_name;
        document.getElementById('payment_ref').textContent = payable.ref_code;
        document.getElementById('payment_remaining').textContent = 'Rp ' + parseFloat(payable.remaining_amount).toLocaleString('id-ID');
        document.getElementById('payment_amount').max = payable.remaining_amount;
        document.getElementById('payment_amount').value = payable.remaining_amount;
        document.getElementById('paymentModal').classList.remove('hidden');
    }
    
    function closePaymentModal() {
        document.getElementById('paymentModal').classList.add('hidden');
    }
    function showEditModal(payable) {
    document.getElementById('edit_id').value = payable.id;
    document.getElementById('edit_supplier_name').value = payable.supplier_name;
    document.getElementById('edit_total_amount').value = payable.total_amount;
    document.getElementById('edit_due_date').value = payable.due_date;
    document.getElementById('edit_description').value = payable.description;
    document.getElementById('edit_return_reason').textContent = payable.notes || 'Tidak ada alasan';
    document.getElementById('editModal').classList.remove('hidden');
}

function closeEditModal() {
    document.getElementById('editModal').classList.add('hidden');
}

// Update event listener Escape
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        closePaymentModal();
        closeEditModal();
        closeReturnModal();
        closeRejectModal();
    }
});
    function showReturnModal(id) {
        document.getElementById('return_id').value = id;
        document.getElementById('returnModal').classList.remove('hidden');
    }
    
    function closeReturnModal() {
        document.getElementById('returnModal').classList.add('hidden');
    }
    
    function showRejectModal(id) {
        document.getElementById('reject_id').value = id;
        document.getElementById('rejectModal').classList.remove('hidden');
    }
    
    function closeRejectModal() {
        document.getElementById('rejectModal').classList.add('hidden');
    }
    
    document.addEventListener('keydown', function(event) {
        if (event.key === 'Escape') {
            closePaymentModal();
            closeReturnModal();
            closeRejectModal();
            const form = document.getElementById('inputForm');
            if (form && !form.classList.contains('hidden')) {
                form.classList.add('hidden');
            }
        }
    });
</script>

</body>
</html>
<?php $conn->close(); ?>