<?php
require_once __DIR__ . '/includes/config.php';
checkLogin();
if (isAdmin()) {
    $_SESSION['error'] = 'Admin tidak memiliki akses ke halaman ini.';
    header('Location: manage_users.php');
    exit();
}

$conn = getDBConnection();

// Get filter parameters
$filter_date_from = $_GET['date_from'] ?? '';
$filter_date_to = $_GET['date_to'] ?? '';
$filter_account_code = $_GET['account_code'] ?? '';

// Build query dengan filter
$where_conditions = [];
$params = [];
$types = "";

if (!empty($filter_date_from)) {
    $where_conditions[] = "gj.journal_date >= ?";
    $params[] = $filter_date_from;
    $types .= "s";
}

if (!empty($filter_date_to)) {
    $where_conditions[] = "gj.journal_date <= ?";
    $params[] = $filter_date_to;
    $types .= "s";
}

if (!empty($filter_account_code)) {
    $where_conditions[] = "je.account_code LIKE ?";
    $params[] = $filter_account_code . '%';
    $types .= "s";
}

// Base query
$query = "SELECT gj.id, gj.journal_date, gj.description, 
          je.account_code, je.account_name, je.debit, je.credit
          FROM general_journal gj
          LEFT JOIN journal_entries je ON gj.id = je.journal_id";

if (!empty($where_conditions)) {
    $query .= " WHERE " . implode(" AND ", $where_conditions);
}

$query .= " ORDER BY gj.journal_date DESC, gj.created_at DESC, je.id ASC";

// Execute query
if (!empty($params)) {
    $stmt = $conn->prepare($query);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query($query);
}

// Group entries by journal_id
$journals = [];
$total_debit = 0;
$total_credit = 0;

while ($row = $result->fetch_assoc()) {
    $journal_id = $row['id'];
    
    if (!isset($journals[$journal_id])) {
        $journals[$journal_id] = [
            'date' => $row['journal_date'],
            'description' => $row['description'],
            'entries' => [],
            'total_debit' => 0,
            'total_credit' => 0
        ];
    }
    
    $journals[$journal_id]['entries'][] = [
        'account_code' => $row['account_code'],
        'account_name' => $row['account_name'],
        'debit' => $row['debit'],
        'credit' => $row['credit']
    ];
    
    $journals[$journal_id]['total_debit'] += $row['debit'];
    $journals[$journal_id]['total_credit'] += $row['credit'];
    $total_debit += $row['debit'];
    $total_credit += $row['credit'];
}

// Get chart of accounts untuk dropdown
$accounts = $conn->query("SELECT account_code, account_name FROM chart_of_accounts ORDER BY account_code");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jurnal Umum - Sistem Informasi Akuntansi</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <?php include __DIR__ . '/includes/header.php'; ?>
    
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-6">
        <div class="mb-6 flex items-center justify-between">
            <h2 class="text-2xl font-bold text-gray-800">Jurnal Umum</h2>
            <a href="exports/export_journal.php<?php echo !empty($_SERVER['QUERY_STRING']) ? '?' . $_SERVER['QUERY_STRING'] : ''; ?>" 
               class="bg-green-600 text-white px-6 py-2.5 rounded-lg hover:bg-green-700 font-medium transition-colors">
                📥 Export Excel
            </a>
        </div>
        
        <!-- Filter Section -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-6">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Filter Jurnal</h3>
            <form method="GET" class="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Dari Tanggal</label>
                    <input type="date" name="date_from" value="<?php echo htmlspecialchars($filter_date_from); ?>"
                           class="w-full px-3 py-2 border border-gray-300 rounded-md">
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Sampai Tanggal</label>
                    <input type="date" name="date_to" value="<?php echo htmlspecialchars($filter_date_to); ?>"
                           class="w-full px-3 py-2 border border-gray-300 rounded-md">
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Kode Akun</label>
                    <select name="account_code" class="w-full px-3 py-2 border border-gray-300 rounded-md">
                        <option value="">Semua Akun</option>
                        <?php while ($acc = $accounts->fetch_assoc()): ?>
                            <option value="<?php echo $acc['account_code']; ?>" 
                                    <?php echo $filter_account_code == $acc['account_code'] ? 'selected' : ''; ?>>
                                <?php echo $acc['account_code'] . ' - ' . $acc['account_name']; ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                
                <div class="flex items-end gap-2">
                    <button type="submit" class="flex-1 bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700">
                        🔍 Filter
                    </button>
                    <a href="journal.php" class="bg-gray-200 text-gray-700 px-6 py-2 rounded-md hover:bg-gray-300">
                        Reset
                    </a>
                </div>
            </form>
        </div>

        <!-- Summary Cards -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div class="bg-white rounded-lg shadow p-4">
                <p class="text-sm text-gray-600">Total Debit</p>
                <p class="text-xl font-bold text-blue-600"><?php echo formatRupiah($total_debit); ?></p>
            </div>
            <div class="bg-white rounded-lg shadow p-4">
                <p class="text-sm text-gray-600">Total Kredit</p>
                <p class="text-xl font-bold text-green-600"><?php echo formatRupiah($total_credit); ?></p>
            </div>
            <div class="bg-white rounded-lg shadow p-4">
                <p class="text-sm text-gray-600">Status</p>
                <p class="text-xl font-bold <?php echo abs($total_debit - $total_credit) < 0.01 ? 'text-green-600' : 'text-red-600'; ?>">
                    <?php 
                    if (abs($total_debit - $total_credit) < 0.01) {
                        echo 'BALANCE ✓';
                    } else {
                        echo 'NOT BALANCE ✗';
                    }
                    ?>
                </p>
            </div>
        </div>
        
        <!-- Journal Table -->
        <div class="bg-white rounded-lg shadow overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full border-collapse">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="border border-gray-300 px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase">Tanggal</th>
                            <th class="border border-gray-300 px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase">Kode</th>
                            <th class="border border-gray-300 px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase">Nama Akun</th>
                            <th class="border border-gray-300 px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase">Keterangan</th>
                            <th class="border border-gray-300 px-4 py-3 text-right text-xs font-medium text-gray-700 uppercase">Debit</th>
                            <th class="border border-gray-300 px-4 py-3 text-right text-xs font-medium text-gray-700 uppercase">Kredit</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($journals) > 0): ?>
                            <?php foreach ($journals as $journal): ?>
                                <!-- Header Transaksi -->
                                <tr class="bg-gray-100 font-semibold">
                                    <td class="border border-gray-300 px-4 py-2 text-sm">
                                        <?php echo formatTanggal($journal['date']); ?>
                                    </td>
                                    <td colspan="5" class="border border-gray-300 px-4 py-2 text-sm">
                                        <?php echo htmlspecialchars($journal['description']); ?>
                                    </td>
                                </tr>
                                
                                <!-- Entries -->
                                <?php foreach ($journal['entries'] as $entry): ?>
                                    <tr class="hover:bg-gray-50">
                                        <td class="border border-gray-300 px-4 py-2"></td>
                                        <td class="border border-gray-300 px-4 py-2 text-sm text-gray-700">
                                            <?php echo htmlspecialchars(formatAccountCodeDisplay($entry['account_code'])); ?>
                                        </td>
                                        <td class="border border-gray-300 px-4 py-2 text-sm">
                                            <?php echo htmlspecialchars($entry['account_name']); ?>
                                        </td>
                                        <td class="border border-gray-300 px-4 py-2 text-sm text-gray-600">
                                            <!-- Kosong atau bisa diisi detail tambahan -->
                                        </td>
                                        <td class="border border-gray-300 px-4 py-2 text-sm text-right font-medium">
                                            <?php echo $entry['debit'] > 0 ? formatRupiah($entry['debit']) : ''; ?>
                                        </td>
                                        <td class="border border-gray-300 px-4 py-2 text-sm text-right font-medium">
                                            <?php echo $entry['credit'] > 0 ? formatRupiah($entry['credit']) : ''; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                
                                <!-- Subtotal per jurnal -->
                                <tr class="bg-blue-50 font-bold">
                                    <td colspan="4" class="border border-gray-300 px-4 py-2 text-sm text-right">
                                        SUBTOTAL
                                    </td>
                                    <td class="border border-gray-300 px-4 py-2 text-sm text-right text-blue-700">
                                        <?php echo formatRupiah($journal['total_debit']); ?>
                                    </td>
                                    <td class="border border-gray-300 px-4 py-2 text-sm text-right text-green-700">
                                        <?php echo formatRupiah($journal['total_credit']); ?>
                                    </td>
                                </tr>
                                
                                <!-- Balance Check per jurnal -->
                                <?php 
                                $is_balanced = abs($journal['total_debit'] - $journal['total_credit']) < 0.01;
                                ?>
                                <tr class="<?php echo $is_balanced ? 'bg-green-50' : 'bg-red-50'; ?>">
                                    <td colspan="4" class="border border-gray-300 px-4 py-2 text-sm text-right font-medium">
                                        <?php echo $is_balanced ? '✓ BALANCE' : '✗ NOT BALANCE'; ?>
                                    </td>
                                    <td colspan="2" class="border border-gray-300 px-4 py-2 text-sm text-center <?php echo $is_balanced ? 'text-green-700' : 'text-red-700'; ?>">
                                        <?php 
                                        if (!$is_balanced) {
                                            echo 'Selisih: ' . formatRupiah(abs($journal['total_debit'] - $journal['total_credit']));
                                        }
                                        ?>
                                    </td>
                                </tr>
                                
                                <!-- Spacer -->
                                <tr>
                                    <td colspan="6" class="py-2"></td>
                                </tr>
                            <?php endforeach; ?>
                            
                            <!-- Grand Total -->
                            <tr class="bg-gray-800 text-white font-bold">
                                <td colspan="4" class="border border-gray-700 px-4 py-3 text-sm text-right">
                                    TOTAL KESELURUHAN
                                </td>
                                <td class="border border-gray-700 px-4 py-3 text-sm text-right">
                                    <?php echo formatRupiah($total_debit); ?>
                                </td>
                                <td class="border border-gray-700 px-4 py-3 text-sm text-right">
                                    <?php echo formatRupiah($total_credit); ?>
                                </td>
                            </tr>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="border border-gray-300 text-center text-gray-500 py-8">
                                    Belum ada data jurnal
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Info Footer -->
        <div class="mt-4 text-sm text-gray-600 text-center">
            <p>📋 Total <?php echo count($journals); ?> transaksi jurnal</p>
        </div>
    </div>
</body>
</html>
<?php $conn->close(); ?>