<?php
require_once __DIR__ . '/includes/config.php';
checkLogin();
if (isAdmin()) {
    $_SESSION['error'] = 'Admin tidak memiliki akses ke halaman ini.';
    header('Location: manage_users.php');
    exit();
}

$conn = getDBConnection();
$success = isset($_SESSION['success']) ? $_SESSION['success'] : '';
$error = isset($_SESSION['error']) ? $_SESSION['error'] : '';
unset($_SESSION['success'], $_SESSION['error']);

// Generate ref code
function generateRefCode($conn, $prefix = 'RCV') {
    $date = date('Ymd');
    $stmt = $conn->prepare("SELECT ref_code FROM receivables WHERE ref_code LIKE ? ORDER BY ref_code DESC LIMIT 1");
    $pattern = $prefix . $date . '%';
    $stmt->bind_param("s", $pattern);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $last_code = $result->fetch_assoc()['ref_code'];
        $last_num = intval(substr($last_code, -4));
        $new_num = str_pad($last_num + 1, 4, '0', STR_PAD_LEFT);
    } else {
        $new_num = '0001';
    }
    
    return $prefix . $date . $new_num;
}

// Handle approve action
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'approve') {
    if (!isSupervisor()) {
        $_SESSION['error'] = 'Hanya supervisor yang dapat meng-approve piutang!';
        header('Location: receivable_approve_handler.php');
        exit();
    }
    
    $receivable_id = intval($_POST['id']);
    $user_id = $_SESSION['user_id'];
    
    // Get receivable details
    $stmt = $conn->prepare("SELECT * FROM receivables WHERE id = ?");
    $stmt->bind_param("i", $receivable_id);
    $stmt->execute();
    $receivable = $stmt->get_result()->fetch_assoc();
    
    if ($receivable) {
        // Update approval
        $stmt2 = $conn->prepare("UPDATE receivables SET approved_by = ?, approved_at = NOW() WHERE id = ?");
        $stmt2->bind_param("ii", $user_id, $receivable_id);
        
        if ($stmt2->execute()) {
            // Create journal entry
            $journal_desc = "Piutang dari " . $receivable['customer_name'] . " - " . $receivable['description'];
            $stmt3 = $conn->prepare("INSERT INTO general_journal (journal_date, description, reference_id, reference_type) VALUES (CURDATE(), ?, ?, 'receivable')");
            $stmt3->bind_param("si", $journal_desc, $receivable_id);
            $stmt3->execute();
            $journal_id = $stmt3->insert_id;
            
            // Debit: Piutang Usaha
            $stmt4 = $conn->prepare("INSERT INTO journal_entries (journal_id, account_code, account_name, debit, credit) VALUES (?, '1-1200', 'Piutang Usaha', ?, 0)");
            $stmt4->bind_param("id", $journal_id, $receivable['total_amount']);
            $stmt4->execute();
            
            // Credit: Pendapatan (4-4100)
            $stmt4 = $conn->prepare("INSERT INTO journal_entries (journal_id, account_code, account_name, debit, credit) VALUES (?, '4-4100', 'Pendapatan', 0, ?)");
            $stmt4->bind_param("id", $journal_id, $total_amount);
            $stmt4->execute();
            
            $_SESSION['success'] = 'Piutang berhasil di-approve!';
        } else {
            $_SESSION['error'] = 'Gagal meng-approve piutang!';
        }
    } else {
        $_SESSION['error'] = 'Piutang tidak ditemukan!';
    }
    
    header('Location: receivable_approve_handler.php');
    exit();
}

// Handle form submission - Add Receivable
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_receivable'])) {
    $customer_name = trim($_POST['customer_name']);
    $description = trim($_POST['description']);
    $total_amount = floatval($_POST['total_amount']);
    $due_date = $_POST['due_date'];
    $user_id = $_SESSION['user_id'];
    
    $ref_code = generateRefCode($conn);
    $status = isSupervisor() ? 'pending' : 'pending';
    
    $stmt = $conn->prepare("INSERT INTO receivables (ref_code, customer_name, description, total_amount, remaining_amount, due_date, status, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssddssi", $ref_code, $customer_name, $description, $total_amount, $total_amount, $due_date, $status, $user_id);
    
    if ($stmt->execute()) {
        $receivable_id = $stmt->insert_id;
        
        // Auto-approve if supervisor
        if (isSupervisor()) {
            $stmt2 = $conn->prepare("UPDATE receivables SET approved_by = ?, approved_at = NOW() WHERE id = ?");
            $stmt2->bind_param("ii", $user_id, $receivable_id);
            $stmt2->execute();
            
            // Create journal entry
            $journal_desc = "Piutang dari " . $customer_name . " - " . $description;
            $stmt3 = $conn->prepare("INSERT INTO general_journal (journal_date, description, reference_id, reference_type) VALUES (CURDATE(), ?, ?, 'receivable')");
            $stmt3->bind_param("si", $journal_desc, $receivable_id);
            $stmt3->execute();
            $journal_id = $stmt3->insert_id;
            
            // Debit: Piutang Usaha
            $stmt4 = $conn->prepare("INSERT INTO journal_entries (journal_id, account_code, account_name, debit, credit) VALUES (?, '1-1200', 'Piutang Usaha', ?, 0)");
            $stmt4->bind_param("id", $journal_id, $total_amount);
            $stmt4->execute();
            
            // Credit: Pendapatan Penjualan
            $stmt4 = $conn->prepare("INSERT INTO journal_entries (journal_id, account_code, account_name, debit, credit) VALUES (?, '4-4100', 'Pendapatan Penjualan', 0, ?)");
            $stmt4->bind_param("id", $journal_id, $total_amount);
            $stmt4->execute();
        }
        
        $success = 'Piutang berhasil ditambahkan! Ref: ' . $ref_code;
    } else {
        $error = 'Gagal menambahkan piutang!';
    }
}

// Get filter
$filter_status = $_GET['status'] ?? '';
$filter_customer = $_GET['customer'] ?? '';

// Build query
$query = "SELECT r.*, u.full_name as creator_name 
          FROM receivables r 
          LEFT JOIN users u ON r.created_by = u.id 
          WHERE 1=1";

$params = [];
$types = "";

if (!empty($filter_status)) {
    $query .= " AND r.status = ?";
    $params[] = $filter_status;
    $types .= "s";
}

if (!empty($filter_customer)) {
    $query .= " AND r.customer_name LIKE ?";
    $params[] = '%' . $filter_customer . '%';
    $types .= "s";
}

$query .= " ORDER BY r.due_date ASC, r.created_at DESC";

if (!empty($params)) {
    $stmt = $conn->prepare($query);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $receivables = $stmt->get_result();
} else {
    $receivables = $conn->query($query);
}

// Update overdue status
$conn->query("UPDATE receivables SET status = 'overdue' WHERE status IN ('pending', 'partial') AND due_date < CURDATE()");

// Count pending for supervisor
$pending_count = 0;
if (isSupervisor()) {
    $result = $conn->query("SELECT COUNT(*) as count FROM receivables WHERE approved_at IS NULL");
    $pending_count = $result->fetch_assoc()['count'];
}

// Summary - FIXED: Calculate paid from total-remaining
$summary_result = $conn->query("SELECT 
    COALESCE(SUM(total_amount), 0) as total,
    COALESCE(SUM(total_amount - remaining_amount), 0) as paid,
    COALESCE(SUM(remaining_amount), 0) as remaining,
    COUNT(CASE WHEN status = 'overdue' THEN 1 END) as overdue_count
    FROM receivables WHERE status != 'paid'");

$summary = $summary_result ? $summary_result->fetch_assoc() : [
    'total' => 0,
    'paid' => 0,
    'remaining' => 0,
    'overdue_count' => 0
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Piutang - Sistem Informasi Akuntansi</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <?php include __DIR__ . '/includes/header.php'; ?>
    
    <div class="container mx-auto px-4 py-6">
        <!-- Alert Messages -->
        <?php if ($success): ?>
            <div class="mb-4 p-4 bg-green-100 border border-green-400 text-green-700 rounded-lg">
                <?php echo $success; ?>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="mb-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded-lg">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <!-- Page Header -->
        <div class="mb-6 flex justify-between items-center">
            <div>
                <h2 class="text-2xl font-bold text-gray-800">Manajemen Piutang</h2>
                <p class="text-gray-600">Kelola piutang usaha dan pembayaran</p>
                <?php if (isSupervisor() && $pending_count > 0): ?>
                    <div class="mt-2 inline-block bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-sm font-medium">
                        Ã°Å¸â€â€ <?php echo $pending_count; ?> piutang menunggu approval
                    </div>
                <?php endif; ?>
            </div>
            <div class="flex gap-3">
                <?php if (!isSupervisor()): ?>
                <button onclick="toggleInputForm()" class="bg-blue-600 text-white px-6 py-2.5 rounded-lg hover:bg-blue-700 transition-colors font-medium flex items-center gap-2">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
                    </svg>
                    Input Piutang
                </button>
                <?php endif; ?>
                <a href="exports/export_receivables.php" target="_blank" 
                   class="bg-green-600 text-white px-6 py-2.5 rounded-lg hover:bg-green-700 transition-colors font-medium flex items-center gap-2">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                    </svg>
                    Export
                </a>
            </div>
        </div>

        <!-- Summary Cards -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div class="bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg shadow-lg p-6 text-white">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-blue-100 text-sm font-medium">Total Piutang</p>
                        <h3 class="text-2xl font-bold mt-1"><?php echo formatRupiah($summary['total']); ?></h3>
                    </div>
                    <div class="bg-blue-400 bg-opacity-50 p-3 rounded-lg">
                        <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                        </svg>
                    </div>
                </div>
            </div>

            <div class="bg-gradient-to-br from-green-500 to-green-600 rounded-lg shadow-lg p-6 text-white">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-green-100 text-sm font-medium">Terbayar</p>
                        <h3 class="text-2xl font-bold mt-1"><?php echo formatRupiah($summary['paid']); ?></h3>
                    </div>
                    <div class="bg-green-400 bg-opacity-50 p-3 rounded-lg">
                        <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                    </div>
                </div>
            </div>

            <div class="bg-gradient-to-br from-orange-500 to-orange-600 rounded-lg shadow-lg p-6 text-white">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-orange-100 text-sm font-medium">Sisa Piutang</p>
                        <h3 class="text-2xl font-bold mt-1"><?php echo formatRupiah($summary['remaining']); ?></h3>
                    </div>
                    <div class="bg-orange-400 bg-opacity-50 p-3 rounded-lg">
                        <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                    </div>
                </div>
            </div>

            <div class="bg-gradient-to-br from-red-500 to-red-600 rounded-lg shadow-lg p-6 text-white">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-red-100 text-sm font-medium">Overdue</p>
                        <h3 class="text-2xl font-bold mt-1"><?php echo $summary['overdue_count']; ?> piutang</h3>
                    </div>
                    <div class="bg-red-400 bg-opacity-50 p-3 rounded-lg">
                        <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                    </div>
                </div>
            </div>
        </div>
        
        <?php if (!isSupervisor()): ?>
        <!-- Input Form -->
        <div id="inputForm" class="hidden mb-6 bg-white rounded-lg shadow-lg p-6 border-2 border-blue-500">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-lg font-semibold text-gray-800">Input Piutang Baru</h3>
                <button onclick="toggleInputForm()" class="text-gray-500 hover:text-gray-700">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>
            <form method="POST" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                    <label class="block text-xs font-medium text-gray-700 mb-1">Nama Customer</label>
                    <input type="text" name="customer_name" required
                           class="w-full px-3 py-2 text-sm border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                           placeholder="PT. ABC / John Doe">
                </div>
                
                <div>
                    <label class="block text-xs font-medium text-gray-700 mb-1">Keterangan</label>
                    <input type="text" name="description" required
                           class="w-full px-3 py-2 text-sm border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                           placeholder="Penjualan produk...">
                </div>
                
                <div>
                    <label class="block text-xs font-medium text-gray-700 mb-1">Jumlah Piutang</label>
                    <input type="number" name="total_amount" step="1" min="1" required
                           class="w-full px-3 py-2 text-sm border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                           placeholder="5000000">
                </div>
                
                <div>
                    <label class="block text-xs font-medium text-gray-700 mb-1">Jatuh Tempo</label>
                    <input type="date" name="due_date" required value="<?php echo date('Y-m-d', strtotime('+30 days')); ?>"
                           class="w-full px-3 py-2 text-sm border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500">
                </div>
                
                <div class="md:col-span-2 lg:col-span-4 flex justify-end">
                    <button type="submit" name="add_receivable"
                            class="bg-green-600 text-white py-2 px-6 rounded-md hover:bg-green-700 transition-colors font-medium text-sm">
                        Simpan Piutang
                    </button>
                </div>
            </form>
        </div>
        <?php endif; ?>
        
        <!-- Receivables List with Filters -->
        <div class="bg-white rounded-lg shadow">
            <!-- Filter Bar -->
            <div class="p-4 bg-gray-50 border-b border-gray-200">
                <form method="GET" class="grid grid-cols-2 md:grid-cols-4 gap-3">
                    <div>
                        <input type="text" name="customer" value="<?php echo htmlspecialchars($filter_customer); ?>" placeholder="Cari customer..."
                               class="w-full px-3 py-2 text-sm border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500">
                    </div>
                    
                    <div>
                        <select name="status" class="w-full px-3 py-2 text-sm border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500">
                            <option value="">Semua Status</option>
                            <option value="pending" <?php echo $filter_status === 'pending' ? 'selected' : ''; ?>>Pending</option>
                            <option value="partial" <?php echo $filter_status === 'partial' ? 'selected' : ''; ?>>Partial</option>
                            <option value="paid" <?php echo $filter_status === 'paid' ? 'selected' : ''; ?>>Lunas</option>
                            <option value="overdue" <?php echo $filter_status === 'overdue' ? 'selected' : ''; ?>>Overdue</option>
                        </select>
                    </div>
                    
                    <div class="col-span-2 flex gap-2">
                        <button type="submit" class="flex-1 bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors text-sm font-medium">
                            Filter
                        </button>
                        <a href="receivables.php" class="flex-1 text-center bg-gray-200 text-gray-800 py-2 px-4 rounded-md hover:bg-gray-300 transition-colors text-sm font-medium">
                            Reset
                        </a>
                    </div>
                </form>
            </div>
            
            <!-- Receivables List -->
            <div class="p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Daftar Piutang</h3>
                <div class="space-y-3">
                    <?php if ($receivables->num_rows > 0): ?>
                        <?php while ($row = $receivables->fetch_assoc()): 
                            $status_colors = [
                                'pending' => 'border-yellow-500 bg-yellow-50',
                                'partial' => 'border-blue-500 bg-blue-50',
                                'paid' => 'border-green-500 bg-green-50',
                                'overdue' => 'border-red-500 bg-red-50'
                            ];
                            $color = $status_colors[$row['status']] ?? 'border-gray-500';
                        ?>
                            <div class="border-l-4 <?php echo $color; ?> pl-4 py-3 rounded-r-lg hover:shadow-md transition-shadow">
                                <div class="flex items-start justify-between">
                                    <div class="flex-1">
                                        <div class="flex items-center gap-2">
                                            <h4 class="font-semibold text-gray-800"><?php echo htmlspecialchars($row['customer_name']); ?></h4>
                                            <code class="text-xs bg-gray-200 px-2 py-1 rounded"><?php echo $row['ref_code']; ?></code>
                                            <span class="text-xs px-2 py-0.5 rounded-full <?php 
                                                echo $row['status'] === 'paid' ? 'bg-green-100 text-green-800' : 
                                                    ($row['status'] === 'overdue' ? 'bg-red-100 text-red-800' : 
                                                    ($row['status'] === 'partial' ? 'bg-blue-100 text-blue-800' : 'bg-yellow-100 text-yellow-800')); 
                                            ?>">
                                                <?php echo ucfirst($row['status']); ?>
                                            </span>
                                        </div>
                                        <p class="text-sm text-gray-600 mt-1"><?php echo htmlspecialchars($row['description']); ?></p>
                                        <p class="text-xs text-gray-500 mt-1">
                                            Jatuh tempo: <?php echo formatTanggal($row['due_date']); ?>
                                            <?php if ($row['creator_name']): ?>
                                                • oleh <?php echo htmlspecialchars($row['creator_name']); ?>
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                    <div class="text-right ml-4">
                                        <div class="space-y-1">
                                            <div>
                                                <p class="text-xs text-gray-500">Total</p>
                                                <p class="font-bold text-gray-800"><?php echo formatRupiah($row['total_amount']); ?></p>
                                            </div>
                                            <div>
                                                <p class="text-xs text-gray-500">Terbayar</p>
                                                <p class="font-medium text-green-600"><?php echo formatRupiah($row['total_amount'] - $row['remaining_amount']); ?></p>
                                            </div>
                                            <div>
                                                <p class="text-xs text-gray-500">Sisa</p>
                                                <p class="font-bold text-orange-600"><?php echo formatRupiah($row['remaining_amount']); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Action Buttons -->
                                <div class="mt-3 flex gap-2 flex-wrap">
                                    <?php if ($row['status'] !== 'paid' && $row['approved_at'] !== null): ?>
                                        <button onclick="showPaymentModal(<?php echo htmlspecialchars(json_encode($row)); ?>)"
                                                class="text-xs bg-green-600 text-white px-4 py-1.5 rounded hover:bg-green-700 font-medium">
                                            💰 Bayar Piutang
                                        </button>
                                    <?php endif; ?>
                                    
                                    <a href="receivable_history_page.php?id=<?php echo $row['id']; ?>"
                                       class="text-xs bg-blue-600 text-white px-4 py-1.5 rounded hover:bg-blue-700 font-medium">
                                        📋 Riwayat
                                    </a>
                                    
                                    <?php if (isSupervisor() && $row['approved_at'] === null): ?>
                                        <form method="POST" action="receivable_approve_handler.php" class="inline">
                                            <input type="hidden" name="action" value="approve">
                                            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                            <button type="submit" onclick="return confirm('Approve piutang ini?')"
                                                    class="text-xs bg-purple-600 text-white px-4 py-1.5 rounded hover:bg-purple-700 font-medium">
                                                ✓ Approve
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p class="text-center text-gray-500 py-8">Belum ada piutang yang terdaftar</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Payment Modal -->
    <div id="paymentModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
        <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">Bayar Piutang</h3>
                <form method="POST" action="handlers/receivable_payment_handler.php">
                <input type="hidden" name="receivable_id" id="payment_receivable_id">
                
                <div class="mb-3 p-3 bg-gray-50 rounded">
                    <p class="text-sm text-gray-600">Customer: <span id="payment_customer" class="font-semibold"></span></p>
                    <p class="text-sm text-gray-600">Ref: <code id="payment_ref" class="bg-gray-200 px-2 py-0.5 rounded"></code></p>
                    <p class="text-sm text-gray-600 mt-1">Sisa Piutang: <span id="payment_remaining" class="font-bold text-orange-600"></span></p>
                </div>
                
                <div class="mb-3">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Tanggal Bayar</label>
                    <input type="date" name="payment_date" value="<?php echo date('Y-m-d'); ?>" required
                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500">
                </div>
                
                <div class="mb-3">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Jumlah Bayar</label>
                    <input type="number" name="amount" id="payment_amount" step="1" min="1" required
                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                           placeholder="Masukkan jumlah">
                </div>
                
                <div class="mb-3">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Metode Pembayaran</label>
                    <select name="payment_method" required
                            class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500">
                        <option value="tunai">Tunai</option>
                        <option value="transfer">Transfer</option>
                    </select>
                </div>
                
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Catatan (opsional)</label>
                    <textarea name="notes" rows="2"
                              class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                              placeholder="Catatan pembayaran..."></textarea>
                </div>
                
                <div class="flex justify-end gap-2">
                    <button type="button" onclick="closePaymentModal()" 
                            class="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300">
                        Batal
                    </button>
                    <button type="submit" 
                            class="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700">
                        Proses Pembayaran
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        function toggleInputForm() {
            const form = document.getElementById('inputForm');
            form.classList.toggle('hidden');
            if (!form.classList.contains('hidden')) {
                form.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        }
        
        function showPaymentModal(receivable) {
            document.getElementById('payment_receivable_id').value = receivable.id;
            document.getElementById('payment_customer').textContent = receivable.customer_name;
            document.getElementById('payment_ref').textContent = receivable.ref_code;
            document.getElementById('payment_remaining').textContent = 'Rp ' + parseFloat(receivable.remaining_amount).toLocaleString('id-ID');
            document.getElementById('payment_amount').max = receivable.remaining_amount;
            document.getElementById('payment_amount').value = receivable.remaining_amount;
            document.getElementById('paymentModal').classList.remove('hidden');
        }
        
        function closePaymentModal() {
            document.getElementById('paymentModal').classList.add('hidden');
        }
        
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                closePaymentModal();
                const form = document.getElementById('inputForm');
                if (form && !form.classList.contains('hidden')) {
                    form.classList.add('hidden');
                }
            }
        });
    </script>
</body>
</html>
<?php $conn->close(); ?>