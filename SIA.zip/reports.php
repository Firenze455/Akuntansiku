<?php
require_once __DIR__ . '/includes/config.php';
checkLogin();
if (isAdmin()) {
    $_SESSION['error'] = 'Admin tidak memiliki akses ke halaman ini.';
    header('Location: manage_users.php');
    exit();
}
// Opsional: batasi akses laporan berdasarkan permission jurnal
requirePermission('journal', 'view');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan - Sistem Informasi Akuntansi</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <?php include __DIR__ . '/includes/header.php'; ?>
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-6">
        <div class="mb-6 flex items-center justify-between">
            <h2 class="text-2xl font-bold text-gray-800">Laporan</h2>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <!-- Jurnal Umum -->
            <div class="bg-white rounded-lg shadow hover:shadow-md transition p-6">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="text-lg font-semibold text-gray-800">Jurnal Umum</h3>
                    <span class="text-xs px-2 py-1 rounded bg-blue-100 text-blue-700">Transaksi</span>
                </div>
                <p class="text-sm text-gray-600 mb-4">Lihat dan filter transaksi jurnal umum.</p>
                <div class="flex gap-3">
                    <a href="journal.php" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Buka</a>
                <a href="exports/export_journal.php" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">Export Excel</a>
                </div>
            </div>

            <!-- Buku Besar -->
            <div class="bg-white rounded-lg shadow hover:shadow-md transition p-6">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="text-lg font-semibold text-gray-800">Buku Besar</h3>
                    <span class="text-xs px-2 py-1 rounded bg-purple-100 text-purple-700">Ringkasan Akun</span>
                </div>
                <p class="text-sm text-gray-600 mb-4">Lihat saldo berjalan per akun, lengkap dengan filter.</p>
                <div class="flex gap-3">
                    <a href="ledger.php" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Buka</a>
                <a href="exports/export_ledger.php" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">Export Excel</a>
                </div>
            </div>

            <!-- Neraca Saldo -->
            <div class="bg-white rounded-lg shadow hover:shadow-md transition p-6">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="text-lg font-semibold text-gray-800">Neraca Saldo</h3>
                    <span class="text-xs px-2 py-1 rounded bg-blue-100 text-blue-700">Report</span>
                </div>
                <p class="text-sm text-gray-600 mb-4">Ringkasan saldo debit/kredit per akun.</p>
                <div class="flex gap-3">
                    <a href="trial_balance.php" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Buka</a>
                <a href="exports/export_trial_balance.php" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">Export Excel</a>
                </div>
            </div>

            <!-- [BARU] Jurnal Penyesuaian -->
            <div class="bg-white rounded-lg shadow hover:shadow-md transition p-6">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="text-lg font-semibold text-gray-800">Jurnal Penyesuaian</h3>
                    <span class="text-xs px-2 py-1 rounded bg-gray-100 text-gray-700">Segera</span>
                </div>
                <p class="text-sm text-gray-600 mb-4">Pencatatan penyesuaian akhir periode.</p>
                <div class="flex gap-3">
                    <button class="bg-gray-300 text-gray-700 px-4 py-2 rounded cursor-not-allowed">Buka</button>
                    <button class="bg-gray-300 text-gray-700 px-4 py-2 rounded cursor-not-allowed">Export Excel</button>
                </div>
            </div>

            <!-- [BARU] Buku Besar Setelah Penyesuaian (BBSP) -->
            <div class="bg-white rounded-lg shadow hover:shadow-md transition p-6">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="text-lg font-semibold text-gray-800">Buku Besar Setelah Penyesuaian (BBSP)</h3>
                    <span class="text-xs px-2 py-1 rounded bg-gray-100 text-gray-700">Segera</span>
                </div>
                <p class="text-sm text-gray-600 mb-4">Saldo berjalan per akun setelah penyesuaian.</p>
                <div class="flex gap-3">
                    <button class="bg-gray-300 text-gray-700 px-4 py-2 rounded cursor-not-allowed">Buka</button>
                    <button class="bg-gray-300 text-gray-700 px-4 py-2 rounded cursor-not-allowed">Export Excel</button>
                </div>
            </div>

            <!-- [BARU] Neraca Saldo Setelah Penyesuaian (NSSP) -->
            <div class="bg-white rounded-lg shadow hover:shadow-md transition p-6">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="text-lg font-semibold text-gray-800">Neraca Saldo Setelah Penyesuaian (NSSP)</h3>
                    <span class="text-xs px-2 py-1 rounded bg-gray-100 text-gray-700">Segera</span>
                </div>
                <p class="text-sm text-gray-600 mb-4">Daftar saldo setelah seluruh penyesuaian.</p>
                <div class="flex gap-3">
                    <button class="bg-gray-300 text-gray-700 px-4 py-2 rounded cursor-not-allowed">Buka</button>
                    <button class="bg-gray-300 text-gray-700 px-4 py-2 rounded cursor-not-allowed">Export Excel</button>
                </div>
            </div>

            <!-- [BARU] Laporan Laba Rugi -->
            <div class="bg-white rounded-lg shadow hover:shadow-md transition p-6">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="text-lg font-semibold text-gray-800">Laporan Laba Rugi</h3>
                    <span class="text-xs px-2 py-1 rounded bg-gray-100 text-gray-700">Segera</span>
                </div>
                <p class="text-sm text-gray-600 mb-4">Rangkuman pendapatan dan beban periode.</p>
                <div class="flex gap-3">
                    <button class="bg-gray-300 text-gray-700 px-4 py-2 rounded cursor-not-allowed">Buka</button>
                    <button class="bg-gray-300 text-gray-700 px-4 py-2 rounded cursor-not-allowed">Export Excel</button>
                </div>
            </div>

            <!-- [BARU] Laporan Ekuitas -->
            <div class="bg-white rounded-lg shadow hover:shadow-md transition p-6">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="text-lg font-semibold text-gray-800">Laporan Ekuitas</h3>
                    <span class="text-xs px-2 py-1 rounded bg-gray-100 text-gray-700">Segera</span>
                </div>
                <p class="text-sm text-gray-600 mb-4">Perubahan ekuitas pemilik selama periode.</p>
                <div class="flex gap-3">
                    <button class="bg-gray-300 text-gray-700 px-4 py-2 rounded cursor-not-allowed">Buka</button>
                    <button class="bg-gray-300 text-gray-700 px-4 py-2 rounded cursor-not-allowed">Export Excel</button>
                </div>
            </div>

            <!-- [BARU] Neraca Akhir -->
            <div class="bg-white rounded-lg shadow hover:shadow-md transition p-6">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="text-lg font-semibold text-gray-800">Neraca Akhir</h3>
                    <span class="text-xs px-2 py-1 rounded bg-gray-100 text-gray-700">Segera</span>
                </div>
                <p class="text-sm text-gray-600 mb-4">Posisi aset, liabilitas, dan modal pada akhir periode.</p>
                <div class="flex gap-3">
                    <button class="bg-gray-300 text-gray-700 px-4 py-2 rounded cursor-not-allowed">Buka</button>
                    <button class="bg-gray-300 text-gray-700 px-4 py-2 rounded cursor-not-allowed">Export Excel</button>
                </div>
            </div>
        </div>
    </div>
</body>
</html>