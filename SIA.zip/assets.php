<?php
require_once __DIR__ . '/includes/config.php';
checkLogin();
if (isAdmin()) {
    $_SESSION['error'] = 'Admin tidak memiliki akses ke halaman ini.';
    header('Location: manage_users.php');
    exit();
}

$conn = getDBConnection();
$success = isset($_SESSION['success']) ? $_SESSION['success'] : '';
$error = isset($_SESSION['error']) ? $_SESSION['error'] : '';
unset($_SESSION['success'], $_SESSION['error']);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_asset'])) {
    $name = $_POST['asset_name'];
    $category = $_POST['category'];
    $purchase_date = $_POST['purchase_date'];
    $purchase_price = $_POST['purchase_price'];
    $current_value = $_POST['current_value'] ?: $purchase_price;
    $user_id = $_SESSION['user_id'];
    
    $status = isSupervisor() ? 'approved' : 'pending';
    
    // Insert asset
    $stmt = $conn->prepare("INSERT INTO assets (asset_name, category, purchase_date, purchase_price, current_value, status, created_by) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssddsi", $name, $category, $purchase_date, $purchase_price, $current_value, $status, $user_id);
    
    if ($stmt->execute()) {
        $asset_id = $stmt->insert_id;
        
        // Jika supervisor, langsung buat jurnal
        if ($status === 'approved') {
            // Create journal entry
            $description = "Pembelian " . $name;
            $stmt2 = $conn->prepare("INSERT INTO general_journal (journal_date, description, reference_id, reference_type) VALUES (?, ?, ?, 'asset')");
            $stmt2->bind_param("ssi", $purchase_date, $description, $asset_id);
            $stmt2->execute();
            $journal_id = $stmt2->insert_id;
            
            // Debit Asset
            $account_code = $category == 'peralatan' ? '1-1400' : '1-1300';
            $account_name = $category == 'peralatan' ? 'Peralatan' : 'Perlengkapan';
            $stmt3 = $conn->prepare("INSERT INTO journal_entries (journal_id, account_code, account_name, debit, credit) VALUES (?, ?, ?, ?, 0)");
            $stmt3->bind_param("issd", $journal_id, $account_code, $account_name, $purchase_price);
            $stmt3->execute();
            
            // Credit Kas
            $account_code = '1-1100';
            $account_name = 'Kas';
            $stmt3 = $conn->prepare("INSERT INTO journal_entries (journal_id, account_code, account_name, debit, credit) VALUES (?, ?, ?, 0, ?)");
            $stmt3->bind_param("issd", $journal_id, $account_code, $account_name, $purchase_price);
            $stmt3->execute();
            
            $success = 'Aset berhasil ditambahkan!';
        } else {
            $success = 'Aset berhasil diinput dan menunggu approval!';
        }
    } else {
        $error = 'Gagal menambahkan aset!';
    }
}

// Get filter
$filter_status = $_GET['status'] ?? '';
$filter_category = $_GET['category'] ?? '';

// Build query
$query = "SELECT a.*, u.full_name as creator_name 
          FROM assets a 
          LEFT JOIN users u ON a.created_by = u.id 
          WHERE 1=1";

$params = [];
$types = "";

if (!empty($filter_status)) {
    $query .= " AND a.status = ?";
    $params[] = $filter_status;
    $types .= "s";
}

if (!empty($filter_category)) {
    $query .= " AND a.category = ?";
    $params[] = $filter_category;
    $types .= "s";
}

$query .= " ORDER BY a.purchase_date DESC, a.created_at DESC";

// Execute query
if (!empty($params)) {
    $stmt = $conn->prepare($query);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $assets = $stmt->get_result();
} else {
    $assets = $conn->query($query);
}

// Count pending for supervisor
$pending_count = 0;
if (isSupervisor()) {
    $result = $conn->query("SELECT COUNT(*) as count FROM assets WHERE status = 'pending'");
    $pending_count = $result->fetch_assoc()['count'];
}

// Flag untuk membuka form via query string
$open_form = isset($_GET['new']) && $_GET['new'] === '1';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aset - Sistem Informasi Akuntansi</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <?php include __DIR__ . '/includes/header.php'; ?>
    
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-6">
        <!-- Alert Messages -->
        <?php if ($success): ?>
            <div class="mb-4 p-4 bg-green-100 border border-green-400 text-green-700 rounded-lg">
                <?php echo $success; ?>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="mb-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded-lg">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <!-- Page Header -->
        <div class="mb-6 flex justify-between items-center">
            <div>
                <h2 class="text-2xl font-bold text-gray-800">Manajemen Aset</h2>
                <p class="text-gray-600">Kelola aset perusahaan</p>
                <?php if (isSupervisor() && $pending_count > 0): ?>
                    <div class="mt-2 inline-block bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-sm font-medium">
                        🔔 <?php echo $pending_count; ?> aset menunggu approval
                    </div>
                <?php endif; ?>
            </div>
            <div class="flex gap-3">
                <button onclick="toggleInputForm()" class="bg-blue-600 text-white px-6 py-2.5 rounded-lg hover:bg-blue-700 transition-colors font-medium flex items-center gap-2">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
                    </svg>
                    Input Aset
                </button>
                <a href="exports/export_assets.php" target="_blank" 
                   class="bg-green-600 text-white px-6 py-2.5 rounded-lg hover:bg-green-700 transition-colors font-medium flex items-center gap-2">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                    </svg>
                    Export
                </a>
            </div>
        </div>
        
        <!-- Input Form -->
        <div id="inputForm" class="<?php echo $open_form ? '' : 'hidden'; ?> mb-6 bg-white rounded-lg shadow-lg p-6 border-2 border-blue-500">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-lg font-semibold text-gray-800">Input Aset Baru</h3>
                <button onclick="toggleInputForm()" class="text-gray-500 hover:text-gray-700">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>
            <form method="POST" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                <div>
                    <label class="block text-xs font-medium text-gray-700 mb-1">Nama Aset</label>
                    <input type="text" name="asset_name" required
                           class="w-full px-3 py-2 text-sm border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                           placeholder="Contoh: Laptop HP">
                </div>
                
                <div>
                    <label class="block text-xs font-medium text-gray-700 mb-1">Kategori</label>
                    <select name="category" required
                            class="w-full px-3 py-2 text-sm border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500">
                        <option value="peralatan">Peralatan</option>
                        <option value="perlengkapan">Perlengkapan</option>
                    </select>
                </div>
                
                <div>
                    <label class="block text-xs font-medium text-gray-700 mb-1">Tanggal Pembelian</label>
                    <input type="date" name="purchase_date" value="<?php echo date('Y-m-d'); ?>" required
                           class="w-full px-3 py-2 text-sm border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500">
                </div>
                
                <div>
                    <label class="block text-xs font-medium text-gray-700 mb-1">Harga Pembelian</label>
                    <input type="number" name="purchase_price" step="1" min="1" required
                           class="w-full px-3 py-2 text-sm border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                           placeholder="5000000">
                </div>
                
                <div>
                    <label class="block text-xs font-medium text-gray-700 mb-1">Nilai Sekarang</label>
                    <input type="number" name="current_value" step="1" min="0"
                           class="w-full px-3 py-2 text-sm border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                           placeholder="Kosongkan jika sama">
                </div>
                
                <div class="md:col-span-2 lg:col-span-1 flex items-end">
                    <button type="submit" name="add_asset"
                            class="w-full bg-green-600 text-white py-2 px-4 rounded-md hover:bg-green-700 transition-colors font-medium text-sm">
                        Simpan
                    </button>
                </div>
            </form>
        </div>
        
        <!-- Assets List with Inline Filters -->
        <div class="bg-white rounded-lg shadow">
            <!-- Inline Filter Bar -->
            <div class="p-4 bg-gray-50 border-b border-gray-200">
                <form method="GET" class="grid grid-cols-2 md:grid-cols-4 gap-3">
                    <div>
                        <select name="category" class="w-full px-3 py-2 text-sm border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500">
                            <option value="">Semua Kategori</option>
                            <option value="peralatan" <?php echo $filter_category === 'peralatan' ? 'selected' : ''; ?>>Peralatan</option>
                            <option value="perlengkapan" <?php echo $filter_category === 'perlengkapan' ? 'selected' : ''; ?>>Perlengkapan</option>
                        </select>
                    </div>
                    
                    <div>
                        <select name="status" class="w-full px-3 py-2 text-sm border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500">
                            <option value="">Semua Status</option>
                            <option value="pending" <?php echo $filter_status === 'pending' ? 'selected' : ''; ?>>Pending</option>
                            <option value="approved" <?php echo $filter_status === 'approved' ? 'selected' : ''; ?>>Approved</option>
                            <option value="rejected" <?php echo $filter_status === 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                        </select>
                    </div>
                    
                    <div class="col-span-2 flex gap-2">
                        <button type="submit" class="flex-1 bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors text-sm font-medium">
                            Filter
                        </button>
                        <a href="assets.php" class="flex-1 text-center bg-gray-200 text-gray-800 py-2 px-4 rounded-md hover:bg-gray-300 transition-colors text-sm font-medium">
                            Reset
                        </a>
                    </div>
                </form>
            </div>
            
            <!-- Asset List -->
            <div class="p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Daftar Aset</h3>
                <div class="space-y-3">
                    <?php if ($assets->num_rows > 0): ?>
                        <?php while ($row = $assets->fetch_assoc()): ?>
                            <div class="border-l-4 <?php 
                                echo $row['status'] === 'approved' ? 'border-green-500' : 
                                    ($row['status'] === 'rejected' ? 'border-red-500' : 'border-yellow-500'); 
                            ?> pl-4 py-3 bg-gray-50 rounded-r-lg hover:bg-gray-100 transition-colors">
                                <div class="flex items-start justify-between">
                                    <div class="flex-1">
                                        <h4 class="font-semibold text-gray-800"><?php echo htmlspecialchars($row['asset_name']); ?></h4>
                                        <p class="text-sm text-gray-500 mt-1">
                                            <span class="inline-block px-2 py-0.5 bg-purple-100 text-purple-800 rounded text-xs mr-2">
                                                <?php echo $row['category'] == 'peralatan' ? 'Peralatan' : 'Perlengkapan'; ?>
                                            </span>
                                            Dibeli: <?php echo formatTanggal($row['purchase_date']); ?>
                                            <?php if ($row['creator_name']): ?>
                                                <span class="text-xs">• oleh <?php echo htmlspecialchars($row['creator_name']); ?></span>
                                            <?php endif; ?>
                                        </p>
                                        <?php if ($row['status'] === 'rejected' && $row['rejection_reason']): ?>
                                            <p class="text-xs text-red-600 mt-1">❌ <?php echo htmlspecialchars($row['rejection_reason']); ?></p>
                                        <?php endif; ?>
                                    </div>
                                    <div class="text-right ml-4">
                                        <div class="flex gap-4">
                                            <div>
                                                <p class="text-xs text-gray-500">Harga Beli</p>
                                                <p class="font-medium text-gray-800"><?php echo formatRupiah($row['purchase_price']); ?></p>
                                            </div>
                                            <div>
                                                <p class="text-xs text-gray-500">Nilai Sekarang</p>
                                                <p class="font-medium text-green-600"><?php echo formatRupiah($row['current_value']); ?></p>
                                            </div>
                                        </div>
                                        <span class="inline-block mt-2 px-2 py-0.5 text-xs rounded-full <?php 
                                            echo $row['status'] === 'approved' ? 'bg-green-100 text-green-800' : 
                                                ($row['status'] === 'rejected' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'); 
                                        ?>">
                                            <?php echo ucfirst($row['status']); ?>
                                        </span>
                                    </div>
                                </div>
                                
                                <!-- Approval Buttons untuk Supervisor -->
                                <?php if (isSupervisor() && $row['status'] === 'pending'): ?>
                                    <div class="mt-3 flex gap-2">
                <form method="POST" action="handlers/approve_handler.php" class="inline">
                                            <input type="hidden" name="action" value="approve">
                                            <input type="hidden" name="type" value="asset">
                                            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                            <input type="hidden" name="redirect" value="assets.php">
                                            <button type="submit" onclick="return confirm('Approve aset ini?')"
                                                    class="text-xs bg-green-600 text-white px-4 py-1.5 rounded hover:bg-green-700 font-medium">
                                                ✓ Approve
                                            </button>
                                        </form>
                                        <button onclick="showRejectModal(<?php echo $row['id']; ?>, 'asset')"
                                                class="text-xs bg-red-600 text-white px-4 py-1.5 rounded hover:bg-red-700 font-medium">
                                            ✗ Reject
                                        </button>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p class="text-center text-gray-500 py-8">Belum ada aset yang terdaftar</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Reject Modal -->
    <div id="rejectModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
        <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">Alasan Penolakan</h3>
                <form method="POST" action="handlers/approve_handler.php" onsubmit="return validateRejectForm()">
                <input type="hidden" name="action" value="reject">
                <input type="hidden" name="type" id="reject_type">
                <input type="hidden" name="id" id="reject_id">
                <input type="hidden" name="redirect" value="assets.php">
                <textarea name="reason" id="reject_reason" required rows="3" 
                          class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                          placeholder="Masukkan alasan penolakan..."></textarea>
                <div class="flex justify-end gap-2 mt-4">
                    <button type="button" onclick="closeRejectModal()" 
                            class="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300">
                        Batal
                    </button>
                    <button type="submit" 
                            class="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700">
                        Reject
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        function toggleInputForm() {
            const form = document.getElementById('inputForm');
            form.classList.toggle('hidden');
            if (!form.classList.contains('hidden')) {
                form.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        }
        
        function showRejectModal(id, type) {
            document.getElementById('reject_id').value = id;
            document.getElementById('reject_type').value = type;
            document.getElementById('reject_reason').value = '';
            document.getElementById('rejectModal').classList.remove('hidden');
            
            setTimeout(() => {
                document.getElementById('reject_reason').focus();
            }, 100);
        }
        
        function closeRejectModal() {
            document.getElementById('rejectModal').classList.add('hidden');
            document.getElementById('reject_reason').value = '';
        }
        
        function validateRejectForm() {
            const reason = document.getElementById('reject_reason').value.trim();
            if (reason.length < 10) {
                alert('Alasan penolakan harus minimal 10 karakter!');
                return false;
            }
            return confirm('Yakin ingin MENOLAK aset ini?\n\nAlasan: ' + reason);
        }
        
        // Auto-open form if ?new=1 parameter exists
        <?php if ($open_form): ?>
        window.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('inputForm');
            if (form) {
                form.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        });
        <?php endif; ?>
        
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                closeRejectModal();
                const form = document.getElementById('inputForm');
                if (form && !form.classList.contains('hidden')) {
                    form.classList.add('hidden');
                }
            }
        });
    </script>
</body>
</html>
<?php $conn->close(); ?>