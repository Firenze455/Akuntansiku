<?php
require_once __DIR__ . '/includes/config.php';
checkLogin();
if (isAdmin()) {
    $_SESSION['error'] = 'Admin tidak memiliki akses ke halaman ini.';
    header('Location: manage_users.php');
    exit();
}

$conn = getDBConnection();

// Filters
$filter_date_from = $_GET['date_from'] ?? '';
$filter_date_to = $_GET['date_to'] ?? '';
$filter_account_code = $_GET['account_code'] ?? '';

// Build query with filters
$where_conditions = [];
$params = [];
$types = "";

if (!empty($filter_date_from)) {
    $where_conditions[] = "gj.journal_date >= ?";
    $params[] = $filter_date_from;
    $types .= "s";
}
if (!empty($filter_date_to)) {
    $where_conditions[] = "gj.journal_date <= ?";
    $params[] = $filter_date_to;
    $types .= "s";
}
if (!empty($filter_account_code)) {
    $where_conditions[] = "je.account_code LIKE ?";
    $params[] = $filter_account_code . '%';
    $types .= "s";
}

$query = "SELECT 
            je.id AS entry_id, 
            je.journal_id, 
            gj.journal_date, 
            gj.description AS journal_description,
            je.account_code, 
            je.account_name, 
            je.debit, 
            je.credit, 
            coa.account_type
          FROM journal_entries je
          LEFT JOIN general_journal gj ON je.journal_id = gj.id
          LEFT JOIN chart_of_accounts coa ON coa.account_code = je.account_code";

if (!empty($where_conditions)) {
    $query .= " WHERE " . implode(" AND ", $where_conditions);
}

$query .= " ORDER BY je.account_code ASC, gj.journal_date ASC, je.id ASC";

// Execute query
if (!empty($params)) {
    $stmt = $conn->prepare($query);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query($query);
}

// Group by account
$ledger = [];
while ($row = $result->fetch_assoc()) {
    $code = $row['account_code'];
    if (!isset($ledger[$code])) {
        $ledger[$code] = [
            'account_code' => $code,
            'account_name' => $row['account_name'],
            'account_type' => $row['account_type'] ?? null,
            'entries' => []
        ];
    }
    $ledger[$code]['entries'][] = [
        'date' => $row['journal_date'],
        'description' => $row['journal_description'],
        'debit' => (float)$row['debit'],
        'credit' => (float)$row['credit']
    ];
}

// Fallback tipe akun berdasarkan prefix kode
function inferAccountType($code) {
    $normalized = str_replace('-', '', $code);
    $first = substr($normalized, 0, 1);

    if ($first === '1') return 'aset';
    if ($first === '2') return 'liabilitas';
    if ($first === '3') return 'modal';
    if ($first === '4') return 'pendapatan';
    if ($first === '5') return 'beban';
    return null;
}
function isDebitNormal($type) {
    return in_array($type, ['aset','beban'], true);
}

// Accounts dropdown
$accounts = $conn->query("SELECT account_code, account_name FROM chart_of_accounts ORDER BY account_code");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Buku Besar - Sistem Informasi Akuntansi</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <?php include __DIR__ . '/includes/header.php'; ?>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-6">
        <div class="mb-6 flex items-center justify-between">
            <h2 class="text-2xl font-bold text-gray-800">Buku Besar</h2>
            <a href="exports/export_ledger.php<?php echo !empty($_SERVER['QUERY_STRING']) ? '?' . $_SERVER['QUERY_STRING'] : ''; ?>" 
               class="bg-green-600 text-white px-6 py-2.5 rounded-lg hover:bg-green-700 font-medium transition-colors">
                📥 Export Excel
            </a>
        </div>

        <!-- Filter Section (meniru Jurnal Umum) -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-6">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Filter Buku Besar</h3>
            <form method="GET" class="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Dari Tanggal</label>
                    <input type="date" name="date_from" value="<?php echo htmlspecialchars($filter_date_from); ?>"
                           class="w-full px-3 py-2 border border-gray-300 rounded-md">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Sampai Tanggal</label>
                    <input type="date" name="date_to" value="<?php echo htmlspecialchars($filter_date_to); ?>"
                           class="w-full px-3 py-2 border border-gray-300 rounded-md">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Kode Akun</label>
                    <select name="account_code" class="w-full px-3 py-2 border border-gray-300 rounded-md">
                        <option value="">Semua Akun</option>
                        <?php while ($acc = $accounts->fetch_assoc()): ?>
                            <option value="<?php echo $acc['account_code']; ?>"
                                    <?php echo $filter_account_code == $acc['account_code'] ? 'selected' : ''; ?>>
                                <?php echo $acc['account_code'] . ' - ' . $acc['account_name']; ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="flex items-end gap-2">
                    <button type="submit" class="flex-1 bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700">
                        🔍 Filter
                    </button>
                    <a href="ledger.php" class="bg-gray-200 text-gray-700 px-6 py-2 rounded-md hover:bg-gray-300">
                        Reset
                    </a>
                </div>
            </form>
        </div>

        <!-- Ledger Tables per Akun -->
        <?php if (!empty($ledger)): ?>
            <?php foreach ($ledger as $code => $acct): ?>
                <?php 
                    $type = $acct['account_type'] ?: inferAccountType($acct['account_code']);
                    $balance = 0.0;
                    $normalDebit = isDebitNormal($type);
                ?>
                <div class="bg-white rounded-lg shadow overflow-hidden mb-6">
                    <div class="px-4 py-3 bg-gray-50 border-b">
                        <div class="font-bold text-gray-800">
                            Akun: <?php echo htmlspecialchars($acct['account_code']); ?> — <?php echo htmlspecialchars($acct['account_name']); ?>
                        </div>
                        <div class="text-sm text-gray-600">
                            Tipe: <?php echo htmlspecialchars($type ?: '-'); ?> • Saldo Normal: <?php echo $normalDebit ? 'Debit' : 'Kredit'; ?>
                        </div>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="w-full border-collapse">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="border border-gray-300 px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase">Tanggal</th>
                                    <th class="border border-gray-300 px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase">Kode</th>
                                    <th class="border border-gray-300 px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase">Nama Akun</th>
                                    <th class="border border-gray-300 px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase">Keterangan</th>
                                    <th class="border border-gray-300 px-4 py-3 text-right text-xs font-medium text-gray-700 uppercase">Debit</th>
                                    <th class="border border-gray-300 px-4 py-3 text-right text-xs font-medium text-gray-700 uppercase">Kredit</th>
                                    <th class="border border-gray-300 px-4 py-3 text-right text-xs font-medium text-gray-700 uppercase">Saldo</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($acct['entries'] as $entry): ?>
                                    <?php
                                        if ($normalDebit) {
                                            $balance += ($entry['debit'] - $entry['credit']);
                                        } else {
                                            $balance += ($entry['credit'] - $entry['debit']);
                                        }
                                    ?>
                                    <tr class="hover:bg-gray-50">
                                        <td class="border border-gray-300 px-4 py-2 text-sm">
                                            <?php echo formatTanggal($entry['date']); ?>
                                        </td>
                                        <td class="border border-gray-300 px-4 py-2 text-sm text-gray-700">
                                            <?php echo htmlspecialchars(formatAccountCodeDisplay($acct['account_code'])); ?>
                                        </td>
                                        <td class="border border-gray-300 px-4 py-2 text-sm">
                                            <?php echo htmlspecialchars($acct['account_name']); ?>
                                        </td>
                                        <td class="border border-gray-300 px-4 py-2 text-sm text-gray-600">
                                            <?php echo htmlspecialchars($entry['description']); ?>
                                        </td>
                                        <td class="border border-gray-300 px-4 py-2 text-sm text-right font-medium">
                                            <?php echo $entry['debit'] > 0 ? formatRupiah($entry['debit']) : ''; ?>
                                        </td>
                                        <td class="border border-gray-300 px-4 py-2 text-sm text-right font-medium">
                                            <?php echo $entry['credit'] > 0 ? formatRupiah($entry['credit']) : ''; ?>
                                        </td>
                                        <td class="border border-gray-300 px-4 py-2 text-sm text-right font-bold">
                                            <?php echo formatRupiah($balance); ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                <tr class="bg-blue-50 font-bold">
                                    <td colspan="6" class="border border-gray-300 px-4 py-2 text-sm text-right">
                                        SALDO AKHIR
                                    </td>
                                    <td class="border border-gray-300 px-4 py-2 text-sm text-right text-blue-700">
                                        <?php echo formatRupiah($balance); ?>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="bg-white rounded-lg shadow p-6 text-center text-gray-600">
                Belum ada jurnal yang tercatat atau filter tidak menghasilkan data.
            </div>
        <?php endif; ?>
    </div>
</body>
</html>