# SIA (Sistem Informasi Akuntansi)

README ini menjelaskan keseluruhan sistem, fungsionalitas utama, cara penggunaan dasar, dan penjelasan detail isi tiap direktori setelah reorganisasi.

## Gambaran Sistem
SIA adalah aplikasi berbasis PHP sederhana untuk membantu kebutuhan akuntansi operasional kecil/menengah. Fitur inti mencakup:

- Autentikasi & manajemen pengguna (role: admin, supervisor, staff, head).
- Manajemen Cashflow (pencatatan transaksi pemasukan & pengeluaran).
- Modul Piutang (receivables) termasuk pembuatan invoice, pembayaran, histori, dan approval.
- Modul Hutang (payables) termasuk pencatatan hutang, pembayaran, histori, dan approval.
- Manajemen Aset (assets) dan perekaman jurnal terkait saat aset disetujui.
- Jurnal Umum (general journal) dan entri jurnal (journal entries) untuk pencatatan akuntansi.
- Kontak: Customer dan Supplier.
- Fitur export (mis. export ke Excel/CSV) untuk laporan jurnal, aset, cashflow, piutang, hutang.
- Utilitas admin (fix data, reset DB tertentu — sensitif dan sebaiknya hanya digunakan oleh admin).

System flow singkat:
- Staff membuat atau menginput data transaksi/aset/piutang/hutang.
- Jika peran supervisor diperlukan, supervisor memberikan approval; setelah approval, jurnal otomatis dibuat untuk beberapa tindakan.

## Fitur Utama per Modul
- Auth: login, manage users, setup admin.
- Cashflow: buat transaksi (tunai / piutang / hutang), otomatis membuat receivable/payable jika diperlukan, dan otomatis membuat jurnal saat transaksi di-approve.
- Receivables: pembuatan referensi piutang, pencatatan pembayaran, histori, approval/reject/return.
- Payables: pembuatan referensi hutang, pencatatan pembayaran (term & DP), histori, approval/reject/return.
- Assets: input aset, approval supervisor, pembuatan jurnal saat aset disetujui.
- Journal: tampilan jurnal umum, filter, dan export.
- Contacts: daftar/CRUD customers & suppliers.
- Exports: skrip terpisah untuk mengekspor data (CSV/XLS) untuk modul terkait.

## Instalasi & Menjalankan (Development)

Prasyarat:
- PHP (7.4+ disarankan) terpasang dan tersedia di PATH.
- MySQL/MariaDB atau DB lain yang kompatibel, serta konfigurasi di `includes/config.php`.

Langkah singkat (development):

1. Pastikan konfigurasi database ada dan benar di `includes/config.php` (host, user, password, dbname).
2. Dari root project (misal: `c:\Users\David Augusto\Documents\sia`), jalankan server built-in PHP untuk development:

```powershell
cd 'c:\Users\David Augusto\Documents\sia'
php -S localhost:8000
```

3. Akses aplikasi lewat browser: http://localhost:8000/

Catatan keamanan: utilitas seperti `secret_reset_database.php` berisiko bila lingkungan non-lokal; gunakan hanya di lingkungan development atau dengan proteksi ketat.

## Struktur Direktori dan Penjelasan Isi (per folder)

Root (project root)
- `README.md` — dokumentasi (file ini).

`auth/` — autentikasi & user management
- `login.php` — halaman login.
- `logout.php` — logout.
- `manage_users.php` — halaman CRUD user (hanya admin).
- `setup_admin.php` — skrip setup admin awal.
- `generate_password.php` — utilitas pembuatan password sementara.

`modules/` — modul fungsional aplikasi, tiap modul memiliki subfolder
- `modules/cashflow/` — `cashflow.php` (halaman manajemen cashflow), handler terkait.
- `modules/receivables/` — semua halaman dan handler terkait piutang (approve, payment, return, history, list).
- `modules/payables/` — semua halaman dan handler terkait hutang (approve, payment, return, history, list).
- `modules/assets/` — `assets.php` dan fitur terkait aset, approval, jurnal.
- `modules/journal/` — `journal.php` untuk melihat jurnal umum dan entri jurnal.
- `modules/contacts/` — `customers.php`, `suppliers.php` untuk manajemen kontak.

`includes/` — file yang di-include secara global
- `config.php` — konfigurasi aplikasi dan fungsi helper (DB connection, session handling, helper functions). PENTING: pastikan konfigurasi DB benar.
- `header.php` — template header/navigation yang di-include di halaman-halaman aplikasi.

`exports/` — skrip export data (dipanggil dari UI)
- `export_assets.php`, `export_cashflow.php`, `export_journal.php`, `export_payables.php`, `export_receivables.php`.

`utils/` — utilitas dan handler
- `approve_handler.php`, `edit_handler.php`, `approve_handler.php` (untuk action approve/reject/return/resubmit), `fix_data.php`, `secret_reset_database.php` dan lain-lain.

`assets/` (tidak dibuat otomatis oleh refactor) — rekomendasi: pindahkan CSS/JS/Images ke folder ini di masa depan untuk management asset statis.

Catatan: banyak file telah dipindahkan dari root ke struktur di atas; referensi include telah diperbarui untuk menggunakan path relatif berbasis `__DIR__`.

## Verifikasi setelah refactor
- Buka `auth/login.php` untuk memastikan halaman login muncul tanpa error path.
- Cek halaman-halaman utama (Cashflow, Receivables, Payables, Assets, Journal, Contacts) — jika salah satu menunjukkan error "failed to open stream: No such file or directory", buka file tersebut dan periksa include/require path.
- Jalankan scan PowerShell bila perlu untuk menemukan file yang masih menggunakan include tanpa path:

```powershell
cd 'c:\Users\David Augusto\Documents\sia'
Select-String -Pattern "require_once\s+['\"]config.php['\"]|include\s+['\"]header.php['\"]" -Path . -Recurse
```

## Rekomendasi & Langkah Selanjutnya
- Centralize base paths: tambahkan konstanta seperti `BASE_DIR` di `includes/config.php` untuk memudahkan include di masa depan.
- Pindahkan file statis (CSS/JS/Images) ke `assets/` atau `public/` dan perbarui `includes/header.php` untuk memuat asset dari folder tersebut.
- Tambahkan kontrol keamanan untuk utilitas sensitif (IP whitelist, autentikasi tambahan).
- Tambahkan skrip kecil (PowerShell / PHP) untuk memeriksa semua include/require agar mengikuti pola yang konsisten.

Jika Anda ingin, saya bisa:
- Mengimplementasikan `BASE_DIR` di `includes/config.php` dan merubah includes menjadi `require_once BASE_DIR . '/includes/config.php'` untuk konsistensi.
- Membuat folder `assets/` dan memperbarui `header.php` untuk menunjuk ke CSS/JS dari folder tersebut.
- Menjalankan sekali lagi scan otomatis dan memperbaiki sisa masalah path.

-- Selesai

Dokumentasi ini menggantikan README yang sebelumnya berisi catatan perubahan struktur folder — sekarang README berfokus pada gambaran sistem, penggunaan, dan penjelasan setiap folder.
