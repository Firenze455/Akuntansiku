<?php
require_once __DIR__ . '/includes/config.php';
checkLogin();
if (isAdmin()) {
    $_SESSION['error'] = 'Admin tidak memiliki akses ke halaman ini.';
    header('Location: manage_users.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>External - Sistem Informasi Akuntansi</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <?php include __DIR__ . '/includes/header.php'; ?>
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-6">
        <div class="mb-6 flex items-center justify-between">
            <h2 class="text-2xl font-bold text-gray-800">External</h2>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div class="bg-white rounded-lg shadow hover:shadow-md transition p-6">
                <div class="flex items-center justify-between mb-2">
                    <h3 class="text-lg font-semibold text-gray-800">Customer</h3>
                    <span class="text-xs px-2 py-1 rounded bg-blue-100 text-blue-700">Kontak</span>
                </div>
                <p class="text-sm text-gray-600 mb-4">Kelola data customer dan informasi terkait.</p>
                <a href="customers.php" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Buka</a>
            </div>

            <div class="bg-white rounded-lg shadow hover:shadow-md transition p-6">
                <div class="flex items-center justify-between mb-2">
                    <h3 class="text-lg font-semibold text-gray-800">Supplier</h3>
                    <span class="text-xs px-2 py-1 rounded bg-yellow-100 text-yellow-700">Kontak</span>
                </div>
                <p class="text-sm text-gray-600 mb-4">Kelola data supplier dan informasi terkait.</p>
                <a href="suppliers.php" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Buka</a>
            </div>
        </div>
    </div>
</body>
</html>