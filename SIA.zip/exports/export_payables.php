<?php
require_once __DIR__ . '/../includes/config.php';
checkLogin();

$conn = getDBConnection();

// Set header untuk download Excel
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename="Laporan_Hutang_' . date('Y-m-d') . '.xls"');
header('Cache-Control: max-age=0');

// Get all payables
$payables = $conn->query("SELECT p.*, u.full_name as creator_name 
                          FROM payables p 
                          LEFT JOIN users u ON p.created_by = u.id 
                          ORDER BY p.status, p.due_date ASC");

// Calculate totals
$summary = $conn->query("SELECT 
    SUM(total_amount) as total,
    SUM(paid_amount) as paid,
    SUM(remaining_amount) as remaining,
    COUNT(CASE WHEN status = 'paid' THEN 1 END) as paid_count,
    COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_count,
    COUNT(CASE WHEN status = 'partial' THEN 1 END) as partial_count,
    COUNT(CASE WHEN status = 'overdue' THEN 1 END) as overdue_count
    FROM payables")->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Laporan Hutang</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #000;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #C00000;
            color: white;
            font-weight: bold;
        }
        .text-right {
            text-align: right;
        }
        .text-center {
            text-align: center;
        }
        .header {
            text-align: center;
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 20px;
        }
        .date-info {
            text-align: center;
            font-size: 12px;
            margin-bottom: 20px;
        }
        .status-pending {
            background-color: #FFF3CD;
        }
        .status-partial {
            background-color: #D1ECF1;
        }
        .status-paid {
            background-color: #D4EDDA;
        }
        .status-overdue {
            background-color: #F8D7DA;
        }
    </style>
</head>
<body>
    <div class="header">
        LAPORAN HUTANG USAHA<br>
        SISTEM INFORMASI AKUNTANSI
    </div>
    
    <div class="date-info">
        Dicetak tanggal: <?php echo date('d/m/Y H:i:s'); ?>
    </div>
    
    <!-- Summary Box -->
    <table style="width: 600px; margin: 20px auto;">
        <tr>
            <td style="background-color: #FCE4D6;"><strong>Total Hutang</strong></td>
            <td class="text-right" style="color: red;"><strong>Rp <?php echo number_format($summary['total'], 0, ',', '.'); ?></strong></td>
        </tr>
        <tr>
            <td style="background-color: #D4EDDA;"><strong>Total Terbayar</strong></td>
            <td class="text-right" style="color: green;"><strong>Rp <?php echo number_format($summary['paid'], 0, ',', '.'); ?></strong></td>
        </tr>
        <tr>
            <td style="background-color: #FCE4D6;"><strong>Sisa Hutang</strong></td>
            <td class="text-right" style="color: red;"><strong>Rp <?php echo number_format($summary['remaining'], 0, ',', '.'); ?></strong></td>
        </tr>
        <tr>
            <td colspan="2" style="background-color: #F2F2F2; text-align: center;">
                <strong>Status: </strong>
                Lunas: <?php echo $summary['paid_count']; ?> | 
                Partial: <?php echo $summary['partial_count']; ?> | 
                Pending: <?php echo $summary['pending_count']; ?> | 
                Overdue: <?php echo $summary['overdue_count']; ?>
            </td>
        </tr>
    </table>
    
    <br>
    
    <table>
        <thead>
            <tr>
                <th class="text-center">No</th>
                <th>Ref Code</th>
                <th>Supplier</th>
                <th>Keterangan</th>
                <th class="text-center">Tanggal</th>
                <th class="text-center">Jatuh Tempo</th>
                <th class="text-right">Total (Rp)</th>
                <th class="text-right">Terbayar (Rp)</th>
                <th class="text-right">Sisa (Rp)</th>
                <th class="text-center">Status</th>
                <th>Dibuat Oleh</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($payables->num_rows > 0): ?>
                <?php 
                $no = 1;
                while ($row = $payables->fetch_assoc()):
                    $status_class = 'status-' . $row['status'];
                ?>
                    <tr class="<?php echo $status_class; ?>">
                        <td class="text-center"><?php echo $no++; ?></td>
                        <td><?php echo htmlspecialchars($row['ref_code']); ?></td>
                        <td><?php echo htmlspecialchars($row['supplier_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['description']); ?></td>
                        <td class="text-center"><?php echo date('d/m/Y', strtotime($row['created_at'])); ?></td>
                        <td class="text-center"><?php echo date('d/m/Y', strtotime($row['due_date'])); ?></td>
                        <td class="text-right"><?php echo number_format($row['total_amount'], 0, ',', '.'); ?></td>
                        <td class="text-right" style="color: green;"><?php echo number_format($row['paid_amount'], 0, ',', '.'); ?></td>
                        <td class="text-right" style="color: red;"><?php echo number_format($row['remaining_amount'], 0, ',', '.'); ?></td>
                        <td class="text-center"><?php echo strtoupper($row['status']); ?></td>
                        <td><?php echo htmlspecialchars($row['creator_name']); ?></td>
                    </tr>
                <?php endwhile; ?>
                
                <!-- Total Row -->
                <tr style="background-color: #F2F2F2; font-weight: bold;">
                    <td colspan="6" class="text-center"><strong>TOTAL</strong></td>
                    <td class="text-right"><strong><?php echo number_format($summary['total'], 0, ',', '.'); ?></strong></td>
                    <td class="text-right" style="color: green;"><strong><?php echo number_format($summary['paid'], 0, ',', '.'); ?></strong></td>
                    <td class="text-right" style="color: red;"><strong><?php echo number_format($summary['remaining'], 0, ',', '.'); ?></strong></td>
                    <td colspan="2"></td>
                </tr>
            <?php else: ?>
                <tr>
                    <td colspan="11" class="text-center">Belum ada hutang yang terdaftar</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    
    <br><br>
    
    <table style="border: none; width: 100%;">
        <tr style="border: none;">
            <td style="border: none; width: 70%;"></td>
            <td style="border: none; text-align: center;">
                <p>Mengetahui,</p>
                <br><br><br>
                <p>_____________________</p>
                <p><strong><?php echo htmlspecialchars($_SESSION['full_name']); ?></strong></p>
            </td>
        </tr>
    </table>
</body>
</html>
<?php $conn->close(); ?>
