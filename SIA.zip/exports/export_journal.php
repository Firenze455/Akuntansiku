<?php
require_once __DIR__ . '/../includes/config.php';
checkLogin();

$conn = getDBConnection();

// Set header untuk download Excel
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename="Jurnal_Umum_' . date('Y-m-d') . '.xls"');
header('Cache-Control: max-age=0');

// Get all journal entries with details
$query = "SELECT gj.id, gj.journal_date, gj.description, 
          je.account_code, je.account_name, je.debit, je.credit
          FROM general_journal gj
          LEFT JOIN journal_entries je ON gj.id = je.journal_id
          ORDER BY gj.journal_date DESC, gj.created_at DESC, je.id ASC";

$result = $conn->query($query);

// Group entries by journal_id
$journals = [];
while ($row = $result->fetch_assoc()) {
    $journal_id = $row['id'];
    if (!isset($journals[$journal_id])) {
        $journals[$journal_id] = [
            'date' => $row['journal_date'],
            'description' => $row['description'],
            'entries' => []
        ];
    }
    $journals[$journal_id]['entries'][] = [
        'account_code' => $row['account_code'],
        'account_name' => $row['account_name'],
        'debit' => $row['debit'],
        'credit' => $row['credit']
    ];
}

// Output Excel
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Jurnal Umum</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #000;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #4472C4;
            color: white;
            font-weight: bold;
        }
        .text-right {
            text-align: right;
        }
        .text-center {
            text-align: center;
        }
        .header {
            text-align: center;
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 20px;
        }
        .date-info {
            text-align: center;
            font-size: 12px;
            margin-bottom: 20px;
        }
        .total-row {
            background-color: #F2F2F2;
            font-weight: bold;
        }
        .indent {
            padding-left: 30px;
        }
    </style>
</head>
<body>
    <div class="header">
        JURNAL UMUM<br>
        SISTEM INFORMASI AKUNTANSI
    </div>
    
    <div class="date-info">
        Dicetak tanggal: <?php echo date('d/m/Y H:i:s'); ?>
    </div>
    
    <table>
        <thead>
            <tr>
                <th>Tanggal</th>
                <th>Kode Akun</th>
                <th>Keterangan</th>
                <th class="text-right">Debit (Rp)</th>
                <th class="text-right">Kredit (Rp)</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($journals) > 0): ?>
                <?php 
                $total_debit = 0;
                $total_credit = 0;
                ?>
                <?php foreach ($journals as $journal): ?>
                    <?php $firstRow = true; ?>
                    <?php 
                        // Urutkan entries berdasarkan kode akun (ascending)
                        $entries = $journal['entries'];
                        usort($entries, function($a, $b) {
                            return strcmp($a['account_code'], $b['account_code']);
                        });
                        foreach ($entries as $entry):
                    ?>
                        <tr>
                            <td class="text-center">
                                <?php if ($firstRow): ?>
                                    <?php echo date('d/m/Y', strtotime($journal['date'])); ?>
                                <?php endif; ?>
                            </td>
                            <td class="text-center">
                                <?php echo htmlspecialchars(formatAccountCodeDisplay($entry['account_code'])); ?>
                            </td>
                            <td <?php echo !$firstRow ? 'class="indent"' : ''; ?>>
                                <?php if ($firstRow): ?>
                                    <?php echo htmlspecialchars($journal['description']); ?>
                                <?php else: ?>
                                    <?php echo htmlspecialchars($entry['account_name']); ?>
                                <?php endif; ?>
                            </td>
                            <td class="text-right">
                                <?php 
                                if ($entry['debit'] > 0) {
                                    echo number_format($entry['debit'], 0, ',', '.');
                                    $total_debit += $entry['debit'];
                                } else {
                                    echo '-';
                                }
                                ?>
                            </td>
                            <td class="text-right">
                                <?php 
                                if ($entry['credit'] > 0) {
                                    echo number_format($entry['credit'], 0, ',', '.');
                                    $total_credit += $entry['credit'];
                                } else {
                                    echo '-';
                                }
                                ?>
                            </td>
                        </tr>
                        <?php $firstRow = false; ?>
                    <?php endforeach; ?>
                    <tr>
                        <td colspan="5" style="border: none; height: 5px;"></td>
                    </tr>
                <?php endforeach; ?>
                
                <!-- Total Row -->
                <tr class="total-row">
                    <td colspan="3" class="text-center"><strong>TOTAL</strong></td>
                    <td class="text-right"><strong><?php echo number_format($total_debit, 0, ',', '.'); ?></strong></td>
                    <td class="text-right"><strong><?php echo number_format($total_credit, 0, ',', '.'); ?></strong></td>
                </tr>
                
                <!-- Balance Check -->
                <tr>
                    <td colspan="3" class="text-center"><strong>SELISIH</strong></td>
                    <td colspan="2" class="text-center">
                        <strong>
                            <?php 
                            $balance = $total_debit - $total_credit;
                            if ($balance == 0) {
                                echo 'BALANCE ✓';
                            } else {
                                echo 'Rp ' . number_format(abs($balance), 0, ',', '.');
                            }
                            ?>
                        </strong>
                    </td>
                </tr>
            <?php else: ?>
                <tr>
                    <td colspan="5" class="text-center">Belum ada jurnal yang tercatat</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    
    <br><br>
    
    <table style="border: none; width: 100%;">
        <tr style="border: none;">
            <td style="border: none; width: 70%;"></td>
            <td style="border: none; text-align: center;">
                <p>Mengetahui,</p>
                <br><br><br>
                <p>_____________________</p>
                <p><strong><?php echo htmlspecialchars($_SESSION['full_name']); ?></strong></p>
            </td>
        </tr>
    </table>
</body>
</html>
<?php
$conn->close();
?>
