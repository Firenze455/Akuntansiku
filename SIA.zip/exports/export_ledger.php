<?php
require_once __DIR__ . '/../includes/config.php';
checkLogin();

$conn = getDBConnection();

// Set header untuk download Excel
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename="Buku_Besar_' . date('Y-m-d') . '.xls"');
header('Cache-Control: max-age=0');

// Ambil semua journal entries beserta tanggal dan uraian jurnal
// [BARU] Ambil filter dari query string agar sesuai dengan halaman web
$filter_date_from = $_GET['date_from'] ?? '';
$filter_date_to = $_GET['date_to'] ?? '';
$filter_account_code = $_GET['account_code'] ?? '';

$where_conditions = [];
$params = [];
$types = "";

if (!empty($filter_date_from)) {
    $where_conditions[] = "gj.journal_date >= ?";
    $params[] = $filter_date_from;
    $types .= "s";
}
if (!empty($filter_date_to)) {
    $where_conditions[] = "gj.journal_date <= ?";
    $params[] = $filter_date_to;
    $types .= "s";
}
if (!empty($filter_account_code)) {
    $where_conditions[] = "je.account_code LIKE ?";
    $params[] = $filter_account_code . '%';
    $types .= "s";
}

// ... existing code ...

// [UBAH] Query dasar + kondisi dinamis
$query = "SELECT 
            je.id AS entry_id, 
            je.journal_id, 
            gj.journal_date, 
            gj.description AS journal_description,
            je.account_code, 
            je.account_name, 
            je.debit, 
            je.credit, 
            coa.account_type
          FROM journal_entries je
          LEFT JOIN general_journal gj ON je.journal_id = gj.id
          LEFT JOIN chart_of_accounts coa ON coa.account_code = je.account_code";

if (!empty($where_conditions)) {
    $query .= " WHERE " . implode(" AND ", $where_conditions);
}

$query .= " ORDER BY je.account_code ASC, gj.journal_date ASC, je.id ASC";

// [UBAH] Eksekusi: gunakan prepared statement jika ada filter
if (!empty($params)) {
    $stmt = $conn->prepare($query);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query($query);
}

// Kelompokkan per akun
$ledger = [];
while ($row = $result->fetch_assoc()) {
    $code = $row['account_code'];
    if (!isset($ledger[$code])) {
        $ledger[$code] = [
            'account_code' => $code,
            'account_name' => $row['account_name'],
            'account_type' => $row['account_type'] ?? null,
            'entries' => []
        ];
    }
    $ledger[$code]['entries'][] = [
        'date' => $row['journal_date'],
        'description' => $row['journal_description'],
        'debit' => (float)$row['debit'],
        'credit' => (float)$row['credit']
    ];
}

// Fallback tipe akun jika tidak ada di chart_of_accounts
function inferAccountType($code) {
    if (strpos($code, '1-') === 0) return 'aset';
    if (strpos($code, '2-') === 0) return 'liabilitas';
    if (strpos($code, '3-') === 0) return 'modal';
    if (strpos($code, '4-') === 0) return 'pendapatan';
    if (strpos($code, '5-') === 0) return 'beban';
    return null;
}

function isDebitNormal($type) {
    return in_array($type, ['aset','beban'], true);
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Buku Besar</title>
    <style>
        body {
            font-family: Calibri, Arial, sans-serif;
            font-size: 12px;
        }
        .header {
            text-align: center;
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .date-info {
            text-align: center;
            font-size: 12px;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            table-layout: fixed;
            margin-bottom: 25px;
        }
        th, td {
            border: 1px solid #333;
            padding: 6px 8px;
            vertical-align: top;
            word-wrap: break-word;
            text-align: left;
        }
        th {
            background-color: #4472C4;
            color: white;
            font-weight: bold;
        }
        .text-right { text-align: right; }
        .text-center { text-align: center; }
        .account-header {
            background-color: #F2F2F2;
            font-weight: bold;
        }
        .summary-row {
            background-color: #FFF2CC;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="header">BUKU BESAR</div>
    <div class="date-info">Dicetak: <?php echo date('d/m/Y H:i'); ?></div>

    <?php if (!empty($ledger)): ?>
        <?php foreach ($ledger as $code => $acct): ?>
            <?php 
                $type = $acct['account_type'] ?: inferAccountType($acct['account_code']);
                $balance = 0.0;
                $normalDebit = isDebitNormal($type);
            ?>
            <table>
                <tr class="account-header">
                    <td colspan="7">
                        Akun: <?php echo htmlspecialchars($acct['account_code']); ?> — <?php echo htmlspecialchars($acct['account_name']); ?>
                        (Tipe: <?php echo htmlspecialchars($type ?: '-'); ?>, Saldo Normal: <?php echo $normalDebit ? 'Debit' : 'Kredit'; ?>)
                    </td>
                </tr>
                <tr>
                    <th class="text-center" style="width: 12%;">Tanggal</th>
                    <th class="text-center" style="width: 12%;">Kode Akun</th>
                    <th style="width: 18%;">Nama Akun</th>
                    <th style="width: 28%;">Uraian</th>
                    <th class="text-right" style="width: 10%;">Debit</th>
                    <th class="text-right" style="width: 10%;">Kredit</th>
                    <th class="text-right" style="width: 10%;">Saldo</th>
                </tr>
                <?php if (!empty($acct['entries'])): ?>
                    <?php foreach ($acct['entries'] as $entry): ?>
                        <?php
                            if ($normalDebit) {
                                $balance += ($entry['debit'] - $entry['credit']);
                            } else {
                                $balance += ($entry['credit'] - $entry['debit']);
                            }
                        ?>
                        <tr>
                            <td class="text-center"><?php echo date('d/m/Y', strtotime($entry['date'])); ?></td>
                            <td class="text-center"><?php echo htmlspecialchars(formatAccountCodeDisplay($acct['account_code'])); ?></td>
                            <td><?php echo htmlspecialchars($acct['account_name']); ?></td>
                            <td><?php echo htmlspecialchars($entry['description']); ?></td>
                            <td class="text-right">
                                <?php echo $entry['debit'] > 0 ? 'Rp ' . number_format($entry['debit'], 0, ',', '.') : '-'; ?>
                            </td>
                            <td class="text-right">
                                <?php echo $entry['credit'] > 0 ? 'Rp ' . number_format($entry['credit'], 0, ',', '.') : '-'; ?>
                            </td>
                            <td class="text-right">Rp <?php echo number_format($balance, 0, ',', '.'); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <tr class="summary-row">
                        <td colspan="6" class="text-right"><strong>Saldo Akhir</strong></td>
                        <td class="text-right"><strong>Rp <?php echo number_format($balance, 0, ',', '.'); ?></strong></td>
                    </tr>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center">Belum ada entri untuk akun ini</td>
                    </tr>
                <?php endif; ?>
            </table>
        <?php endforeach; ?>
    <?php else: ?>
        <table>
            <tr>
                <th class="text-center">Tanggal</th>
                <th class="text-center">Kode Akun</th>
                <th>Nama Akun</th>
                <th>Uraian</th>
                <th class="text-right">Debit</th>
                <th class="text-right">Kredit</th>
                <th class="text-right">Saldo</th>
            </tr>
            <tr>
                <td colspan="7" class="text-center">Belum ada jurnal yang tercatat</td>
            </tr>
        </table>
    <?php endif; ?>

    <table style="border: none; width: 100%; margin-top: 10px;">
        <tr style="border: none;">
            <td style="border: none;"><em>Catatan:</em></td>
        </tr>
        <tr style="border: none;">
            <td style="border: none;">
                - Saldo berjalan dihitung dengan dasar saldo normal akun (aset/beban: debit; liabilitas/modal/pendapatan: kredit).<br>
                - Data diambil dari tabel <code>general_journal</code> dan <code>journal_entries</code>, dengan referensi <code>chart_of_accounts</code>.
            </td>
        </tr>
    </table>
</body>
</html>