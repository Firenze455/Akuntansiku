<?php
require_once __DIR__ . '/../includes/config.php';
checkLogin();

$conn = getDBConnection();

// Set header untuk download Excel
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename="Laporan_Cashflow_' . date('Y-m-d') . '.xls"');
header('Cache-Control: max-age=0');

// Get all transactions
$transactions = $conn->query("SELECT * FROM transactions ORDER BY transaction_date DESC, created_at DESC");

// Calculate totals
$total_masuk = 0;
$total_keluar = 0;

$result = $conn->query("SELECT transaction_type, SUM(amount) as total FROM transactions GROUP BY transaction_type");
while ($row = $result->fetch_assoc()) {
    if ($row['transaction_type'] == 'masuk') {
        $total_masuk = $row['total'];
    } else {
        $total_keluar = $row['total'];
    }
}

$saldo = $total_masuk - $total_keluar;
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Laporan Cashflow</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #000;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #70AD47;
            color: white;
            font-weight: bold;
        }
        .text-right {
            text-align: right;
        }
        .text-center {
            text-align: center;
        }
        .header {
            text-align: center;
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 20px;
        }
        .date-info {
            text-align: center;
            font-size: 12px;
            margin-bottom: 20px;
        }
        .summary-box {
            width: 300px;
            margin: 20px auto;
            border: 2px solid #000;
            padding: 15px;
        }
        .summary-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        .income {
            color: green;
            font-weight: bold;
        }
        .expense {
            color: red;
            font-weight: bold;
        }
        .balance {
            color: blue;
            font-weight: bold;
            font-size: 16px;
        }
    </style>
</head>
<body>
    <div class="header">
        LAPORAN CASHFLOW<br>
        SISTEM INFORMASI AKUNTANSI
    </div>
    
    <div class="date-info">
        Dicetak tanggal: <?php echo date('d/m/Y H:i:s'); ?>
    </div>
    
    <!-- Summary Box -->
    <table style="width: 400px; margin: 20px auto;">
        <tr>
            <td style="background-color: #E2EFDA;"><strong>Total Pemasukan</strong></td>
            <td class="text-right income">Rp <?php echo number_format($total_masuk, 0, ',', '.'); ?></td>
        </tr>
        <tr>
            <td style="background-color: #FCE4D6;"><strong>Total Pengeluaran</strong></td>
            <td class="text-right expense">Rp <?php echo number_format($total_keluar, 0, ',', '.'); ?></td>
        </tr>
        <tr style="background-color: #DEEBF7;">
            <td><strong>Saldo Akhir</strong></td>
            <td class="text-right balance">Rp <?php echo number_format($saldo, 0, ',', '.'); ?></td>
        </tr>
    </table>
    
    <br>
    
    <table>
        <thead>
            <tr>
                <th class="text-center">No</th>
                <th class="text-center">Tanggal</th>
                <th>Keterangan</th>
                <th class="text-center">Tipe</th>
                <th class="text-center">Kategori</th>
                <th class="text-right">Pemasukan (Rp)</th>
                <th class="text-right">Pengeluaran (Rp)</th>
                <th class="text-right">Saldo (Rp)</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($transactions->num_rows > 0): ?>
                <?php 
                $no = 1;
                $running_balance = 0;
                $transactions->data_seek(0); // Reset pointer ke awal
                
                // Ambil semua transaksi dan balik urutannya untuk hitung saldo
                $all_transactions = [];
                while ($row = $transactions->fetch_assoc()) {
                    $all_transactions[] = $row;
                }
                $all_transactions = array_reverse($all_transactions);
                
                foreach ($all_transactions as $row):
                    if ($row['transaction_type'] == 'masuk') {
                        $running_balance += $row['amount'];
                    } else {
                        $running_balance -= $row['amount'];
                    }
                ?>
                    <tr>
                        <td class="text-center"><?php echo $no++; ?></td>
                        <td class="text-center"><?php echo date('d/m/Y', strtotime($row['transaction_date'])); ?></td>
                        <td><?php echo htmlspecialchars($row['description']); ?></td>
                        <td class="text-center">
                            <?php echo $row['transaction_type'] == 'masuk' ? 'Masuk' : 'Keluar'; ?>
                        </td>
                        <td class="text-center"><?php echo ucfirst($row['category']); ?></td>
                        <td class="text-right income">
                            <?php echo $row['transaction_type'] == 'masuk' ? number_format($row['amount'], 0, ',', '.') : '-'; ?>
                        </td>
                        <td class="text-right expense">
                            <?php echo $row['transaction_type'] == 'keluar' ? number_format($row['amount'], 0, ',', '.') : '-'; ?>
                        </td>
                        <td class="text-right"><?php echo number_format($running_balance, 0, ',', '.'); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="8" class="text-center">Belum ada transaksi</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    
    <br><br>
    
    <table style="border: none; width: 100%;">
        <tr style="border: none;">
            <td style="border: none; width: 70%;"></td>
            <td style="border: none; text-align: center;">
                <p>Mengetahui,</p>
                <br><br><br>
                <p>_____________________</p>
                <p><strong><?php echo htmlspecialchars($_SESSION['full_name']); ?></strong></p>
            </td>
        </tr>
    </table>
</body>
</html>
<?php
$conn->close();
?>
