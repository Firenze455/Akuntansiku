<?php
require_once __DIR__ . '/../includes/config.php';
checkLogin();

$conn = getDBConnection();

// Set header untuk download Excel
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename="Neraca_Saldo_' . date('Y-m-d') . '.xls"');
header('Cache-Control: max-age=0');

// Filters
// [SAMA] Bangun query dari chart_of_accounts agar akun tanpa transaksi tampil
$filter_date_from = $_GET['date_from'] ?? '';
$filter_date_to = $_GET['date_to'] ?? '';
$filter_account_code = $_GET['account_code'] ?? '';

$params = [];
$types = "";

$gjJoin = " LEFT JOIN general_journal gj ON gj.id = je.journal_id";
if (!empty($filter_date_from)) {
    $gjJoin .= " AND gj.journal_date >= ?";
    $params[] = $filter_date_from;
    $types .= "s";
}
if (!empty($filter_date_to)) {
    $gjJoin .= " AND gj.journal_date <= ?";
    $params[] = $filter_date_to;
    $types .= "s";
}

$query = "SELECT 
            coa.account_code,
            coa.account_name,
            COALESCE(SUM(je.debit), 0) AS total_debit,
            COALESCE(SUM(je.credit), 0) AS total_credit
          FROM chart_of_accounts coa
          LEFT JOIN journal_entries je ON je.account_code = coa.account_code
          $gjJoin";

$where = [];
if (!empty($filter_account_code)) {
    $where[] = "coa.account_code LIKE ?";
    $params[] = $filter_account_code . '%';
    $types .= "s";
}
if (!empty($where)) {
    $query .= " WHERE " . implode(" AND ", $where);
}

$query .= " GROUP BY coa.account_code, coa.account_name
            ORDER BY coa.account_code ASC";

if (!empty($params)) {
    $stmt = $conn->prepare($query);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query($query);
}

// Build rows
$rows = [];
$total_debit_col = 0.0;
$total_credit_col = 0.0;

while ($r = $result->fetch_assoc()) {
    $net = (float)$r['total_debit'] - (float)$r['total_credit'];
    $debit_col = $net >= 0 ? $net : 0.0;
    $credit_col = $net < 0 ? abs($net) : 0.0;

    $rows[] = [
        'account_code' => $r['account_code'],
        'account_name' => $r['account_name'],
        'debit' => $debit_col,
        'credit' => $credit_col
    ];
    $total_debit_col += $debit_col;
    $total_credit_col += $credit_col;
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Neraca Saldo</title>
    <style>
        body { font-family: Calibri, Arial, sans-serif; font-size: 12px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #333; padding: 6px 8px; text-align: left; }
        th { background-color: #4472C4; color: white; font-weight: bold; }
        .text-right { text-align: right; }
        .header { text-align: center; font-size: 18px; font-weight: bold; margin-bottom: 10px; }
        .date-info { text-align: center; font-size: 12px; margin-bottom: 20px; }
        .summary-row { background-color: #FFF2CC; font-weight: bold; }
    </style>
</head>
<body>
    <div class="header">NERACA SALDO</div>
    <div class="date-info">Dicetak: <?php echo date('d/m/Y H:i'); ?></div>

    <table>
        <thead>
            <tr>
                <th>No Akun</th>
                <th>Uraian</th>
                <th class="text-right">Debit</th>
                <th class="text-right">Kredit</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($rows)): ?>
                <?php foreach ($rows as $row): ?>
                <tr>
                    <td><?php echo htmlspecialchars(formatAccountCodeDisplay($row['account_code'])); ?></td>
                    <td><?php echo htmlspecialchars($row['account_name']); ?></td>
                    <td class="text-right"><?php echo $row['debit'] > 0 ? number_format($row['debit'], 0, ',', '.') : '-'; ?></td>
                    <td class="text-right"><?php echo $row['credit'] > 0 ? number_format($row['credit'], 0, ',', '.') : '-'; ?></td>
                </tr>
                <?php endforeach; ?>
                <tr class="summary-row">
                    <td colspan="2"><strong>TOTAL</strong></td>
                    <td class="text-right"><strong><?php echo number_format($total_debit_col, 0, ',', '.'); ?></strong></td>
                    <td class="text-right"><strong><?php echo number_format($total_credit_col, 0, ',', '.'); ?></strong></td>
                </tr>
            <?php else: ?>
                <tr>
                    <td colspan="4" class="text-center">Tidak ada data untuk filter yang dipilih.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html>