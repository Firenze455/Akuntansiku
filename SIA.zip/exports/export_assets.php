<?php
require_once __DIR__ . '/../includes/config.php';
checkLogin();

$conn = getDBConnection();

// Set header untuk download Excel
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename="Daftar_Aset_' . date('Y-m-d') . '.xls"');
header('Cache-Control: max-age=0');

// Get all assets
$assets = $conn->query("SELECT * FROM assets ORDER BY category, purchase_date DESC");

// Calculate totals
$total_purchase = 0;
$total_current = 0;

$result = $conn->query("SELECT SUM(purchase_price) as purchase, SUM(current_value) as current FROM assets");
if ($row = $result->fetch_assoc()) {
    $total_purchase = $row['purchase'];
    $total_current = $row['current'];
}

$depreciation = $total_purchase - $total_current;
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Daftar Aset</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #000;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #9966CC;
            color: white;
            font-weight: bold;
        }
        .text-right {
            text-align: right;
        }
        .text-center {
            text-align: center;
        }
        .header {
            text-align: center;
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 20px;
        }
        .date-info {
            text-align: center;
            font-size: 12px;
            margin-bottom: 20px;
        }
        .total-row {
            background-color: #F2F2F2;
            font-weight: bold;
        }
        .category-header {
            background-color: #E6E6FA;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="header">
        DAFTAR ASET<br>
        SISTEM INFORMASI AKUNTANSI
    </div>
    
    <div class="date-info">
        Dicetak tanggal: <?php echo date('d/m/Y H:i:s'); ?>
    </div>
    
    <!-- Summary Box -->
    <table style="width: 400px; margin: 20px auto;">
        <tr>
            <td style="background-color: #E6E6FA;"><strong>Total Harga Pembelian</strong></td>
            <td class="text-right"><strong>Rp <?php echo number_format($total_purchase, 0, ',', '.'); ?></strong></td>
        </tr>
        <tr>
            <td style="background-color: #E6E6FA;"><strong>Total Nilai Sekarang</strong></td>
            <td class="text-right"><strong>Rp <?php echo number_format($total_current, 0, ',', '.'); ?></strong></td>
        </tr>
        <tr style="background-color: #FFE6E6;">
            <td><strong>Total Penyusutan</strong></td>
            <td class="text-right" style="color: red;"><strong>Rp <?php echo number_format($depreciation, 0, ',', '.'); ?></strong></td>
        </tr>
    </table>
    
    <br>
    
    <table>
        <thead>
            <tr>
                <th class="text-center">No</th>
                <th>Nama Aset</th>
                <th class="text-center">Kategori</th>
                <th class="text-center">Tanggal Pembelian</th>
                <th class="text-right">Harga Beli (Rp)</th>
                <th class="text-right">Nilai Sekarang (Rp)</th>
                <th class="text-right">Penyusutan (Rp)</th>
                <th class="text-center">% Penyusutan</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($assets->num_rows > 0): ?>
                <?php 
                $no = 1;
                $current_category = '';
                
                while ($row = $assets->fetch_assoc()):
                    $depreciation_amount = $row['purchase_price'] - $row['current_value'];
                    $depreciation_percent = $row['purchase_price'] > 0 ? ($depreciation_amount / $row['purchase_price']) * 100 : 0;
                    
                    // Category header
                    if ($current_category != $row['category']):
                        $current_category = $row['category'];
                ?>
                    <tr class="category-header">
                        <td colspan="8">
                            <strong><?php echo $row['category'] == 'peralatan' ? 'PERALATAN' : 'PERLENGKAPAN'; ?></strong>
                        </td>
                    </tr>
                <?php endif; ?>
                
                    <tr>
                        <td class="text-center"><?php echo $no++; ?></td>
                        <td><?php echo htmlspecialchars($row['asset_name']); ?></td>
                        <td class="text-center"><?php echo $row['category'] == 'peralatan' ? 'Peralatan' : 'Perlengkapan'; ?></td>
                        <td class="text-center"><?php echo date('d/m/Y', strtotime($row['purchase_date'])); ?></td>
                        <td class="text-right"><?php echo number_format($row['purchase_price'], 0, ',', '.'); ?></td>
                        <td class="text-right"><?php echo number_format($row['current_value'], 0, ',', '.'); ?></td>
                        <td class="text-right" style="color: red;"><?php echo number_format($depreciation_amount, 0, ',', '.'); ?></td>
                        <td class="text-center"><?php echo number_format($depreciation_percent, 1); ?>%</td>
                    </tr>
                <?php endwhile; ?>
                
                <!-- Total Row -->
                <tr class="total-row">
                    <td colspan="4" class="text-center"><strong>TOTAL</strong></td>
                    <td class="text-right"><strong><?php echo number_format($total_purchase, 0, ',', '.'); ?></strong></td>
                    <td class="text-right"><strong><?php echo number_format($total_current, 0, ',', '.'); ?></strong></td>
                    <td class="text-right" style="color: red;"><strong><?php echo number_format($depreciation, 0, ',', '.'); ?></strong></td>
                    <td class="text-center">
                        <strong><?php echo $total_purchase > 0 ? number_format(($depreciation / $total_purchase) * 100, 1) : 0; ?>%</strong>
                    </td>
                </tr>
            <?php else: ?>
                <tr>
                    <td colspan="8" class="text-center">Belum ada aset yang terdaftar</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    
    <br><br>
    
    <table style="border: none; width: 100%;">
        <tr style="border: none;">
            <td style="border: none; width: 70%;"></td>
            <td style="border: none; text-align: center;">
                <p>Mengetahui,</p>
                <br><br><br>
                <p>_____________________</p>
                <p><strong><?php echo htmlspecialchars($_SESSION['full_name']); ?></strong></p>
            </td>
        </tr>
    </table>
</body>
</html>
<?php
$conn->close();
?>
