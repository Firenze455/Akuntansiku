<?php
require_once __DIR__ . '/includes/config.php';
checkLogin();

// BLOCK ADMIN - Redirect ke manage users
if (isAdmin()) {
    header('Location: manage_users.php');
    exit();
}

// Check permission - hanya supervisor dan head yang bisa akses dashboard
if (!checkPermission('dashboard', 'view')) {
    $_SESSION['error'] = 'Anda tidak memiliki akses ke dashboard!';
    
    // Redirect based on role
    if (isStaff()) {
        header('Location: cashflow.php');
    } else {
        header('Location: login.php');
    }
    exit();
}

$conn = getDBConnection();

// Get summary data (only approved transactions)
$total_kas = 0;
$total_assets = 0;
$total_revenue = 0;
$total_expense = 0;

// Calculate Kas (Cash) - hanya dari approved
$result = $conn->query("SELECT COALESCE(SUM(debit - credit), 0) as total FROM journal_entries WHERE account_code = '1-1100'");
if ($row = $result->fetch_assoc()) {
    $total_kas = $row['total'];
}

// Calculate Total Assets - hanya approved
$result = $conn->query("SELECT COALESCE(SUM(current_value), 0) as total FROM assets WHERE status = 'approved'");
if ($row = $result->fetch_assoc()) {
    $total_assets = $row['total'];
}

// Calculate Revenue - hanya dari approved
$result = $conn->query("SELECT COALESCE(SUM(credit - debit), 0) as total FROM journal_entries WHERE account_code LIKE '4-%'");
if ($row = $result->fetch_assoc()) {
    $total_revenue = $row['total'];
}

// Calculate Expense - hanya dari approved
$result = $conn->query("SELECT COALESCE(SUM(debit - credit), 0) as total FROM journal_entries WHERE account_code LIKE '5-%'");
if ($row = $result->fetch_assoc()) {
    $total_expense = $row['total'];
}

// Tambahan: saldo Piutang & Hutang dari jurnal
$total_receivables_balance = 0;
$total_payables_balance = 0;

// Piutang Usaha (normal debit): debit - credit
$result = $conn->query("SELECT COALESCE(SUM(debit - credit), 0) as total FROM journal_entries WHERE account_code = '1-1200'");
if ($row = $result->fetch_assoc()) {
    $total_receivables_balance = $row['total'];
}

// Hutang Usaha (normal kredit): credit - debit
$result = $conn->query("SELECT COALESCE(SUM(credit - debit), 0) as total FROM journal_entries WHERE account_code = '2-2100'");
if ($row = $result->fetch_assoc()) {
    $total_payables_balance = $row['total'];
}

// Get recent transactions - hanya approved
$recent_transactions = $conn->query("SELECT * FROM transactions WHERE status = 'approved' ORDER BY transaction_date DESC, created_at DESC LIMIT 5");

// Get pending count for supervisor
$pending_transactions = 0;
$pending_assets = 0;
if (isSupervisor()) {
    $result = $conn->query("SELECT COUNT(*) as count FROM transactions WHERE status = 'pending'");
    $pending_transactions = $result->fetch_assoc()['count'];
    
    $result = $conn->query("SELECT COUNT(*) as count FROM assets WHERE status = 'pending'");
    $pending_assets = $result->fetch_assoc()['count'];
}

// Get revenue breakdown by category
$revenue_breakdown = $conn->query("
    SELECT 
        je.account_name,
        SUM(je.credit - je.debit) as amount
    FROM journal_entries je
    WHERE je.account_code LIKE '4-%'
    GROUP BY je.account_code, je.account_name
    HAVING amount > 0
    ORDER BY amount DESC
");

// Get expense breakdown by category
$expense_breakdown = $conn->query("
    SELECT 
        je.account_name,
        SUM(je.debit - je.credit) as amount
    FROM journal_entries je
    WHERE je.account_code LIKE '5-%'
    GROUP BY je.account_code, je.account_name
    HAVING amount > 0
    ORDER BY amount DESC
");

// Get monthly revenue and expense for trend chart
$monthly_data = $conn->query("
    SELECT 
        DATE_FORMAT(gj.journal_date, '%Y-%m') as month,
        SUM(CASE WHEN je.account_code LIKE '4-%' THEN je.credit - je.debit ELSE 0 END) as revenue,
        SUM(CASE WHEN je.account_code LIKE '5-%' THEN je.debit - je.credit ELSE 0 END) as expense
    FROM general_journal gj
    JOIN journal_entries je ON gj.id = je.journal_id
    WHERE gj.journal_date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
    GROUP BY month
    ORDER BY month ASC
");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Sistem Informasi Akuntansi</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="bg-gray-50">
    <?php include __DIR__ . '/includes/header.php'; ?>
    
    <div class="max-w-7xl mx-auto p-6">
        <div class="mb-6">
            <h2 class="text-2xl font-bold text-gray-800">Dashboard</h2>
            <p class="text-gray-600 mt-1">
                Selamat datang, <?php echo htmlspecialchars($_SESSION['full_name']); ?>!
                <?php if (isSupervisor()): ?>
                    <span class="inline-block ml-2 px-2 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-800">
                        Supervisor
                    </span>
                <?php elseif (isHead()): ?>
                    <span class="inline-block ml-2 px-2 py-1 text-xs font-semibold rounded-full bg-yellow-100 text-yellow-800">
                        Head
                    </span>
                <?php endif; ?>
            </p>
        </div>
        
        <?php if (isSupervisor() && ($pending_transactions > 0 || $pending_assets > 0)): ?>
        <!-- Alert Pending for Supervisor -->
        <div class="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-6">
            <div class="flex">
                <div class="flex-shrink-0">
                    <svg class="h-5 w-5 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/>
                    </svg>
                </div>
                <div class="ml-3">
                    <p class="text-sm text-yellow-700">
                        Ada <strong><?php echo $pending_transactions + $pending_assets; ?> transaksi</strong> menunggu approval!
                        <?php if ($pending_transactions > 0): ?>
                            <a href="cashflow.php" class="underline ml-2">Lihat Cashflow (<?php echo $pending_transactions; ?>)</a>
                        <?php endif; ?>
                        <?php if ($pending_assets > 0): ?>
                            <a href="assets.php" class="underline ml-2">Lihat Assets (<?php echo $pending_assets; ?>)</a>
                        <?php endif; ?>
                    </p>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <?php if (isSupervisor()): ?>
        <!-- Quick Actions for Supervisor -->
        <div class="bg-gradient-to-r from-blue-500 to-indigo-600 rounded-lg shadow-lg p-6 mb-6 text-white">
            <h3 class="text-lg font-semibold mb-3 flex items-center">
                <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3zM6 8a2 2 0 11-4 0 2 2 0 014 0zM16 18v-3a5.972 5.972 0 00-.75-2.906A3.005 3.005 0 0119 15v3h-3zM4.75 12.094A5.973 5.973 0 004 15v3H1v-3a3 3 0 013.75-2.906z"></path>
                </svg>
                Quick Actions - Supervisor
            </h3>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <a href="cashflow.php?status=pending" class="bg-white bg-opacity-20 hover:bg-opacity-30 rounded-lg p-4 transition-all">
                    <div class="flex items-center">
                        <svg class="w-8 h-8 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                        <div>
                            <div class="font-semibold">Review Transaksi</div>
                            <div class="text-sm text-blue-100"><?php echo $pending_transactions; ?> pending</div>
                        </div>
                    </div>
                </a>
                <a href="journal.php" class="bg-white bg-opacity-20 hover:bg-opacity-30 rounded-lg p-4 transition-all">
                    <div class="flex items-center">
                        <svg class="w-8 h-8 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                        </svg>
                        <div>
                            <div class="font-semibold">Jurnal Umum</div>
                            <div class="text-sm text-blue-100">Lihat semua jurnal</div>
                        </div>
                    </div>
                </a>
                <a href="assets.php?status=pending" class="bg-white bg-opacity-20 hover:bg-opacity-30 rounded-lg p-4 transition-all">
                    <div class="flex items-center">
                        <svg class="w-8 h-8 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"></path>
                        </svg>
                        <div>
                            <div class="font-semibold">Review Aset</div>
                            <div class="text-sm text-blue-100"><?php echo $pending_assets; ?> pending</div>
                        </div>
                    </div>
                </a>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Summary Cards -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <!-- Kas Card -->
            <div class="bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg shadow-lg p-6 text-white cursor-default">
                <div class="flex items-center justify-between mb-4">
                    <div>
                        <p class="text-blue-100 text-sm font-medium">Total Kas</p>
                        <h3 class="text-2xl font-bold mt-1"><?php echo formatRupiah($total_kas); ?></h3>
                    </div>
                    <div class="bg-blue-400 bg-opacity-50 p-3 rounded-lg">
                        <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z"></path>
                        </svg>
                    </div>
                </div>
                <p class="text-blue-100 text-xs">Saldo kas saat ini</p>
            </div>

            <!-- Pendapatan Card - Clickable -->
            <div onclick="toggleRevenueChart()" class="bg-gradient-to-br from-green-500 to-green-600 rounded-lg shadow-lg p-6 text-white cursor-pointer hover:shadow-xl transition-shadow">
                <div class="flex items-center justify-between mb-4">
                    <div>
                        <p class="text-green-100 text-sm font-medium">Total Pendapatan</p>
                        <h3 class="text-2xl font-bold mt-1"><?php echo formatRupiah($total_revenue); ?></h3>
                    </div>
                    <div class="bg-green-400 bg-opacity-50 p-3 rounded-lg">
                        <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"></path>
                        </svg>
                    </div>
                </div>
                <p class="text-green-100 text-xs">👆 Klik untuk lihat detail</p>
            </div>
            
            <!-- Beban Card - Clickable -->
            <div onclick="toggleExpenseChart()" class="bg-gradient-to-br from-red-500 to-red-600 rounded-lg shadow-lg p-6 text-white cursor-pointer hover:shadow-xl transition-shadow">
                <div class="flex items-center justify-between mb-4">
                    <div>
                        <p class="text-red-100 text-sm font-medium">Total Beban</p>
                        <h3 class="text-2xl font-bold mt-1"><?php echo formatRupiah($total_expense); ?></h3>
                    </div>
                    <div class="bg-red-400 bg-opacity-50 p-3 rounded-lg">
                        <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 17h8m0 0V9m0 8l-8-8-4 4-6-6"></path>
                        </svg>
                    </div>
                </div>
                <p class="text-red-100 text-xs">👆 Klik untuk lihat detail</p>
            </div>
            
            <!-- Aset Card -->
            <div class="bg-gradient-to-br from-purple-500 to-purple-600 rounded-lg shadow-lg p-6 text-white cursor-default">
                <div class="flex items-center justify-between mb-4">
                    <div>
                        <p class="text-purple-100 text-sm font-medium">Total Aset</p>
                        <h3 class="text-2xl font-bold mt-1"><?php echo formatRupiah($total_assets); ?></h3>
                    </div>
                    <div class="bg-purple-400 bg-opacity-50 p-3 rounded-lg">
                        <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path>
                        </svg>
                    </div>
                </div>
                <p class="text-purple-100 text-xs">Nilai aset saat ini</p>
            </div>
        </div>

        <!-- Ringkasan Piutang & Hutang -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <!-- Saldo Piutang -->
            <a href="receivables.php" class="bg-gradient-to-br from-amber-500 to-amber-600 rounded-lg shadow-lg p-6 text-white hover:shadow-xl transition-shadow">
                <div class="flex items-center justify-between mb-4">
                    <div>
                        <p class="text-amber-100 text-sm font-medium">Saldo Piutang</p>
                        <h3 class="text-2xl font-bold mt-1"><?php echo formatRupiah($total_receivables_balance); ?></h3>
                    </div>
                    <div class="bg-amber-400 bg-opacity-50 p-3 rounded-lg">
                        <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7h8M8 11h8M8 15h6"></path>
                        </svg>
                    </div>
                </div>
                <p class="text-amber-100 text-xs">Total piutang usaha belum dibayar</p>
            </a>

            <!-- Saldo Hutang -->
            <a href="payables.php" class="bg-gradient-to-br from-slate-500 to-slate-600 rounded-lg shadow-lg p-6 text-white hover:shadow-xl transition-shadow">
                <div class="flex items-center justify-between mb-4">
                    <div>
                        <p class="text-slate-100 text-sm font-medium">Saldo Hutang</p>
                        <h3 class="text-2xl font-bold mt-1"><?php echo formatRupiah($total_payables_balance); ?></h3>
                    </div>
                    <div class="bg-slate-400 bg-opacity-50 p-3 rounded-lg">
                        <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 7h16M4 11h16M4 15h10"></path>
                        </svg>
                    </div>
                </div>
                <p class="text-slate-100 text-xs">Total hutang usaha belum dibayar</p>
            </a>
        </div>

        <!-- Chart Sections - Hidden by default -->
        <div id="revenueChartSection" class="hidden mb-8">
            <div class="flex items-center justify-between">
                <h3 class="text-lg font-semibold text-gray-800">Detail Pendapatan</h3>
                <button onclick="toggleRevenueChart()" class="text-gray-500 hover:text-gray-700">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mt-3">
                <div class="md:col-span-2 min-h-[280px] bg-white rounded-md shadow p-4">
                    <canvas id="revenueChart"></canvas>
                </div>
                <div class="bg-white rounded-md shadow p-4">
                    <h4 class="font-semibold text-gray-800 mb-2">Rincian Pendapatan</h4>
                    <?php if ($revenue_breakdown && $revenue_breakdown->num_rows > 0): ?>
                        <ul class="space-y-2">
                            <?php mysqli_data_seek($revenue_breakdown, 0); while ($r = $revenue_breakdown->fetch_assoc()): ?>
                                <li class="flex justify-between text-sm">
                                    <span class="text-gray-700"><?php echo htmlspecialchars($r['account_name']); ?></span>
                                    <span class="font-medium"><?php echo formatRupiah($r['amount']); ?></span>
                                </li>
                            <?php endwhile; ?>
                        </ul>
                    <?php else: ?>
                        <p class="text-sm text-gray-500">Belum ada data.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <div id="expenseChartSection" class="hidden mb-8">
            <div class="flex items-center justify-between">
                <h3 class="text-lg font-semibold text-gray-800">Detail Beban</h3>
                <button onclick="toggleExpenseChart()" class="text-gray-500 hover:text-gray-700">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mt-3">
                <div class="md:col-span-2 min-h-[280px] bg-white rounded-md shadow p-4">
                    <canvas id="expenseChart"></canvas>
                </div>
                <div class="bg-white rounded-md shadow p-4">
                    <h4 class="font-semibold text-gray-800 mb-2">Rincian Beban</h4>
                    <?php if ($expense_breakdown && $expense_breakdown->num_rows > 0): ?>
                        <ul class="space-y-2">
                            <?php mysqli_data_seek($expense_breakdown, 0); while ($e = $expense_breakdown->fetch_assoc()): ?>
                                <li class="flex justify-between text-sm">
                                    <span class="text-gray-700"><?php echo htmlspecialchars($e['account_name']); ?></span>
                                    <span class="font-medium"><?php echo formatRupiah($e['amount']); ?></span>
                                </li>
                            <?php endwhile; ?>
                        </ul>
                    <?php else: ?>
                        <p class="text-sm text-gray-500">Belum ada data.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Trend Chart -->
        <div class="bg-white rounded-lg shadow p-6 mb-8">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Tren Pendapatan & Beban (6 Bulan Terakhir)</h3>
            <div style="height: 250px; position: relative;">
                <canvas id="trendChart"></canvas>
            </div>
        </div>
        
        <!-- Recent Transactions -->
        <div class="bg-white rounded-lg shadow">
            <div class="p-6 border-b border-gray-200">
                <div class="flex items-center justify-between">
                    <h3 class="text-lg font-semibold text-gray-800">Transaksi Terbaru (Approved)</h3>
                    <a href="cashflow.php" class="text-blue-600 hover:text-blue-700 text-sm font-medium">
                        Lihat Semua →
                    </a>
                </div>
            </div>
            <div class="p-6">
                <?php if ($recent_transactions->num_rows > 0): ?>
                    <div class="space-y-4">
                        <?php while ($row = $recent_transactions->fetch_assoc()): ?>
                            <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                                <div class="flex items-center space-x-4">
                                    <div class="flex-shrink-0">
                                        <div class="w-10 h-10 rounded-full flex items-center justify-center <?php echo $row['transaction_type'] == 'masuk' ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'; ?>">
                                            <?php if ($row['transaction_type'] == 'masuk'): ?>
                                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
                                                </svg>
                                            <?php else: ?>
                                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 12H4"></path>
                                                </svg>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div>
                                        <p class="font-medium text-gray-800"><?php echo htmlspecialchars($row['description']); ?></p>
                                        <p class="text-sm text-gray-500"><?php echo date('d/m/Y', strtotime($row['transaction_date'])); ?></p>
                                    </div>
                                </div>
                                <div class="text-right">
                                    <p class="font-bold <?php echo $row['transaction_type'] == 'masuk' ? 'text-green-600' : 'text-red-600'; ?>">
                                        <?php echo $row['transaction_type'] == 'masuk' ? '+' : '-'; ?> <?php echo formatRupiah($row['amount']); ?>
                                    </p>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                <?php else: ?>
                    <div class="text-center py-8">
                        <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                        </svg>
                        <p class="mt-2 text-gray-500">Belum ada transaksi approved</p>
                        <?php if (isSupervisor()): ?>
                            <a href="cashflow.php?status=pending" class="mt-3 inline-block text-blue-600 hover:text-blue-700 font-medium">
                                Lihat Transaksi Pending
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script>
        // Prepare data for charts
        const revenueData = <?php 
            $labels = [];
            $data = [];
            $colors = [];
            $colorPalette = ['#10b981', '#34d399', '#6ee7b7', '#a7f3d0'];
            $i = 0;
            mysqli_data_seek($revenue_breakdown, 0);
            while ($row = $revenue_breakdown->fetch_assoc()) {
                $labels[] = $row['account_name'];
                $data[] = $row['amount'];
                $colors[] = $colorPalette[$i % count($colorPalette)];
                $i++;
            }
            echo json_encode(['labels' => $labels, 'data' => $data, 'colors' => $colors]);
        ?>;
        
        const expenseData = <?php 
            $labels = [];
            $data = [];
            $colors = [];
            $colorPalette = ['#ef4444', '#f87171', '#fca5a5', '#fecaca'];
            $i = 0;
            mysqli_data_seek($expense_breakdown, 0);
            while ($row = $expense_breakdown->fetch_assoc()) {
                $labels[] = $row['account_name'];
                $data[] = $row['amount'];
                $colors[] = $colorPalette[$i % count($colorPalette)];
                $i++;
            }
            echo json_encode(['labels' => $labels, 'data' => $data, 'colors' => $colors]);
        ?>;
        
        const monthlyData = <?php 
            $months = [];
            $revenues = [];
            $expenses = [];
            mysqli_data_seek($monthly_data, 0);
            while ($row = $monthly_data->fetch_assoc()) {
                $months[] = $row['month'];
                $revenues[] = $row['revenue'];
                $expenses[] = $row['expense'];
            }
            echo json_encode(['months' => $months, 'revenues' => $revenues, 'expenses' => $expenses]);
        ?>;
        
        // Revenue Chart
        let revenueChart = null;
        function toggleRevenueChart() {
            const section = document.getElementById('revenueChartSection');
            const expenseSection = document.getElementById('expenseChartSection');
            
            // Hide expense chart if open
            expenseSection.classList.add('hidden');
            
            if (section.classList.contains('hidden')) {
                section.classList.remove('hidden');
                
                if (!revenueChart && revenueData.labels.length > 0) {
                    const ctx = document.getElementById('revenueChart').getContext('2d');
                    revenueChart = new Chart(ctx, {
                        type: 'doughnut',
                        data: {
                            labels: revenueData.labels,
                            datasets: [{
                                data: revenueData.data,
                                backgroundColor: revenueData.colors,
                                borderWidth: 2,
                                borderColor: '#fff'
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            plugins: {
                                legend: {
                                    position: 'right',
                                },
                                tooltip: {
                                    callbacks: {
                                        label: function(context) {
                                            let label = context.label || '';
                                            if (label) {
                                                label += ': ';
                                            }
                                            label += 'Rp ' + context.parsed.toLocaleString('id-ID');
                                            return label;
                                        }
                                    }
                                }
                            }
                        }
                    });
                }
            } else {
                section.classList.add('hidden');
            }
        }
        
        // Expense Chart
        let expenseChart = null;
        function toggleExpenseChart() {
            const section = document.getElementById('expenseChartSection');
            const revenueSection = document.getElementById('revenueChartSection');
            
            // Hide revenue chart if open
            revenueSection.classList.add('hidden');
            
            if (section.classList.contains('hidden')) {
                section.classList.remove('hidden');
                
                if (!expenseChart && expenseData.labels.length > 0) {
                    const ctx = document.getElementById('expenseChart').getContext('2d');
                    expenseChart = new Chart(ctx, {
                        type: 'doughnut',
                        data: {
                            labels: expenseData.labels,
                            datasets: [{
                                data: expenseData.data,
                                backgroundColor: expenseData.colors,
                                borderWidth: 2,
                                borderColor: '#fff'
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            plugins: {
                                legend: {
                                    position: 'right',
                                },
                                tooltip: {
                                    callbacks: {
                                        label: function(context) {
                                            let label = context.label || '';
                                            if (label) {
                                                label += ': ';
                                            }
                                            label += 'Rp ' + context.parsed.toLocaleString('id-ID');
                                            return label;
                                        }
                                    }
                                }
                            }
                        }
                    });
                }
            } else {
                section.classList.add('hidden');
            }
        }
        
        // Trend Chart - Always shown
        if (monthlyData.months.length > 0) {
            const ctx = document.getElementById('trendChart').getContext('2d');
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: monthlyData.months,
                    datasets: [
                        {
                            label: 'Pendapatan',
                            data: monthlyData.revenues,
                            borderColor: '#10b981',
                            backgroundColor: 'rgba(16, 185, 129, 0.1)',
                            tension: 0.4,
                            fill: true
                        },
                        {
                            label: 'Beban',
                            data: monthlyData.expenses,
                            borderColor: '#ef4444',
                            backgroundColor: 'rgba(239, 68, 68, 0.1)',
                            tension: 0.4,
                            fill: true
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    let label = context.dataset.label || '';
                                    if (label) {
                                        label += ': ';
                                    }
                                    label += 'Rp ' + context.parsed.y.toLocaleString('id-ID');
                                    return label;
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: function(value) {
                                    return 'Rp ' + value.toLocaleString('id-ID');
                                }
                            }
                        }
                    }
                }
            });
        }
    </script>
</body>
</html>
<?php $conn->close(); ?>