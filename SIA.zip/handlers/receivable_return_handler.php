<?php
require_once __DIR__ . '/../includes/config.php';
checkLogin();

if (!isSupervisor()) {
    $_SESSION['error'] = 'Hanya supervisor yang dapat melakukan approve/reject/return piutang!';
    header('Location: receivables.php');
    exit();
}

$conn = getDBConnection();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    $id = intval($_POST['id'] ?? 0);
    $reason = trim($_POST['reason'] ?? '');
    $user_id = $_SESSION['user_id'];
    
    if ($id <= 0) {
        $_SESSION['error'] = 'ID piutang tidak valid!';
        header('Location: receivables.php');
        exit();
    }
    
    // Get receivable details — allow items that are not yet approved (approved_at IS NULL)
    $stmt = $conn->prepare("SELECT * FROM receivables WHERE id = ? AND approved_at IS NULL");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $receivable = $stmt->get_result()->fetch_assoc();

    if (!$receivable) {
        $_SESSION['error'] = 'Piutang tidak ditemukan atau sudah diproses!';
        header('Location: receivables.php');
        exit();
    }
    
    // APPROVE RECEIVABLE
    if ($action === 'approve') {
        $conn->begin_transaction();
        
        try {
            // Update approval
            $stmt = $conn->prepare("UPDATE receivables SET status = 'approved', approved_by = ?, approved_at = NOW() WHERE id = ?");
            $stmt->bind_param("ii", $user_id, $id);
            $stmt->execute();
            
            // Create journal entry
            $journal_desc = "Piutang dari " . $receivable['customer_name'] . " - " . $receivable['description'];
            $stmt = $conn->prepare("INSERT INTO general_journal (journal_date, description, reference_id, reference_type) VALUES (CURDATE(), ?, ?, 'receivable')");
            $stmt->bind_param("si", $journal_desc, $id);
            $stmt->execute();
            $journal_id = $stmt->insert_id;
            
            // Debit: Piutang Usaha
            $stmt = $conn->prepare("INSERT INTO journal_entries (journal_id, account_code, account_name, debit, credit) VALUES (?, '1-1200', 'Piutang Usaha', ?, 0)");
            $stmt->bind_param("id", $journal_id, $receivable['total_amount']);
            $stmt->execute();
            
            // Credit: Pendapatan (4-4100)
            $stmt = $conn->prepare("INSERT INTO journal_entries (journal_id, account_code, account_name, debit, credit) VALUES (?, '4-4100', 'Pendapatan', 0, ?)");
            $stmt->bind_param("id", $journal_id, $receivable['total_amount']);
            $stmt->execute();
            
            $conn->commit();
            $_SESSION['success'] = '✅ Piutang berhasil di-approve!';
            
        } catch (Exception $e) {
            $conn->rollback();
            $_SESSION['error'] = '❌ Gagal meng-approve piutang: ' . $e->getMessage();
        }
    }
    
    // REJECT RECEIVABLE
    elseif ($action === 'reject') {
        if (empty($reason) || strlen($reason) < 10) {
            $_SESSION['error'] = 'Alasan penolakan harus diisi minimal 10 karakter!';
            header('Location: receivables.php');
            exit();
        }
        
        $conn->begin_transaction();
        
        try {
            $stmt = $conn->prepare("UPDATE receivables SET status = 'rejected', notes = ?, approved_by = ?, approved_at = NOW() WHERE id = ?");
            $stmt->bind_param("sii", $reason, $user_id, $id);
            $stmt->execute();
            
            $conn->commit();
            $_SESSION['success'] = '✅ Piutang berhasil ditolak!';
            
        } catch (Exception $e) {
            $conn->rollback();
            $_SESSION['error'] = '❌ Gagal menolak piutang: ' . $e->getMessage();
        }
    }
    
    // RETURN RECEIVABLE (Kembalikan untuk diedit staff)
    elseif ($action === 'return') {
        if (empty($reason) || strlen($reason) < 10) {
            $_SESSION['error'] = 'Alasan pengembalian harus diisi minimal 10 karakter!';
            header('Location: receivables.php');
            exit();
        }
        
        $conn->begin_transaction();
        
        try {
            $stmt = $conn->prepare("UPDATE receivables SET status = 'returned', notes = ?, approved_by = ?, approved_at = NOW() WHERE id = ?");
            $stmt->bind_param("sii", $reason, $user_id, $id);
            $stmt->execute();
            
            $conn->commit();
            $_SESSION['success'] = '🔄 Piutang berhasil dikembalikan ke staff untuk revisi!';
            
        } catch (Exception $e) {
            $conn->rollback();
            $_SESSION['error'] = '❌ Gagal mengembalikan piutang: ' . $e->getMessage();
        }
    }
    
    else {
        $_SESSION['error'] = 'Action tidak valid!';
    }
}

$conn->close();
header('Location: receivables.php');
exit();
?>
