<?php

require_once __DIR__ . '/../includes/config.php';
checkLogin();

$conn = getDBConnection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $type = $_POST['type'] ?? '';
    $id = (int)($_POST['id'] ?? 0);
    $reason = trim($_POST['reason'] ?? '');
    $redirect = $_POST['redirect'] ?? 'index.php';
    
    $user_id = $_SESSION['user_id'];
    
    // Validasi input
    if (empty($action) || empty($type) || $id <= 0) {
        $_SESSION['error'] = 'Data tidak valid!';
        header('Location: ' . $redirect);
        exit();
    }
    
    // RETURN TRANSACTION (Kembalikan ke staff untuk diedit)
    if ($action === 'return' && $type === 'transaction') {
        // Supervisor-only
        if (!isSupervisor()) {
            $_SESSION['error'] = 'Anda tidak memiliki akses untuk mengembalikan transaksi!';
            header('Location: ' . $redirect);
            exit();
        }

        // Validasi alasan
        if (empty($reason) || strlen($reason) < 10) {
            $_SESSION['error'] = 'Alasan pengembalian harus diisi minimal 10 karakter!';
            header('Location: ' . $redirect);
            exit();
        }
        
        // Check if transaction exists and pending
        $stmt = $conn->prepare("SELECT * FROM transactions WHERE id = ? AND status = 'pending'");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $transaction = $stmt->get_result()->fetch_assoc();
        
        if (!$transaction) {
            $_SESSION['error'] = 'Transaksi tidak ditemukan atau sudah diproses!';
            header('Location: ' . $redirect);
            exit();
        }
        
        $conn->begin_transaction();
        
        try {
            // Update status to returned
            $stmt = $conn->prepare("UPDATE transactions SET status = 'returned', rejection_reason = ?, approved_by = ?, approved_at = NOW() WHERE id = ?");
            $stmt->bind_param("sii", $reason, $user_id, $id);
            $stmt->execute();
            
            // Log to approval history
            $notes = 'Transaksi dikembalikan untuk revisi: ' . $reason;
            $stmt = $conn->prepare("INSERT INTO approval_history (transaction_type, transaction_id, action, user_id, notes) VALUES ('cashflow', ?, 'returned', ?, ?)");
            $stmt->bind_param("iis", $id, $user_id, $notes);
            $stmt->execute();
            
            $conn->commit();
            
            $_SESSION['success'] = '🔄 Transaksi berhasil dikembalikan ke staff untuk revisi!';
            
        } catch (Exception $e) {
            $conn->rollback();
            $_SESSION['error'] = '❌ Gagal mengembalikan transaksi: ' . $e->getMessage();
        }
    }
    
    // APPROVE TRANSACTION
    elseif ($action === 'approve' && $type === 'transaction') {
        // Supervisor-only
        if (!isSupervisor()) {
            $_SESSION['error'] = 'Anda tidak memiliki akses untuk menyetujui transaksi!';
            header('Location: ' . $redirect);
            exit();
        }
        // Get transaction data
        $stmt = $conn->prepare("SELECT * FROM transactions WHERE id = ? AND status = 'pending'");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $transaction = $stmt->get_result()->fetch_assoc();
        
        if (!$transaction) {
            $_SESSION['error'] = 'Transaksi tidak ditemukan atau sudah diproses!';
            header('Location: ' . $redirect);
            exit();
        }
        
        // Start transaction
        $conn->begin_transaction();
        
        try {
            // Update status to approved
            $stmt = $conn->prepare("UPDATE transactions SET status = 'approved', approved_by = ?, approved_at = NOW() WHERE id = ?");
            $stmt->bind_param("ii", $user_id, $id);
            $stmt->execute();
            
            // Create journal entry
            $description = $transaction['description'];
            $stmt = $conn->prepare("INSERT INTO general_journal (journal_date, description, reference_id, reference_type) VALUES (?, ?, ?, 'transaction')");
            $stmt->bind_param("ssi", $transaction['transaction_date'], $description, $id);
            $stmt->execute();
            $journal_id = $conn->insert_id;
            
            // Insert journal entries based on transaction type
            if ($transaction['transaction_type'] == 'masuk') {
                // PEMASUKAN: Debit Kas/Piutang, Credit Revenue
                
                $payment_method = $transaction['payment_method'] ?? 'tunai';
                
                if ($payment_method == 'piutang') {
                    // PIUTANG: Harus catat DP ke Kas DAN Sisa ke Piutang
                    
                    // Get receivable data untuk ambil total dan remaining
                    $stmt_rcv = $conn->prepare("SELECT total_amount, remaining_amount FROM receivables WHERE ref_code LIKE ? ORDER BY id DESC LIMIT 1");
                    $rcv_pattern = 'RCV' . date('Ymd', strtotime($transaction['transaction_date'])) . '%';
                    $stmt_rcv->bind_param("s", $rcv_pattern);
                    $stmt_rcv->execute();
                    $rcv_data = $stmt_rcv->get_result()->fetch_assoc();
                    $stmt_rcv->close();
                    
                    $dp_amount = $transaction['amount']; // DP yang dibayar
                    $remaining = $rcv_data['remaining_amount'] ?? 0; // Sisa piutang
                    $total = $rcv_data['total_amount'] ?? $dp_amount; // Total penjualan
                    
                    // 1. Debit Kas (DP yang dibayar)
                    if ($dp_amount > 0) {
                        $stmt = $conn->prepare("INSERT INTO journal_entries (journal_id, account_code, account_name, debit, credit) VALUES (?, ?, ?, ?, 0)");
                        $account_code = '1-1100';
                        $account_name = 'Kas';
                        $stmt->bind_param("issd", $journal_id, $account_code, $account_name, $dp_amount);
                        $stmt->execute();
                    }
                    
                    // 2. Debit Piutang Usaha (Sisa belum dibayar)
                    if ($remaining > 0) {
                        $stmt = $conn->prepare("INSERT INTO journal_entries (journal_id, account_code, account_name, debit, credit) VALUES (?, ?, ?, ?, 0)");
                        $account_code = '1-1200';
                        $account_name = 'Piutang Usaha';
                        $stmt->bind_param("issd", $journal_id, $account_code, $account_name, $remaining);
                        $stmt->execute();
                    }
                    
                    // Amount untuk credit revenue = total penjualan
                    $revenue_amount = $total;
                    
                } else {
                    // TUNAI: Debit Kas saja
                    $account_code = '1-1100';
                    $account_name = 'Kas';
                    
                    $stmt = $conn->prepare("INSERT INTO journal_entries (journal_id, account_code, account_name, debit, credit) VALUES (?, ?, ?, ?, 0)");
                    $stmt->bind_param("issd", $journal_id, $account_code, $account_name, $transaction['amount']);
                    $stmt->execute();
                    
                    $revenue_amount = $transaction['amount'];
                }
                
                // 3. Credit Revenue (semua metode), category berisi account_code pendapatan
                $category = $transaction['category'];
                $rev_code = $category;
                $rev_name = null;
                $stmt_coa = $conn->prepare("SELECT account_name FROM chart_of_accounts WHERE account_code = ? LIMIT 1");
                $stmt_coa->bind_param("s", $rev_code);
                $stmt_coa->execute();
                $res = $stmt_coa->get_result()->fetch_assoc();
                $stmt_coa->close();
                if ($res) {
                    $rev_name = $res['account_name'];
                } else {
                    $stmt_def = $conn->prepare("SELECT account_code, account_name FROM chart_of_accounts WHERE account_type='pendapatan' ORDER BY account_code ASC LIMIT 1");
                    $stmt_def->execute();
                    $def = $stmt_def->get_result()->fetch_assoc();
                    $stmt_def->close();
                    $rev_code = $def['account_code'] ?? '4101';
                    $rev_name = $def['account_name'] ?? 'Pendapatan';
                }
                $stmt = $conn->prepare("INSERT INTO journal_entries (journal_id, account_code, account_name, debit, credit) VALUES (?, ?, ?, 0, ?)");
                $stmt->bind_param("issd", $journal_id, $rev_code, $rev_name, $revenue_amount);
                $stmt->execute();
                
            } else {
                // PENGELUARAN: Debit Expense, Credit Kas
                
                // Debit Expense
                $expense_map = [
                    'operasional' => ['5-5100', 'Beban Operasional'],
                    'gaji' => ['5-5200', 'Beban Gaji'],
                    'utilitas' => ['5-5300', 'Beban Utilitas'],
                    'lain' => ['5-5400', 'Beban Lain-lain']
                ];
                
                $category = $transaction['category'];
                if (isset($expense_map[$category])) {
                    $account_code = $expense_map[$category][0];
                    $account_name = $expense_map[$category][1];
                } else {
                    // Default jika kategori tidak dikenali
                    $account_code = '5-5400';
                    $account_name = 'Beban Lain-lain';
                }
                
                $stmt = $conn->prepare("INSERT INTO journal_entries (journal_id, account_code, account_name, debit, credit) VALUES (?, ?, ?, ?, 0)");
                $stmt->bind_param("issd", $journal_id, $account_code, $account_name, $transaction['amount']);
                $stmt->execute();
                
                // Credit Kas
                $account_code = '1-1100';
                $account_name = 'Kas';
                $stmt = $conn->prepare("INSERT INTO journal_entries (journal_id, account_code, account_name, debit, credit) VALUES (?, ?, ?, 0, ?)");
                $stmt->bind_param("issd", $journal_id, $account_code, $account_name, $transaction['amount']);
                $stmt->execute();
            }
            
            // Log to approval history
            $notes = 'Transaksi disetujui oleh ' . $_SESSION['full_name'];
            $stmt = $conn->prepare("INSERT INTO approval_history (transaction_type, transaction_id, action, user_id, notes) VALUES ('cashflow', ?, 'approved', ?, ?)");
            $stmt->bind_param("iis", $id, $user_id, $notes);
            $stmt->execute();
            
            // Commit transaction
            $conn->commit();
            
            $_SESSION['success'] = '✅ Transaksi berhasil di-APPROVE dan tercatat dalam jurnal!';
            
        } catch (Exception $e) {
            // Rollback on error
            $conn->rollback();
            $_SESSION['error'] = '❌ Gagal approve transaksi: ' . $e->getMessage();
        }
    }
    
    // REJECT TRANSACTION
    elseif ($action === 'reject' && $type === 'transaction') {
        // Supervisor-only
        if (!isSupervisor()) {
            $_SESSION['error'] = 'Anda tidak memiliki akses untuk menolak transaksi!';
            header('Location: ' . $redirect);
            exit();
        }

        // Validasi alasan
        if (empty($reason) || strlen($reason) < 10) {
            $_SESSION['error'] = 'Alasan penolakan harus diisi minimal 10 karakter!';
            header('Location: ' . $redirect);
            exit();
        }
        
        // Check if transaction exists and pending
        $stmt = $conn->prepare("SELECT * FROM transactions WHERE id = ? AND status = 'pending'");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $transaction = $stmt->get_result()->fetch_assoc();
        
        if (!$transaction) {
            $_SESSION['error'] = 'Transaksi tidak ditemukan atau sudah diproses!';
            header('Location: ' . $redirect);
            exit();
        }
        
        // Start transaction
        $conn->begin_transaction();
        
        try {
            // Update status to rejected
            $stmt = $conn->prepare("UPDATE transactions SET status = 'rejected', rejection_reason = ?, approved_by = ?, approved_at = NOW() WHERE id = ?");
            $stmt->bind_param("sii", $reason, $user_id, $id);
            $stmt->execute();
            
            // Log to approval history
            $notes = 'Transaksi ditolak: ' . $reason;
            $stmt = $conn->prepare("INSERT INTO approval_history (transaction_type, transaction_id, action, user_id, notes) VALUES ('cashflow', ?, 'rejected', ?, ?)");
            $stmt->bind_param("iis", $id, $user_id, $notes);
            $stmt->execute();
            
            // Commit
            $conn->commit();
            
            $_SESSION['success'] = '✅ Transaksi berhasil di-REJECT!';
            
        } catch (Exception $e) {
            $conn->rollback();
            $_SESSION['error'] = '❌ Gagal reject transaksi: ' . $e->getMessage();
        }
    }
    
    // APPROVE ASSET
    elseif ($action === 'approve' && $type === 'asset') {
        // Supervisor-only
        if (!isSupervisor()) {
            $_SESSION['error'] = 'Anda tidak memiliki akses untuk menyetujui aset!';
            header('Location: ' . $redirect);
            exit();
        }
        
        $stmt = $conn->prepare("SELECT * FROM assets WHERE id = ? AND status = 'pending'");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $asset = $stmt->get_result()->fetch_assoc();
        
        if (!$asset) {
            $_SESSION['error'] = 'Aset tidak ditemukan atau sudah diproses!';
            header('Location: ' . $redirect);
            exit();
        }
        
        $conn->begin_transaction();
        
        try {
            // Update status
            $stmt = $conn->prepare("UPDATE assets SET status = 'approved', approved_by = ?, approved_at = NOW() WHERE id = ?");
            $stmt->bind_param("ii", $user_id, $id);
            $stmt->execute();
            
            // Create journal entry
            $description = 'Pembelian Aset: ' . $asset['asset_name'];
            $stmt = $conn->prepare("INSERT INTO general_journal (journal_date, description, reference_id, reference_type) VALUES (?, ?, ?, 'asset')");
            $stmt->bind_param("ssi", $asset['purchase_date'], $description, $id);
            $stmt->execute();
            $journal_id = $conn->insert_id;
            
            // Debit Asset
            $account_map = [
                'peralatan' => ['1-1400', 'Peralatan'],
                'perlengkapan' => ['1-1300', 'Perlengkapan']
            ];
            $account_code = $account_map[$asset['category']][0];
            $account_name = $account_map[$asset['category']][1];
            
            $stmt = $conn->prepare("INSERT INTO journal_entries (journal_id, account_code, account_name, debit, credit) VALUES (?, ?, ?, ?, 0)");
            $stmt->bind_param("issd", $journal_id, $account_code, $account_name, $asset['purchase_price']);
            $stmt->execute();
            
            // Credit Kas
            $account_code = '1-1100';
            $account_name = 'Kas';
            $stmt = $conn->prepare("INSERT INTO journal_entries (journal_id, account_code, account_name, debit, credit) VALUES (?, ?, ?, 0, ?)");
            $stmt->bind_param("issd", $journal_id, $account_code, $account_name, $asset['purchase_price']);
            $stmt->execute();
            
            // Log
            $notes = 'Aset disetujui oleh ' . $_SESSION['full_name'];
            $stmt = $conn->prepare("INSERT INTO approval_history (transaction_type, transaction_id, action, user_id, notes) VALUES ('asset', ?, 'approved', ?, ?)");
            $stmt->bind_param("iis", $id, $user_id, $notes);
            $stmt->execute();
            
            $conn->commit();
            
            $_SESSION['success'] = '✅ Aset berhasil di-APPROVE dan tercatat dalam jurnal!';
            
        } catch (Exception $e) {
            $conn->rollback();
            $_SESSION['error'] = '❌ Gagal approve aset: ' . $e->getMessage();
        }
    }
    
    // REJECT ASSET
    elseif ($action === 'reject' && $type === 'asset') {
        // Supervisor-only
        if (!isSupervisor()) {
            $_SESSION['error'] = 'Anda tidak memiliki akses untuk menolak aset!';
            header('Location: ' . $redirect);
            exit();
        }
        
        if (empty($reason) || strlen($reason) < 10) {
            $_SESSION['error'] = 'Alasan penolakan harus diisi minimal 10 karakter!';
            header('Location: ' . $redirect);
            exit();
        }
        
        $conn->begin_transaction();
        
        try {
            $stmt = $conn->prepare("UPDATE assets SET status = 'rejected', rejection_reason = ?, approved_by = ?, approved_at = NOW() WHERE id = ? AND status = 'pending'");
            $stmt->bind_param("sii", $reason, $user_id, $id);
            $stmt->execute();
            
            if ($stmt->affected_rows > 0) {
                // Log
                $notes = 'Aset ditolak: ' . $reason;
                $stmt = $conn->prepare("INSERT INTO approval_history (transaction_type, transaction_id, action, user_id, notes) VALUES ('asset', ?, 'rejected', ?, ?)");
                $stmt->bind_param("iis", $id, $user_id, $notes);
                $stmt->execute();
                
                $conn->commit();
                $_SESSION['success'] = '✅ Aset berhasil di-REJECT!';
            } else {
                $conn->rollback();
                $_SESSION['error'] = 'Aset tidak ditemukan atau sudah diproses!';
            }
            
        } catch (Exception $e) {
            $conn->rollback();
            $_SESSION['error'] = '❌ Gagal reject aset: ' . $e->getMessage();
        }
    }
    
    // RETURN ASSET
    elseif ($action === 'return' && $type === 'asset') {
        // Supervisor-only
        if (!isSupervisor()) {
            $_SESSION['error'] = 'Anda tidak memiliki akses untuk mengembalikan aset!';
            header('Location: ' . $redirect);
            exit();
        }
        
        if (empty($reason) || strlen($reason) < 10) {
            $_SESSION['error'] = 'Alasan pengembalian harus diisi minimal 10 karakter!';
            header('Location: ' . $redirect);
            exit();
        }
        
        $conn->begin_transaction();
        
        try {
            $stmt = $conn->prepare("UPDATE assets SET status = 'returned', rejection_reason = ?, approved_by = ?, approved_at = NOW() WHERE id = ? AND status = 'pending'");
            $stmt->bind_param("sii", $reason, $user_id, $id);
            $stmt->execute();
            
            if ($stmt->affected_rows > 0) {
                // Log
                $notes = 'Aset dikembalikan untuk revisi: ' . $reason;
                $stmt = $conn->prepare("INSERT INTO approval_history (transaction_type, transaction_id, action, user_id, notes) VALUES ('asset', ?, 'returned', ?, ?)");
                $stmt->bind_param("iis", $id, $user_id, $notes);
                $stmt->execute();
                
                $conn->commit();
                $_SESSION['success'] = '🔄 Aset berhasil dikembalikan ke staff untuk revisi!';
            } else {
                $conn->rollback();
                $_SESSION['error'] = 'Aset tidak ditemukan atau sudah diproses!';
            }
            
        } catch (Exception $e) {
            $conn->rollback();
            $_SESSION['error'] = '❌ Gagal mengembalikan aset: ' . $e->getMessage();
        }
    }
    
    // RESUBMIT TRANSACTION (Staff edits a returned transaction and resubmits)
    elseif ($action === 'resubmit' && $type === 'transaction') {
        // Accept edited fields from the form
        $transaction_date = $_POST['transaction_date'] ?? '';
        $amount = (float)($_POST['amount'] ?? 0);
        $description = trim($_POST['description'] ?? '');

        // Basic validation
        if (empty($transaction_date) || $amount <= 0 || empty($description)) {
            $_SESSION['error'] = 'Data tidak valid untuk resubmit! Pastikan tanggal, nominal, dan deskripsi terisi.';
            header('Location: ' . $redirect);
            exit();
        }

        // Check transaction exists and is in 'returned' status
        $stmt = $conn->prepare("SELECT * FROM transactions WHERE id = ? AND status = 'returned'");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $transaction = $stmt->get_result()->fetch_assoc();

        if (!$transaction) {
            $_SESSION['error'] = 'Transaksi tidak ditemukan atau tidak berada pada status returned!';
            header('Location: ' . $redirect);
            exit();
        }

        // Only the original creator may resubmit
        if ($transaction['created_by'] != $user_id) {
            $_SESSION['error'] = 'Anda tidak berhak mengirim ulang transaksi ini!';
            header('Location: ' . $redirect);
            exit();
        }

        $conn->begin_transaction();
        try {
            // Update transaction: apply edits and reset status to pending
            $stmt = $conn->prepare("UPDATE transactions SET transaction_date = ?, amount = ?, description = ?, status = 'pending', rejection_reason = NULL, approved_by = NULL, approved_at = NULL WHERE id = ? AND status = 'returned'");
            $stmt->bind_param("sdsi", $transaction_date, $amount, $description, $id);
            $stmt->execute();

            // Log to approval history
            $notes = 'Transaksi dikirim ulang setelah revisi oleh ' . $_SESSION['full_name'];
            $stmt = $conn->prepare("INSERT INTO approval_history (transaction_type, transaction_id, action, user_id, notes) VALUES ('cashflow', ?, 'resubmitted', ?, ?)");
            $stmt->bind_param("iis", $id, $user_id, $notes);
            $stmt->execute();

            $conn->commit();
            $_SESSION['success'] = '✅ Transaksi berhasil dikirim ulang untuk approval!';

        } catch (Exception $e) {
            $conn->rollback();
            $_SESSION['error'] = '❌ Gagal mengirim ulang transaksi: ' . $e->getMessage();
        }
    }
    
    else {
        $_SESSION['error'] = 'Action tidak valid!';
    }
}

$conn->close();

// Redirect back
$redirect_url = $_POST['redirect'] ?? 'index.php';
header('Location: ' . $redirect_url);
exit();
?>