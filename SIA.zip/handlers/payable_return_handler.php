<?php
require_once __DIR__ . '/../includes/config.php';
checkLogin();

if (!isSupervisor()) {
    $_SESSION['error'] = 'Hanya supervisor yang dapat melakukan approve/reject/return hutang!';
    header('Location: payables.php');
    exit();
}

$conn = getDBConnection();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    $id = intval($_POST['id'] ?? 0);
    $reason = trim($_POST['reason'] ?? '');
    $user_id = $_SESSION['user_id'];
    
    if ($id <= 0) {
        $_SESSION['error'] = 'ID hutang tidak valid!';
        header('Location: payables.php');
        exit();
    }
    
    // Get payable details — allow items that are not yet approved (approved_at IS NULL)
    $stmt = $conn->prepare("SELECT * FROM payables WHERE id = ? AND approved_at IS NULL");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $payable = $stmt->get_result()->fetch_assoc();

    if (!$payable) {
        $_SESSION['error'] = 'Hutang tidak ditemukan atau sudah diproses!';
        header('Location: payables.php');
        exit();
    }
    
    // APPROVE PAYABLE
    if ($action === 'approve') {
        $conn->begin_transaction();
        
        try {
            // Update approval
            $stmt = $conn->prepare("UPDATE payables SET status = 'approved', approved_by = ?, approved_at = NOW() WHERE id = ?");
            $stmt->bind_param("ii", $user_id, $id);
            $stmt->execute();
            
                // Create journal entry
                $journal_desc = "Hutang ke " . $payable['supplier_name'] . " - " . $payable['description'];
                $stmt = $conn->prepare("INSERT INTO general_journal (journal_date, description, reference_id, reference_type) VALUES (CURDATE(), ?, ?, 'payable')");
                $stmt->bind_param("si", $journal_desc, $id);
                $stmt->execute();
                $journal_id = $stmt->insert_id;

                // Determine debit account based on category (asset vs expense)
                $expense_map = [
                    'operasional' => ['5-5100', 'Beban Operasional'],
                    'gaji' => ['5-5200', 'Beban Gaji'],
                    'utilitas' => ['5-5300', 'Beban Utilitas'],
                    'lain' => ['5-5400', 'Beban Lain-lain']
                ];

                $asset_map = [
                    'peralatan' => ['1-1400', 'Peralatan'],
                    'perlengkapan' => ['1-1300', 'Perlengkapan']
                ];

                $category = $payable['category'] ?? '';

                if (isset($asset_map[$category])) {
                    // Debit Asset
                    $account_code = $asset_map[$category][0];
                    $account_name = $asset_map[$category][1];
                    $stmt = $conn->prepare("INSERT INTO journal_entries (journal_id, account_code, account_name, debit, credit) VALUES (?, ?, ?, ?, 0)");
                    $stmt->bind_param("issd", $journal_id, $account_code, $account_name, $payable['total_amount']);
                    $stmt->execute();
                } else {
                    // Default to expense mapping
                    if (isset($expense_map[$category])) {
                        $account_code = $expense_map[$category][0];
                        $account_name = $expense_map[$category][1];
                    } else {
                        $account_code = '5-5100';
                        $account_name = 'Beban Operasional';
                    }
                    $stmt = $conn->prepare("INSERT INTO journal_entries (journal_id, account_code, account_name, debit, credit) VALUES (?, ?, ?, ?, 0)");
                    $stmt->bind_param("issd", $journal_id, $account_code, $account_name, $payable['total_amount']);
                    $stmt->execute();
                }

                // Credit: Hutang Usaha
                $stmt = $conn->prepare("INSERT INTO journal_entries (journal_id, account_code, account_name, debit, credit) VALUES (?, '2-2100', 'Hutang Usaha', 0, ?)");
                $stmt->bind_param("id", $journal_id, $payable['total_amount']);
                $stmt->execute();
            
            $conn->commit();
            $_SESSION['success'] = '✅ Hutang berhasil di-approve!';
            
        } catch (Exception $e) {
            $conn->rollback();
            $_SESSION['error'] = '❌ Gagal meng-approve hutang: ' . $e->getMessage();
        }
    }
    
    // REJECT PAYABLE
    elseif ($action === 'reject') {
        if (empty($reason) || strlen($reason) < 10) {
            $_SESSION['error'] = 'Alasan penolakan harus diisi minimal 10 karakter!';
            header('Location: payables.php');
            exit();
        }
        
        $conn->begin_transaction();
        
        try {
            $stmt = $conn->prepare("UPDATE payables SET status = 'rejected', notes = ?, approved_by = ?, approved_at = NOW() WHERE id = ?");
            $stmt->bind_param("sii", $reason, $user_id, $id);
            $stmt->execute();
            
            $conn->commit();
            $_SESSION['success'] = '✅ Hutang berhasil ditolak!';
            
        } catch (Exception $e) {
            $conn->rollback();
            $_SESSION['error'] = '❌ Gagal menolak hutang: ' . $e->getMessage();
        }
    }
    
    // RETURN PAYABLE (Kembalikan untuk diedit staff)
    elseif ($action === 'return') {
        if (empty($reason) || strlen($reason) < 10) {
            $_SESSION['error'] = 'Alasan pengembalian harus diisi minimal 10 karakter!';
            header('Location: payables.php');
            exit();
        }
        
        $conn->begin_transaction();
        
        try {
            $stmt = $conn->prepare("UPDATE payables SET status = 'returned', notes = ?, approved_by = ?, approved_at = NOW() WHERE id = ?");
            $stmt->bind_param("sii", $reason, $user_id, $id);
            $stmt->execute();
            
            $conn->commit();
            $_SESSION['success'] = '🔄 Hutang berhasil dikembalikan ke staff untuk revisi!';
            
        } catch (Exception $e) {
            $conn->rollback();
            $_SESSION['error'] = '❌ Gagal mengembalikan hutang: ' . $e->getMessage();
        }
    }
    
    else {
        $_SESSION['error'] = 'Action tidak valid!';
    }
}

$conn->close();
header('Location: payables.php');
exit();
?>
