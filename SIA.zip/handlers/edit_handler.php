<?php
/**
 * EDIT HANDLERS
 * Menangani edit untuk transactions dan assets
 * Hanya staff yang bisa edit, dan hanya untuk status pending
 */

require_once __DIR__ . '/../includes/config.php';
checkLogin();

$conn = getDBConnection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    // EDIT TRANSACTION
    if ($action === 'edit_transaction') {
        // Check permission
        requirePermission('cashflow', 'edit');
        
        $id = (int)($_POST['id'] ?? 0);
        $transaction_date = $_POST['transaction_date'] ?? '';
        $transaction_type = $_POST['transaction_type'] ?? '';
        $category = $_POST['category'] ?? '';
        $description = trim($_POST['description'] ?? '');
        $amount = (float)($_POST['amount'] ?? 0);
        
        // Validate
        if (empty($transaction_date) || empty($transaction_type) || empty($category) || empty($description) || $amount <= 0) {
            $_SESSION['error'] = 'Semua field harus diisi!';
            header('Location: cashflow.php');
            exit();
        }
        
        // Check if transaction is pending and belongs to user (staff can only edit their own)
        $stmt = $conn->prepare("SELECT * FROM transactions WHERE id = ? AND status = 'pending'");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $transaction = $stmt->get_result()->fetch_assoc();
        
        if (!$transaction) {
            $_SESSION['error'] = 'Transaksi tidak ditemukan atau sudah diapprove!';
            header('Location: cashflow.php');
            exit();
        }
        
        // Staff can only edit their own
        if (isStaff() && $transaction['created_by'] != $_SESSION['user_id']) {
            $_SESSION['error'] = 'Anda hanya bisa edit transaksi Anda sendiri!';
            header('Location: cashflow.php');
            exit();
        }
        
        // Update transaction
        $stmt = $conn->prepare("UPDATE transactions SET 
            transaction_date = ?, 
            transaction_type = ?, 
            category = ?, 
            description = ?, 
            amount = ?
            WHERE id = ? AND status = 'pending'");
        $stmt->bind_param("ssssdi", $transaction_date, $transaction_type, $category, $description, $amount, $id);
        
        if ($stmt->execute() && $stmt->affected_rows > 0) {
            $_SESSION['success'] = 'Transaksi berhasil diupdate!';
        } else {
            $_SESSION['error'] = 'Gagal mengupdate transaksi!';
        }
        
        header('Location: cashflow.php');
        exit();
    }
    
    // EDIT ASSET
    elseif ($action === 'edit_asset') {
        // Check permission
        requirePermission('assets', 'edit');
        
        $id = (int)($_POST['id'] ?? 0);
        $asset_name = trim($_POST['asset_name'] ?? '');
        $category = $_POST['category'] ?? '';
        $purchase_date = $_POST['purchase_date'] ?? '';
        $purchase_price = (float)($_POST['purchase_price'] ?? 0);
        $current_value = (float)($_POST['current_value'] ?? 0);
        
        // Validate
        if (empty($asset_name) || empty($category) || empty($purchase_date) || $purchase_price <= 0) {
            $_SESSION['error'] = 'Semua field harus diisi!';
            header('Location: assets.php');
            exit();
        }
        
        // If current_value empty, use purchase_price
        if ($current_value == 0) {
            $current_value = $purchase_price;
        }
        
        // Check if asset is pending and belongs to user
        $stmt = $conn->prepare("SELECT * FROM assets WHERE id = ? AND status = 'pending'");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $asset = $stmt->get_result()->fetch_assoc();
        
        if (!$asset) {
            $_SESSION['error'] = 'Aset tidak ditemukan atau sudah diapprove!';
            header('Location: assets.php');
            exit();
        }
        
        // Staff can only edit their own
        if (isStaff() && $asset['created_by'] != $_SESSION['user_id']) {
            $_SESSION['error'] = 'Anda hanya bisa edit aset Anda sendiri!';
            header('Location: assets.php');
            exit();
        }
        
        // Update asset
        $stmt = $conn->prepare("UPDATE assets SET 
            asset_name = ?, 
            category = ?, 
            purchase_date = ?, 
            purchase_price = ?, 
            current_value = ?
            WHERE id = ? AND status = 'pending'");
        $stmt->bind_param("sssddi", $asset_name, $category, $purchase_date, $purchase_price, $current_value, $id);
        
        if ($stmt->execute() && $stmt->affected_rows > 0) {
            $_SESSION['success'] = 'Aset berhasil diupdate!';
        } else {
            $_SESSION['error'] = 'Gagal mengupdate aset!';
        }
        
        header('Location: assets.php');
        exit();
    }
    
    // DELETE TRANSACTION (Soft delete - set status rejected)
    elseif ($action === 'delete_transaction') {
        requirePermission('cashflow', 'delete');
        
        $id = (int)($_POST['id'] ?? 0);
        
        // Check if pending
        $stmt = $conn->prepare("SELECT * FROM transactions WHERE id = ? AND status = 'pending'");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $transaction = $stmt->get_result()->fetch_assoc();
        
        if (!$transaction) {
            $_SESSION['error'] = 'Transaksi tidak bisa dihapus!';
            header('Location: cashflow.php');
            exit();
        }
        
        // Soft delete (ubah status jadi rejected dengan alasan)
        $reason = "Dihapus oleh user";
        $user_id = $_SESSION['user_id'];
        $stmt = $conn->prepare("UPDATE transactions SET status = 'rejected', rejection_reason = ?, approved_by = ? WHERE id = ?");
        $stmt->bind_param("sii", $reason, $user_id, $id);
        
        if ($stmt->execute()) {
            $_SESSION['success'] = 'Transaksi berhasil dihapus!';
        } else {
            $_SESSION['error'] = 'Gagal menghapus transaksi!';
        }
        
        header('Location: cashflow.php');
        exit();
    }
    
    // DELETE ASSET
    elseif ($action === 'delete_asset') {
        requirePermission('assets', 'delete');
        
        $id = (int)($_POST['id'] ?? 0);
        
        // Check if pending
        $stmt = $conn->prepare("SELECT * FROM assets WHERE id = ? AND status = 'pending'");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $asset = $stmt->get_result()->fetch_assoc();
        
        if (!$asset) {
            $_SESSION['error'] = 'Aset tidak bisa dihapus!';
            header('Location: assets.php');
            exit();
        }
        
        // Soft delete
        $reason = "Dihapus oleh user";
        $user_id = $_SESSION['user_id'];
        $stmt = $conn->prepare("UPDATE assets SET status = 'rejected', rejection_reason = ?, approved_by = ? WHERE id = ?");
        $stmt->bind_param("sii", $reason, $user_id, $id);
        
        if ($stmt->execute()) {
            $_SESSION['success'] = 'Aset berhasil dihapus!';
        } else {
            $_SESSION['error'] = 'Gagal menghapus aset!';
        }
        
        header('Location: assets.php');
        exit();
    }
}

$conn->close();
header('Location: index.php');
exit();
?>
