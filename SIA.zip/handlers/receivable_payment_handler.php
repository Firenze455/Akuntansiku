<?php
require_once __DIR__ . '/../includes/config.php';
checkLogin();

$conn = getDBConnection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $receivable_id = (int)($_POST['receivable_id'] ?? 0);
    $payment_date = $_POST['payment_date'] ?? '';
    $amount = (float)($_POST['amount'] ?? 0);
    $payment_method = $_POST['payment_method'] ?? 'tunai';
    $notes = trim($_POST['notes'] ?? '');
    $user_id = $_SESSION['user_id'];
    
    // Validate
    if ($receivable_id <= 0 || empty($payment_date) || $amount <= 0) {
        $_SESSION['error'] = 'Data tidak valid!';
        header('Location: receivables.php');
        exit();
    }
    
    // Get receivable data
    $stmt = $conn->prepare("SELECT * FROM receivables WHERE id = ?");
    $stmt->bind_param("i", $receivable_id);
    $stmt->execute();
    $receivable = $stmt->get_result()->fetch_assoc();
    
    if (!$receivable) {
        $_SESSION['error'] = 'Piutang tidak ditemukan!';
        header('Location: receivables.php');
        exit();
    }
    
    // Check if already paid
    if ($receivable['status'] === 'paid') {
        $_SESSION['error'] = 'Piutang sudah lunas!';
        header('Location: receivables.php');
        exit();
    }
    
    // Check if amount exceeds remaining
    if ($amount > $receivable['remaining_amount']) {
        $_SESSION['error'] = 'Jumlah pembayaran melebihi sisa piutang!';
        header('Location: receivables.php');
        exit();
    }
    
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // Jika catatan kosong, isi default
        if ($notes === '') {
            $notes = 'Pembayaran piutang (' . ucfirst($payment_method) . ')';
        }
        // Insert payment
        $stmt = $conn->prepare("INSERT INTO receivable_payments (receivable_id, payment_date, amount, payment_method, notes, created_by) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("isdssi", $receivable_id, $payment_date, $amount, $payment_method, $notes, $user_id);
        $stmt->execute();
        $payment_id = $conn->insert_id;

        // Update receivable
        $new_paid = ($receivable['paid_amount'] ?? 0) + $amount;
        $new_remaining = $receivable['total_amount'] - $new_paid;
        if ($new_remaining < 0) $new_remaining = 0;
        $new_status = $new_remaining <= 0 ? 'paid' : 'partial';

        $stmt = $conn->prepare("UPDATE receivables SET paid_amount = ?, remaining_amount = ?, status = ? WHERE id = ?");
        $stmt->bind_param("ddsi", $new_paid, $new_remaining, $new_status, $receivable_id);
        $stmt->execute();

        // Create journal entry
        $description = "Pembayaran piutang dari " . $receivable['customer_name'] . " - " . $receivable['ref_code'];
        $stmt = $conn->prepare("INSERT INTO general_journal (journal_date, description, reference_id, reference_type) VALUES (?, ?, ?, 'receivable_payment')");
        $stmt->bind_param("ssi", $payment_date, $description, $receivable_id);
        $stmt->execute();
        $journal_id = $conn->insert_id;

        // Update the specific payment row with journal_id
        $stmt = $conn->prepare("UPDATE receivable_payments SET journal_id = ? WHERE id = ?");
        $stmt->bind_param("ii", $journal_id, $payment_id);
        $stmt->execute();
        
        // Debit: Kas
        $account_code = '1-1100';
        $account_name = 'Kas';
        $stmt = $conn->prepare("INSERT INTO journal_entries (journal_id, account_code, account_name, debit, credit) VALUES (?, ?, ?, ?, 0)");
        $stmt->bind_param("issd", $journal_id, $account_code, $account_name, $amount);
        $stmt->execute();
        
        // Credit: Piutang Usaha
        $account_code = '1-1200';
        $account_name = 'Piutang Usaha';
        $stmt = $conn->prepare("INSERT INTO journal_entries (journal_id, account_code, account_name, debit, credit) VALUES (?, ?, ?, 0, ?)");
        $stmt->bind_param("issd", $journal_id, $account_code, $account_name, $amount);
        $stmt->execute();
        
        $conn->commit();
        
        $_SESSION['success'] = '✅ Pembayaran berhasil dicatat! ' . ($new_status === 'paid' ? 'Piutang LUNAS!' : 'Sisa: ' . formatRupiah($new_remaining));
        
    } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['error'] = '❌ Gagal memproses pembayaran: ' . $e->getMessage();
    }
}

$conn->close();
header('Location: receivables.php');
exit();
?>