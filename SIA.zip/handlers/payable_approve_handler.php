<?php
require_once __DIR__ . '/../includes/config.php';
checkLogin();

// Check permission
if (!isSupervisor()) {
    $_SESSION['error'] = 'Anda tidak memiliki akses untuk approve hutang!';
    header('Location: payables.php');
    exit();
}

$conn = getDBConnection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $id = (int)($_POST['id'] ?? 0);
    $user_id = $_SESSION['user_id'];
    
    if ($action === 'approve' && $id > 0) {
        // Get payable
        $stmt = $conn->prepare("SELECT * FROM payables WHERE id = ? AND approved_at IS NULL");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $payable = $stmt->get_result()->fetch_assoc();
        
        if (!$payable) {
            $_SESSION['error'] = 'Hutang tidak ditemukan atau sudah diapprove!';
            header('Location: payables.php');
            exit();
        }
        
        $conn->begin_transaction();
        
        try {
            // Approve payable
            $stmt = $conn->prepare("UPDATE payables SET approved_by = ?, approved_at = NOW() WHERE id = ?");
            $stmt->bind_param("ii", $user_id, $id);
            $stmt->execute();
            
            // Create journal entry
            $description = "Hutang ke " . $payable['supplier_name'] . " - " . $payable['description'];
            $stmt = $conn->prepare("INSERT INTO general_journal (journal_date, description, reference_id, reference_type) VALUES (CURDATE(), ?, ?, 'payable')");
            $stmt->bind_param("si", $description, $id);
            $stmt->execute();
            $journal_id = $conn->insert_id;
            
            // Debit: Beban Operasional (bisa disesuaikan dengan kategori)
            $stmt = $conn->prepare("INSERT INTO journal_entries (journal_id, account_code, account_name, debit, credit) VALUES (?, '5-5100', 'Beban Operasional', ?, 0)");
            $stmt->bind_param("id", $journal_id, $payable['total_amount']);
            $stmt->execute();
            
            // Credit: Hutang Usaha
            $stmt = $conn->prepare("INSERT INTO journal_entries (journal_id, account_code, account_name, debit, credit) VALUES (?, '2-2100', 'Hutang Usaha', 0, ?)");
            $stmt->bind_param("id", $journal_id, $payable['total_amount']);
            $stmt->execute();
            
            $conn->commit();
            
            $_SESSION['success'] = '✅ Hutang berhasil di-APPROVE dan tercatat dalam jurnal!';
            
        } catch (Exception $e) {
            $conn->rollback();
            $_SESSION['error'] = '❌ Gagal approve hutang: ' . $e->getMessage();
        }
    }
}

$conn->close();
header('Location: payables.php');
exit();
?>
