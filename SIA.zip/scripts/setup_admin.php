<?php
/**
 * SETUP USER ADMIN
 * 
 * Script ini akan membuat user admin dengan password: admin123
 * Jalankan script ini sekali saja setelah database diimport
 * 
 * Cara menggunakan:
 * 1. Akses via browser: http://localhost/sistem-akuntansi/setup_admin.php
 * 2. Atau jalankan via terminal: php setup_admin.php
 */

require_once __DIR__ . '/../includes/config.php';

// Cek apakah diakses via browser
$is_browser = php_sapi_name() !== 'cli';

if ($is_browser) {
    echo "<!DOCTYPE html>
    <html lang='id'>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>Setup Admin User</title>
        <script src='https://cdn.tailwindcss.com'></script>
    </head>
    <body class='bg-gradient-to-br from-blue-50 to-indigo-100 min-h-screen flex items-center justify-center p-4'>
        <div class='bg-white rounded-lg shadow-xl p-8 max-w-2xl w-full'>";
}

echo $is_browser ? "<h1 class='text-2xl font-bold text-gray-800 mb-6'>🔧 Setup Admin User</h1>" : "=== Setup Admin User ===\n\n";

try {
    $conn = getDBConnection();
    
    // Data user default
    $username = 'admin';
    $password = 'admin123';
    $full_name = 'Administrator';
    
    // Hash password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    // Cek apakah user admin sudah ada
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        // Update password yang ada
        $stmt = $conn->prepare("UPDATE users SET password = ?, full_name = ? WHERE username = ?");
        $stmt->bind_param("sss", $hashed_password, $full_name, $username);
        $stmt->execute();
        
        if ($is_browser) {
            echo "<div class='bg-green-50 border border-green-200 rounded-lg p-6 mb-6'>
                <h2 class='text-lg font-bold text-green-800 mb-3'>✅ User Admin Berhasil Diupdate!</h2>
                <div class='space-y-2 text-sm text-green-700'>
                    <p>Password user admin telah diperbarui.</p>
                </div>
            </div>";
        } else {
            echo "✅ User admin berhasil diupdate!\n\n";
        }
    } else {
        // Insert user baru
        $stmt = $conn->prepare("INSERT INTO users (username, password, full_name) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $username, $hashed_password, $full_name);
        $stmt->execute();
        
        if ($is_browser) {
            echo "<div class='bg-green-50 border border-green-200 rounded-lg p-6 mb-6'>
                <h2 class='text-lg font-bold text-green-800 mb-3'>✅ User Admin Berhasil Dibuat!</h2>
                <div class='space-y-2 text-sm text-green-700'>
                    <p>User admin baru telah ditambahkan ke database.</p>
                </div>
            </div>";
        } else {
            echo "✅ User admin berhasil dibuat!\n\n";
        }
    }
    
    // Tampilkan informasi login
    if ($is_browser) {
        echo "
        <div class='bg-blue-50 border border-blue-200 rounded-lg p-6 mb-6'>
            <h3 class='font-bold text-blue-800 mb-3'>🔐 Informasi Login:</h3>
            <div class='space-y-2'>
                <div class='flex justify-between items-center bg-white p-3 rounded'>
                    <span class='text-sm text-gray-600'>Username:</span>
                    <code class='font-mono font-bold text-blue-600'>{$username}</code>
                </div>
                <div class='flex justify-between items-center bg-white p-3 rounded'>
                    <span class='text-sm text-gray-600'>Password:</span>
                    <code class='font-mono font-bold text-blue-600'>{$password}</code>
                </div>
            </div>
        </div>
        
        <div class='bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6'>
            <p class='text-sm text-yellow-800'>
                <strong>⚠️ Penting:</strong> Setelah berhasil login, segera hapus file 
                <code class='bg-yellow-100 px-2 py-1 rounded'>setup_admin.php</code> 
                dari server untuk keamanan!
            </p>
        </div>
        
        <div class='space-y-3'>
            <a href='login.php' 
               class='block w-full bg-blue-600 text-white text-center py-3 px-4 rounded-lg hover:bg-blue-700 transition-colors font-medium'>
                🔐 Login Sekarang
            </a>
            
            <details class='bg-gray-50 rounded-lg p-4'>
                <summary class='cursor-pointer text-sm font-medium text-gray-700'>
                    📋 Informasi Teknis (klik untuk lihat)
                </summary>
                <div class='mt-3 text-xs text-gray-600 space-y-1'>
                    <p><strong>Password Hash:</strong></p>
                    <code class='block bg-white p-2 rounded break-all font-mono'>{$hashed_password}</code>
                    <p class='mt-2'><strong>Hash Method:</strong> bcrypt (PASSWORD_DEFAULT)</p>
                    <p><strong>Hash Cost:</strong> 10 (default)</p>
                </div>
            </details>
        </div>";
    } else {
        echo "Informasi Login:\n";
        echo "Username: {$username}\n";
        echo "Password: {$password}\n\n";
        echo "Password Hash: {$hashed_password}\n\n";
        echo "⚠️  PENTING: Hapus file setup_admin.php setelah berhasil login!\n\n";
    }
    
    $stmt->close();
    $conn->close();
    
} catch (Exception $e) {
    if ($is_browser) {
        echo "<div class='bg-red-50 border border-red-200 rounded-lg p-6'>
            <h3 class='font-bold text-red-800 mb-2'>❌ Error!</h3>
            <p class='text-sm text-red-700'>{$e->getMessage()}</p>
            <div class='mt-4 text-xs text-red-600'>
                <p><strong>Troubleshooting:</strong></p>
                <ul class='list-disc ml-4 mt-2 space-y-1'>
                    <li>Pastikan MySQL sudah running</li>
                    <li>Pastikan database 'sistem_akuntansi' sudah dibuat</li>
                    <li>Pastikan file config.php sudah benar</li>
                    <li>Pastikan tabel 'users' sudah ada</li>
                </ul>
            </div>
        </div>";
    } else {
        echo "❌ Error: " . $e->getMessage() . "\n";
    }
}

if ($is_browser) {
    echo "
        </div>
    </body>
    </html>";
}
?>
