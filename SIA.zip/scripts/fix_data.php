<?php
/**
 * FIX DATA SCRIPT
 * 
 * Script ini akan:
 * 1. Fix kode akun yang salah (May-00, Apr-00, dll)
 * 2. Update journal entries dengan kode akun yang benar
 * 
 * CARA MENGGUNAKAN:
 * 1. Upload file ini ke folder sistem-akuntansi
 * 2. Akses via browser: http://localhost/sistem-akuntansi/fix_data.php
 * 3. Script akan otomatis fix data
 * 4. Hapus file ini setelah selesai!
 */

require_once __DIR__ . '/../includes/config.php';
checkLogin();

$conn = getDBConnection();

echo "<!DOCTYPE html>
<html lang='id'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Fix Data</title>
    <script src='https://cdn.tailwindcss.com'></script>
</head>
<body class='bg-gray-50 p-8'>
    <div class='max-w-4xl mx-auto bg-white rounded-lg shadow-lg p-8'>
        <h1 class='text-2xl font-bold text-gray-800 mb-6'>🔧 Fix Data Script</h1>";

$fixed_count = 0;
$errors = [];

// Mapping kode akun yang salah ke yang benar
$account_fixes = [
    'May-00' => ['5-5300', 'Beban Utilitas'],      // Utilitas (listrik, air, dll)
    'Apr-00' => ['4-4200', 'Pendapatan Lain-lain'], // Pendapatan lain
    'Jan-00' => ['5-5100', 'Beban Operasional'],    // Beban operasional
    'Feb-00' => ['5-5200', 'Beban Gaji'],           // Gaji
    'Mar-00' => ['5-5100', 'Beban Operasional'],    // Operasional
    'Jun-00' => ['5-5400', 'Beban Lain-lain'],      // Beban lain
    'Jul-00' => ['4-4100', 'Pendapatan'], // Pendapatan (dulu Penjualan)
    'Aug-00' => ['5-5100', 'Beban Operasional'],    // Operasional
    'Sep-00' => ['5-5100', 'Beban Operasional'],    // Operasional
    'Oct-00' => ['5-5100', 'Beban Operasional'],    // Operasional
    'Nov-00' => ['5-5100', 'Beban Operasional'],    // Operasional
    'Dec-00' => ['5-5100', 'Beban Operasional']     // Operasional
];

echo "<div class='mb-6'>
        <h2 class='text-lg font-semibold text-gray-800 mb-3'>📊 Scanning Database...</h2>
      </div>";

// Get semua journal entries dengan kode akun yang salah
$query = "SELECT * 
          FROM journal_entries 
          WHERE account_code NOT REGEXP '^[1-5]-[0-9]{4}$|^[1-5][0-9]{3}$'";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    echo "<div class='bg-yellow-50 border border-yellow-300 rounded p-4 mb-4'>
            <p class='text-yellow-800 font-medium'>⚠️ Ditemukan " . $result->num_rows . " entries dengan kode akun yang salah!</p>
          </div>";
    
    echo "<div class='bg-white border rounded-lg overflow-hidden mb-6'>
            <table class='w-full text-sm'>
                <thead class='bg-gray-100'>
                    <tr>
                        <th class='px-4 py-2 text-left'>ID</th>
                        <th class='px-4 py-2 text-left'>Kode Lama</th>
                        <th class='px-4 py-2 text-left'>Kode Baru</th>
                        <th class='px-4 py-2 text-left'>Nama Akun Baru</th>
                        <th class='px-4 py-2 text-left'>Status</th>
                    </tr>
                </thead>
                <tbody>";
    
    while ($row = $result->fetch_assoc()) {
        $old_code = $row['account_code'];
        $entry_id = $row['id'];
        
        // Cari kode yang benar
        $new_code = null;
        $new_name = null;
        
        if (isset($account_fixes[$old_code])) {
            $new_code = $account_fixes[$old_code][0];
            $new_name = $account_fixes[$old_code][1];
        } else {
            // Jika kode tidak ada di mapping, coba deteksi dari nama akun
            $account_name = strtolower($row['account_name']);
            
            if (strpos($account_name, 'utilitas') !== false || strpos($account_name, 'listrik') !== false || strpos($account_name, 'air') !== false) {
                $new_code = '5-5300';
                $new_name = 'Beban Utilitas';
            } elseif (strpos($account_name, 'gaji') !== false) {
                $new_code = '5-5200';
                $new_name = 'Beban Gaji';
            } elseif (strpos($account_name, 'pendapatan') !== false && strpos($account_name, 'lain') !== false) {
                $new_code = '4-4200';
                $new_name = 'Pendapatan Lain-lain';
            } elseif (strpos($account_name, 'pendapatan') !== false || strpos($account_name, 'penjualan') !== false) {
                $new_code = '4-4100';
                $new_name = 'Pendapatan';
            } else {
                $new_code = '5-5100';
                $new_name = 'Beban Operasional';
            }
        }
        
        // Update entry
        $stmt = $conn->prepare("UPDATE journal_entries SET account_code = ?, account_name = ? WHERE id = ?");
        $stmt->bind_param("ssi", $new_code, $new_name, $entry_id);
        
        if ($stmt->execute()) {
            $fixed_count++;
            $status = "<span class='text-green-600'>✓ Fixed</span>";
        } else {
            $errors[] = "Failed to update entry ID: $entry_id";
            $status = "<span class='text-red-600'>✗ Error</span>";
        }
        
        echo "<tr class='border-t'>
                <td class='px-4 py-2'>{$entry_id}</td>
                <td class='px-4 py-2'><code class='bg-red-100 px-2 py-1 rounded'>{$old_code}</code></td>
                <td class='px-4 py-2'><code class='bg-green-100 px-2 py-1 rounded'>{$new_code}</code></td>
                <td class='px-4 py-2'>{$new_name}</td>
                <td class='px-4 py-2'>{$status}</td>
              </tr>";
    }
    
    echo "</tbody></table></div>";
} else {
    echo "<div class='bg-green-50 border border-green-300 rounded p-4 mb-4'>
            <p class='text-green-800 font-medium'>✓ Tidak ada kode akun yang salah!</p>
          </div>";
}

// Summary
echo "<div class='bg-blue-50 border border-blue-300 rounded-lg p-6 mb-6'>
        <h2 class='text-lg font-semibold text-blue-900 mb-3'>📊 Summary:</h2>
        <ul class='space-y-2 text-blue-800'>
            <li><strong>Total entries difix:</strong> {$fixed_count}</li>
            <li><strong>Errors:</strong> " . count($errors) . "</li>
        </ul>
      </div>";

if (count($errors) > 0) {
    echo "<div class='bg-red-50 border border-red-300 rounded p-4 mb-4'>
            <p class='text-red-800 font-medium mb-2'>❌ Errors:</p>
            <ul class='list-disc list-inside text-sm text-red-700'>";
    foreach ($errors as $error) {
        echo "<li>{$error}</li>";
    }
    echo "</ul></div>";
}

echo "<div class='bg-yellow-50 border border-yellow-300 rounded-lg p-6 mb-6'>
        <h2 class='text-lg font-semibold text-yellow-900 mb-3'>⚠️ PENTING:</h2>
        <ul class='space-y-2 text-yellow-800 text-sm'>
            <li>✓ Data sudah difix</li>
            <li>✓ Refresh halaman Jurnal Umum untuk melihat perubahan</li>
            <li>⚠️ <strong>HAPUS file fix_data.php setelah selesai!</strong></li>
        </ul>
      </div>";

echo "<div class='flex space-x-4'>
        <a href='journal.php' class='bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors'>
            Lihat Jurnal Umum
        </a>
        <a href='index.php' class='bg-gray-600 text-white px-6 py-3 rounded-lg hover:bg-gray-700 transition-colors'>
            Kembali ke Dashboard
        </a>
      </div>";

echo "</div></body></html>";

$conn->close();
?>
