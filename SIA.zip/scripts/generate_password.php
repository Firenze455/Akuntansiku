<?php
/**
 * PASSWORD GENERATOR UTILITY
 * 
 * File ini digunakan untuk generate password hash
 * untuk menambahkan user baru ke database
 * 
 * Cara penggunaan:
 * 1. Akses file ini via browser: http://localhost/sistem-akuntansi/generate_password.php
 * 2. Atau jalankan via terminal: php generate_password.php
 */

// Jika diakses via browser
if (php_sapi_name() !== 'cli') {
    echo "<!DOCTYPE html>
    <html lang='id'>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>Password Generator</title>
        <script src='https://cdn.tailwindcss.com'></script>
    </head>
    <body class='bg-gray-100 min-h-screen flex items-center justify-center p-4'>
        <div class='bg-white rounded-lg shadow-lg p-8 max-w-2xl w-full'>
            <h1 class='text-2xl font-bold text-gray-800 mb-6'>🔐 Password Hash Generator</h1>
            
            <div class='bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6'>
                <p class='text-sm text-blue-800'>
                    <strong>Cara menggunakan:</strong><br>
                    1. Masukkan password yang diinginkan<br>
                    2. Klik Generate<br>
                    3. Copy hash yang dihasilkan<br>
                    4. Insert ke database dengan query SQL
                </p>
            </div>";
    
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['password'])) {
        $password = $_POST['password'];
        $username = $_POST['username'];
        $full_name = $_POST['full_name'];
        $hash = password_hash($password, PASSWORD_DEFAULT);
        
        echo "
            <div class='bg-green-50 border border-green-200 rounded-lg p-4 mb-4'>
                <h3 class='font-bold text-green-800 mb-2'>✅ Hash Berhasil Dibuat!</h3>
                <div class='space-y-3'>
                    <div>
                        <p class='text-sm text-gray-600 mb-1'>Username:</p>
                        <code class='bg-gray-100 px-3 py-2 rounded block font-mono text-sm'>{$username}</code>
                    </div>
                    <div>
                        <p class='text-sm text-gray-600 mb-1'>Password:</p>
                        <code class='bg-gray-100 px-3 py-2 rounded block font-mono text-sm'>{$password}</code>
                    </div>
                    <div>
                        <p class='text-sm text-gray-600 mb-1'>Password Hash:</p>
                        <code class='bg-gray-100 px-3 py-2 rounded block font-mono text-xs break-all'>{$hash}</code>
                    </div>
                </div>
            </div>
            
            <div class='bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-4'>
                <h3 class='font-bold text-yellow-800 mb-2'>📋 Query SQL untuk Insert User Baru:</h3>
                <pre class='bg-gray-800 text-green-400 p-4 rounded overflow-x-auto text-xs'>INSERT INTO users (username, password, full_name) 
VALUES ('{$username}', '{$hash}', '{$full_name}');</pre>
                <p class='text-xs text-yellow-700 mt-2'>
                    Copy query di atas, lalu jalankan di phpMyAdmin → SQL
                </p>
            </div>";
    }
    
    echo "
            <form method='POST' class='space-y-4'>
                <div>
                    <label class='block text-sm font-medium text-gray-700 mb-1'>Username</label>
                    <input type='text' name='username' required
                           class='w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500'
                           placeholder='Contoh: user1'>
                </div>
                
                <div>
                    <label class='block text-sm font-medium text-gray-700 mb-1'>Nama Lengkap</label>
                    <input type='text' name='full_name' required
                           class='w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500'
                           placeholder='Contoh: John Doe'>
                </div>
                
                <div>
                    <label class='block text-sm font-medium text-gray-700 mb-1'>Password</label>
                    <input type='text' name='password' required
                           class='w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500'
                           placeholder='Masukkan password yang diinginkan'>
                </div>
                
                <button type='submit' 
                        class='w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors font-medium'>
                    🔑 Generate Password Hash
                </button>
            </form>
            
            <div class='mt-6 p-4 bg-gray-50 rounded-lg'>
                <p class='text-xs text-gray-600'>
                    <strong>Catatan:</strong> Password akan di-hash menggunakan algoritma bcrypt.
                    Hash ini yang akan disimpan ke database untuk keamanan.
                </p>
            </div>
            
            <div class='mt-4 text-center'>
                <a href='login.php' class='text-blue-600 hover:text-blue-700 text-sm'>
                    ← Kembali ke Login
                </a>
            </div>
        </div>
    </body>
    </html>";
    
} else {
    // Jika dijalankan via CLI
    echo "=== Password Hash Generator ===\n\n";
    
    echo "Username: ";
    $username = trim(fgets(STDIN));
    
    echo "Nama Lengkap: ";
    $full_name = trim(fgets(STDIN));
    
    echo "Password: ";
    $password = trim(fgets(STDIN));
    
    $hash = password_hash($password, PASSWORD_DEFAULT);
    
    echo "\n✅ Hash berhasil dibuat!\n\n";
    echo "Username: {$username}\n";
    echo "Password: {$password}\n";
    echo "Hash: {$hash}\n\n";
    
    echo "Query SQL:\n";
    echo "INSERT INTO users (username, password, full_name) VALUES ('{$username}', '{$hash}', '{$full_name}');\n\n";
}
?>
