<?php
/**
 * 🔒 SECRET DATABASE RESET TOOL
 * 
 * PERINGATAN: File ini akan menghapus SEMUA data transaksi!
 * Gunakan HANYA untuk testing/development!
 * 
 * Akses: /secret_reset_database.php
 * Password Default: RESET2025
 */

// Start session
session_start();

// Password untuk akses (GANTI INI!)
define('RESET_PASSWORD', 'RESET2025');

// Flag untuk konfirmasi (proteksi double-check)
$reset_confirmed = false;
$message = '';
$error = '';

// Handle reset request
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $input_password = $_POST['password'] ?? '';
    $confirm_text = $_POST['confirm_text'] ?? '';
    
    // Check password
    if ($input_password !== RESET_PASSWORD) {
        $error = '❌ Password salah!';
    }
    // Check confirmation text
    elseif (strtoupper($confirm_text) !== 'RESET SEMUA DATA') {
        $error = '❌ Konfirmasi tidak sesuai! Ketik: RESET SEMUA DATA';
    }
    // Execute reset
    else {
        require_once __DIR__ . '/../includes/config.php';
        $conn = getDBConnection();
        
        if (!$conn) {
            $error = '❌ Gagal koneksi database!';
        } else {
            // Start transaction
            $conn->begin_transaction();
            
            try {
                // Array of tables to reset (EXCLUDING users, permissions, chart_of_accounts)
                $tables_to_reset = [
                    'approval_history',
                    'assets',
                    'receivables',
                    'receivable_payments',
                    'payables',
                    'payable_payments',
                    'transactions',
                    'general_journal',
                    'journal_entries',
                    'customers',
                    'suppliers',
                    // Legacy tables (if exist)
                    'piutang',
                    'pembayaran_piutang',
                    'hutang',
                    'pembayaran_hutang'
                ];
                
                $reset_count = 0;
                $reset_log = [];
                
                // Disable foreign key checks temporarily
                $conn->query("SET FOREIGN_KEY_CHECKS = 0");
                
                // Delete data from each table
                foreach ($tables_to_reset as $table) {
                    // Check if table exists
                    $check = $conn->query("SHOW TABLES LIKE '$table'");
                    if ($check && $check->num_rows > 0) {
                        $result = $conn->query("DELETE FROM `$table`");
                        if ($result) {
                            $affected = $conn->affected_rows;
                            $reset_log[] = "✅ $table: $affected rows dihapus";
                            $reset_count++;
                            
                            // Reset auto increment
                            $conn->query("ALTER TABLE `$table` AUTO_INCREMENT = 1");
                        } else {
                            $reset_log[] = "⚠️ $table: Gagal - " . $conn->error;
                        }
                    } else {
                        $reset_log[] = "⚠️ $table: Tabel tidak ditemukan";
                    }
                }
                
                // Re-enable foreign key checks
                $conn->query("SET FOREIGN_KEY_CHECKS = 1");
                
                // Commit transaction
                $conn->commit();
                
                // Success message
                $message = "
                    <div class='bg-green-100 border-l-4 border-green-500 p-4 mb-4'>
                        <h3 class='text-lg font-bold text-green-800'>✅ RESET BERHASIL!</h3>
                        <p class='text-green-700 mt-2'>$reset_count tabel berhasil direset</p>
                        <div class='mt-4 space-y-1'>
                            " . implode('<br>', $reset_log) . "
                        </div>
                        <p class='text-sm text-green-600 mt-4'>
                            <strong>Yang TIDAK dihapus:</strong>
                            <br>• Users (akun login tetap ada)
                            <br>• Permissions (hak akses tetap ada)
                            <br>• Chart of Accounts (akun perkiraan tetap ada)
                        </p>
                    </div>
                ";
                
                $reset_confirmed = true;
                
            } catch (Exception $e) {
                $conn->rollback();
                $error = '❌ Error: ' . $e->getMessage();
            }
            
            $conn->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🔒 Secret Reset Database</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center p-4">
    <div class="max-w-2xl w-full bg-white rounded-lg shadow-2xl p-8">
        <!-- Header -->
        <div class="text-center mb-8">
            <div class="text-6xl mb-4">🔒</div>
            <h1 class="text-3xl font-bold text-gray-800 mb-2">Secret Database Reset Tool</h1>
            <p class="text-gray-600">Fitur tersembunyi untuk reset semua data testing</p>
        </div>
        
        <!-- Warning Box -->
        <div class="bg-red-100 border-l-4 border-red-500 p-4 mb-6">
            <div class="flex items-start">
                <div class="text-2xl mr-3">⚠️</div>
                <div>
                    <h3 class="text-lg font-bold text-red-800">PERINGATAN!</h3>
                    <ul class="text-red-700 mt-2 space-y-1 text-sm">
                        <li>• Ini akan menghapus SEMUA data transaksi!</li>
                        <li>• Piutang, Hutang, Cashflow, Assets, Jurnal → HILANG!</li>
                        <li>• Hanya untuk TESTING/DEVELOPMENT!</li>
                        <li>• JANGAN gunakan di production!</li>
                    </ul>
                </div>
            </div>
        </div>
        
        <?php if ($message): ?>
            <?php echo $message; ?>
            <div class="mt-6 text-center">
                <a href="index.php" class="inline-block bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 font-medium">
                    🏠 Kembali ke Dashboard
                </a>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="bg-red-100 border-l-4 border-red-500 p-4 mb-4">
                <p class="text-red-700"><?php echo $error; ?></p>
            </div>
        <?php endif; ?>
        
        <?php if (!$reset_confirmed): ?>
        <!-- Reset Form -->
        <form method="POST" class="space-y-6" onsubmit="return confirmReset()">
            <!-- Password Input -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    🔑 Password Reset <span class="text-red-500">*</span>
                </label>
                <input type="password" name="password" required
                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                       placeholder="Masukkan password reset">
                <p class="text-xs text-gray-500 mt-1">Default: RESET2025 (ganti di config!)</p>
            </div>
            
            <!-- Confirmation Text -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    ✍️ Konfirmasi <span class="text-red-500">*</span>
                </label>
                <input type="text" name="confirm_text" required
                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                       placeholder="Ketik: RESET SEMUA DATA">
                <p class="text-xs text-gray-500 mt-1">Ketik persis: <strong>RESET SEMUA DATA</strong></p>
            </div>
            
            <!-- Info Box -->
            <div class="bg-blue-50 border-l-4 border-blue-500 p-4">
                <h4 class="font-bold text-blue-800 mb-2">📋 Yang Akan Dihapus:</h4>
                <ul class="text-blue-700 text-sm space-y-1">
                    <li>✓ Receivables (Piutang) & Payments</li>
                    <li>✓ Payables (Hutang) & Payments</li>
                    <li>✓ Transactions (Cashflow)</li>
                    <li>✓ Assets (Aset)</li>
                    <li>✓ General Journal & Journal Entries</li>
                    <li>✓ Approval History</li>
                    <li>✓ Customers & Suppliers</li>
                </ul>
                
                <h4 class="font-bold text-green-800 mt-4 mb-2">✅ Yang TIDAK Dihapus:</h4>
                <ul class="text-green-700 text-sm space-y-1">
                    <li>✓ Users (Akun login)</li>
                    <li>✓ Permissions (Hak akses)</li>
                    <li>✓ Chart of Accounts (Akun perkiraan)</li>
                </ul>
            </div>
            
            <!-- Submit Button -->
            <div class="flex gap-3">
                <button type="submit" 
                        class="flex-1 bg-red-600 text-white py-3 px-6 rounded-lg hover:bg-red-700 font-bold text-lg">
                    🗑️ RESET DATABASE
                </button>
                <a href="index.php" 
                   class="flex-1 text-center bg-gray-200 text-gray-800 py-3 px-6 rounded-lg hover:bg-gray-300 font-bold text-lg">
                    ❌ Batal
                </a>
            </div>
        </form>
        <?php endif; ?>
        
        <!-- Footer -->
        <div class="mt-8 pt-6 border-t border-gray-200 text-center">
            <p class="text-sm text-gray-500">
                💡 <strong>Tips:</strong> Backup database sebelum reset!
            </p>
            <p class="text-xs text-gray-400 mt-2">
                File: secret_reset_database.php
            </p>
        </div>
    </div>
    
    <script>
        function confirmReset() {
            return confirm('⚠️ TERAKHIR KALI KONFIRMASI!\n\nAnda yakin ingin menghapus SEMUA data?\n\nKlik OK untuk melanjutkan, Cancel untuk batal.');
        }
    </script>
</body>
</html>
