<?php
require_once __DIR__ . '/includes/config.php';
checkLogin();

if (!isSupervisor()) {
    $_SESSION['error'] = 'Akses ditolak. Hanya Supervisor yang dapat mengelola Master Akun.';
    header('Location: index.php');
    exit();
}

$conn = getDBConnection();
$success = $_SESSION['success'] ?? '';
$error = $_SESSION['error'] ?? '';
unset($_SESSION['success'], $_SESSION['error']);

// Handle POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        $account_code = trim($_POST['account_code'] ?? '');
        $account_name = trim($_POST['account_name'] ?? '');
        $account_type = $_POST['account_type'] ?? '';

        if ($account_code === '' || $account_name === '' || $account_type === '') {
            $_SESSION['error'] = 'Semua field wajib diisi.';
            header('Location: accounts.php');
            exit();
        }

        // Unique code
        $stmt = $conn->prepare("SELECT 1 FROM chart_of_accounts WHERE account_code = ? LIMIT 1");
        $stmt->bind_param("s", $account_code);
        $stmt->execute();
        $exists = $stmt->get_result()->num_rows > 0;
        $stmt->close();

        if ($exists) {
            $_SESSION['error'] = 'Kode akun sudah ada.';
        } else {
            $stmt = $conn->prepare("INSERT INTO chart_of_accounts (account_code, account_name, account_type) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $account_code, $account_name, $account_type);
            if ($stmt->execute()) {
                $_SESSION['success'] = 'Akun berhasil ditambahkan.';
            } else {
                $_SESSION['error'] = 'Gagal menambahkan akun.';
            }
            $stmt->close();
        }
        header('Location: accounts.php');
        exit();
    }

    if ($action === 'update') {
        $id = (int)($_POST['id'] ?? 0);
        $account_code = trim($_POST['account_code'] ?? '');
        $account_name = trim($_POST['account_name'] ?? '');
        $account_type = $_POST['account_type'] ?? '';

        if ($id <= 0 || $account_name === '' || $account_type === '') {
            $_SESSION['error'] = 'Data tidak valid.';
            header('Location: accounts.php');
            exit();
        }

        // Cek apakah akun sudah digunakan di jurnal
        $stmt = $conn->prepare("SELECT account_code FROM chart_of_accounts WHERE id = ? LIMIT 1");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $coa = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$coa) {
            $_SESSION['error'] = 'Akun tidak ditemukan.';
            header('Location: accounts.php');
            exit();
        }

        $existing_code = $coa['account_code'];
        $used = false;
        $stmt = $conn->prepare("SELECT 1 FROM journal_entries WHERE account_code = ? LIMIT 1");
        $stmt->bind_param("s", $existing_code);
        $stmt->execute();
        $used = $stmt->get_result()->num_rows > 0;
        $stmt->close();

        if ($used && $account_code !== $existing_code) {
            $_SESSION['error'] = 'Kode akun sudah dipakai di jurnal dan tidak boleh diubah.';
            header('Location: accounts.php');
            exit();
        }

        // Jika user mencoba ubah kode ke milik akun lain
        if ($account_code !== $existing_code) {
            $stmt = $conn->prepare("SELECT 1 FROM chart_of_accounts WHERE account_code = ? AND id <> ? LIMIT 1");
            $stmt->bind_param("si", $account_code, $id);
            $stmt->execute();
            $exists = $stmt->get_result()->num_rows > 0;
            $stmt->close();
            if ($exists) {
                $_SESSION['error'] = 'Kode akun sudah digunakan oleh akun lain.';
                header('Location: accounts.php');
                exit();
            }
        }

        $stmt = $conn->prepare("UPDATE chart_of_accounts SET account_code = ?, account_name = ?, account_type = ? WHERE id = ?");
        $stmt->bind_param("sssi", $account_code, $account_name, $account_type, $id);
        if ($stmt->execute()) {
            $_SESSION['success'] = 'Akun berhasil diperbarui.';
        } else {
            $_SESSION['error'] = 'Gagal memperbarui akun.';
        }
        $stmt->close();
        header('Location: accounts.php');
        exit();
    }

    if ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) {
            $_SESSION['error'] = 'Data tidak valid.';
            header('Location: accounts.php');
            exit();
        }

        // Ambil code
        $stmt = $conn->prepare("SELECT account_code FROM chart_of_accounts WHERE id = ? LIMIT 1");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $coa = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$coa) {
            $_SESSION['error'] = 'Akun tidak ditemukan.';
            header('Location: accounts.php');
            exit();
        }

        // Cek dipakai di jurnal?
        $stmt = $conn->prepare("SELECT 1 FROM journal_entries WHERE account_code = ? LIMIT 1");
        $stmt->bind_param("s", $coa['account_code']);
        $stmt->execute();
        $used = $stmt->get_result()->num_rows > 0;
        $stmt->close();

        if ($used) {
            $_SESSION['error'] = 'Akun sudah dipakai di jurnal dan tidak bisa dihapus.';
        } else {
            $stmt = $conn->prepare("DELETE FROM chart_of_accounts WHERE id = ?");
            $stmt->bind_param("i", $id);
            if ($stmt->execute()) {
                $_SESSION['success'] = 'Akun berhasil dihapus.';
            } else {
                $_SESSION['error'] = 'Gagal menghapus akun.';
            }
            $stmt->close();
        }
        header('Location: accounts.php');
        exit();
    }
}

// Data untuk tampilan
$accounts = $conn->query("SELECT * FROM chart_of_accounts ORDER BY account_type, account_code ASC");

$current_page = 'accounts.php';
include __DIR__ . '/includes/header.php';
?>
<script src="https://cdn.tailwindcss.com"></script>
<div class="max-w-6xl mx-auto px-4 py-6">
    <h1 class="text-2xl font-bold text-gray-900 mb-4">Master Akun (Chart of Accounts)</h1>

    <?php if (!empty($success)): ?>
        <div class="mb-4 p-3 bg-green-50 text-green-800 border border-green-200 rounded"><?php echo htmlspecialchars($success); ?></div>
    <?php endif; ?>
    <?php if (!empty($error)): ?>
        <div class="mb-4 p-3 bg-red-50 text-red-800 border border-red-200 rounded"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <div class="bg-white rounded-lg shadow p-4 mb-6">
        <h2 class="text-lg font-semibold mb-3">Tambah Akun Baru</h2>
        <form method="POST">
            <input type="hidden" name="action" value="create">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Kode Akun</label>
                    <input type="text" name="account_code" class="w-full px-3 py-2 border border-gray-300 rounded" placeholder="mis. 5-5400" required>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Nama Akun</label>
                    <input type="text" name="account_name" class="w-full px-3 py-2 border border-gray-300 rounded" placeholder="mis. Beban Lain-lain" required>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Tipe</label>
                    <select name="account_type" class="w-full px-3 py-2 border border-gray-300 rounded" required>
                        <option value="aset">Aset</option>
                        <option value="liabilitas">Liabilitas</option>
                        <option value="modal">Modal</option>
                        <option value="pendapatan">Pendapatan</option>
                        <option value="beban">Beban</option>
                    </select>
                </div>
            </div>
            <div class="mt-4">
                <button class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Simpan</button>
            </div>
        </form>
    </div>

    <div class="bg-white rounded-lg shadow overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Kode</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nama Akun</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tipe</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Aksi</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php while ($row = $accounts->fetch_assoc()): ?>
                <tr class="hover:bg-gray-50">
                    <form method="POST">
                        <input type="hidden" name="action" value="update">
                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            <input type="text" name="account_code" value="<?php echo htmlspecialchars($row['account_code']); ?>" class="px-2 py-1 border rounded w-40">
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            <input type="text" name="account_name" value="<?php echo htmlspecialchars($row['account_name']); ?>" class="px-2 py-1 border rounded w-64">
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            <select name="account_type" class="px-2 py-1 border rounded w-40">
                                <?php
                                $types = ['aset','liabilitas','modal','pendapatan','beban'];
                                foreach ($types as $t) {
                                    $sel = $t === $row['account_type'] ? 'selected' : '';
                                    echo "<option value=\"$t\" $sel>" . ucfirst($t) . "</option>";
                                }
                                ?>
                            </select>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm">
                            <button class="px-3 py-1 bg-blue-600 text-white rounded hover:bg-blue-700">Update</button>
                        </td>
                    </form>
                    <td class="px-6 py-4 whitespace-nowrap text-sm">
                        <form method="POST" onsubmit="return confirm('Hapus akun ini?')">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                            <button class="px-3 py-1 bg-red-600 text-white rounded hover:bg-red-700">Hapus</button>
                        </form>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<?php $conn->close(); ?>