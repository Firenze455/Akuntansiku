<?php
require_once __DIR__ . '/includes/config.php';
checkLogin();

$conn = getDBConnection();
$success = isset($_SESSION['success']) ? $_SESSION['success'] : '';
$error = isset($_SESSION['error']) ? $_SESSION['error'] : '';
unset($_SESSION['success'], $_SESSION['error']);

// Load Chart of Accounts helpers and preload common account lists
function fetchAccountsByType($conn, $type) {
    $accs = [];
    $stmt = $conn->prepare("SELECT account_code, account_name FROM chart_of_accounts WHERE account_type = ? ORDER BY account_code ASC");
    if ($stmt) {
        $stmt->bind_param("s", $type);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($res) {
            while ($r = $res->fetch_assoc()) {
                $accs[] = ['account_code' => $r['account_code'], 'account_name' => $r['account_name']];
            }
        }
        $stmt->close();
    }
    return $accs;
}

// Quick map for display (code -> name)
$coa_map = [];
$all = $conn->query("SELECT account_code, account_name FROM chart_of_accounts");
if ($all && $all->num_rows > 0) {
    while ($r = $all->fetch_assoc()) {
        $coa_map[$r['account_code']] = $r['account_name'];
    }
}

// Preload account lists for forms
$income_accounts = fetchAccountsByType($conn, 'pendapatan');
$expense_accounts = fetchAccountsByType($conn, 'beban');

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_transaction'])) {
    $date = $_POST['transaction_date'];
    $type = $_POST['transaction_type'];
    $category = $_POST['category'];
    $description = $_POST['description'];
    $payment_method = $_POST['payment_method'] ?? 'tunai';
    $user_id = $_SESSION['user_id'];
    
    // Ambil data berdasarkan metode pembayaran
    if ($payment_method == 'piutang' || $payment_method == 'hutang') {
        $total_amount = floatval($_POST['total_amount']);
        $dp_amount = floatval($_POST['dp_amount']);
        $outstanding_amount = $total_amount - $dp_amount;
        $amount = $dp_amount;
    } else {
        $amount = floatval($_POST['amount']);
        $total_amount = $amount;
        $dp_amount = $amount;
        $outstanding_amount = 0;
    }
    
    $status = isSupervisor() ? 'approved' : 'pending';
    
    try {
        // Insert transaction
        $stmt = $conn->prepare("INSERT INTO transactions (transaction_date, transaction_type, category, description, amount, payment_method, status, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssdssi", $date, $type, $category, $description, $amount, $payment_method, $status, $user_id);
        
        if ($stmt->execute()) {
            $transaction_id = $stmt->insert_id;
            
            // Auto-generate Piutang atau Hutang
            if ($payment_method == 'piutang' && $type == 'masuk') {
                // Get/Create customer
                $customer_input = trim($_POST['customer_name']);
                $customer_address = trim($_POST['customer_address'] ?? '');
                
                // Check if customer exists
                $stmt_check = $conn->prepare("SELECT id, name FROM customers WHERE name = ? LIMIT 1");
                $stmt_check->bind_param("s", $customer_input);
                $stmt_check->execute();
                $result_check = $stmt_check->get_result();
                
                if ($result_check->num_rows > 0) {
                    // Customer exists
                    $cust_data = $result_check->fetch_assoc();
                    $customer_id = $cust_data['id'];
                    $customer_name = $cust_data['name'];
                    // Update address if provided
                    if (!empty($customer_address)) {
                        $stmt_update = $conn->prepare("UPDATE customers SET address = ? WHERE id = ?");
                        $stmt_update->bind_param("si", $customer_address, $customer_id);
                        $stmt_update->execute();
                        $stmt_update->close();
                    }
                } else {
                    // Create new customer with address
                    $stmt_create = $conn->prepare("INSERT INTO customers (name, address, created_by) VALUES (?, ?, ?)");
                    $stmt_create->bind_param("ssi", $customer_input, $customer_address, $user_id);
                    $stmt_create->execute();
                    $customer_id = $stmt_create->insert_id;
                    $customer_name = $customer_input;
                    $stmt_create->close();
                }
                $stmt_check->close();
                
                $rec_status = ($outstanding_amount <= 0) ? 'lunas' : ($dp_amount > 0 ? 'sebagian' : 'belum_lunas');
                
                // Generate ref_code
                $ref_prefix = 'RCV';
                $ref_date = date('Ymd');
                $stmt_check = $conn->prepare("SELECT ref_code FROM receivables WHERE ref_code LIKE ? ORDER BY ref_code DESC LIMIT 1");
                $pattern = $ref_prefix . $ref_date . '%';
                $stmt_check->bind_param("s", $pattern);
                $stmt_check->execute();
                $result_check = $stmt_check->get_result();
                
                if ($result_check->num_rows > 0) {
                    $last_code = $result_check->fetch_assoc()['ref_code'];
                    $last_num = intval(substr($last_code, -4));
                    $new_num = str_pad($last_num + 1, 4, '0', STR_PAD_LEFT);
                } else {
                    $new_num = '0001';
                }
                $ref_code = $ref_prefix . $ref_date . $new_num;
                $stmt_check->close();
                
                // Insert receivable
                $due_date = !empty($_POST['due_date']) ? $_POST['due_date'] : date('Y-m-d', strtotime($date . ' +30 days'));
                $stmt_receivable = $conn->prepare("INSERT INTO receivables (ref_code, customer_id, customer_name, description, total_amount, paid_amount, remaining_amount, due_date, status, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $paid_amount = $dp_amount; // DP that has been paid immediately
                $stmt_receivable->bind_param("sissdddssi", $ref_code, $customer_id, $customer_name, $description, $total_amount, $paid_amount, $outstanding_amount, $due_date, $rec_status, $user_id);
                $stmt_receivable->execute();
                $receivable_id = $stmt_receivable->insert_id;
                $stmt_receivable->close();

                // Simpan syarat (maksimal cicilan) ke notes
                $max_installments = intval($_POST['max_installments'] ?? 0);
                if ($max_installments > 0) {
                    $terms_text = 'Cicilan maksimal ' . $max_installments . ' kali';
                    $stmt_terms = $conn->prepare("UPDATE receivables SET notes = ? WHERE id = ?");
                    $stmt_terms->bind_param("si", $terms_text, $receivable_id);
                    $stmt_terms->execute();
                    $stmt_terms->close();
                }
                
                // Auto-approve if supervisor
                if (isSupervisor()) {
                    $stmt_approve = $conn->prepare("UPDATE receivables SET approved_by = ?, approved_at = NOW() WHERE id = ?");
                    $stmt_approve->bind_param("ii", $user_id, $receivable_id);
                    $stmt_approve->execute();
                    $stmt_approve->close();
                }

                // Catat DP sebagai pembayaran awal agar muncul di riwayat pembayaran
                if ($dp_amount > 0) {
                    $payment_date = $date;
                    $payment_method_for_dp = 'tunai';
                    $notes = 'DP pada pembuatan piutang dari transaksi ' . $transaction_id;
                    $stmt_pay = $conn->prepare("INSERT INTO receivable_payments (receivable_id, payment_date, amount, payment_method, notes, created_by) VALUES (?, ?, ?, ?, ?, ?)");
                    $stmt_pay->bind_param("isdssi", $receivable_id, $payment_date, $dp_amount, $payment_method_for_dp, $notes, $user_id);
                    $stmt_pay->execute();
                    $stmt_pay->close();
                }
                
            } elseif ($payment_method == 'hutang' && $type == 'keluar') {
                // Get/Create supplier
                $supplier_input = trim($_POST['supplier_name']);
                
                // Check if supplier exists
                $stmt_check = $conn->prepare("SELECT id, name FROM suppliers WHERE name = ? LIMIT 1");
                $stmt_check->bind_param("s", $supplier_input);
                $stmt_check->execute();
                $result_check = $stmt_check->get_result();
                
                if ($result_check->num_rows > 0) {
                    // Supplier exists
                    $supp_data = $result_check->fetch_assoc();
                    $supplier_id = $supp_data['id'];
                    $supplier_name = $supp_data['name'];
                } else {
                    // Create new supplier
                    $stmt_create = $conn->prepare("INSERT INTO suppliers (name, created_by) VALUES (?, ?)");
                    $stmt_create->bind_param("si", $supplier_input, $user_id);
                    $stmt_create->execute();
                    $supplier_id = $stmt_create->insert_id;
                    $supplier_name = $supplier_input;
                    $stmt_create->close();
                }
                $stmt_check->close();
                
                $pay_status = ($outstanding_amount <= 0) ? 'lunas' : ($dp_amount > 0 ? 'sebagian' : 'belum_lunas');
                
                // Generate ref_code
                $ref_prefix = 'PAY';
                $ref_date = date('Ymd');
                $stmt_check = $conn->prepare("SELECT ref_code FROM payables WHERE ref_code LIKE ? ORDER BY ref_code DESC LIMIT 1");
                $pattern = $ref_prefix . $ref_date . '%';
                $stmt_check->bind_param("s", $pattern);
                $stmt_check->execute();
                $result_check = $stmt_check->get_result();
                
                if ($result_check->num_rows > 0) {
                    $last_code = $result_check->fetch_assoc()['ref_code'];
                    $last_num = intval(substr($last_code, -4));
                    $new_num = str_pad($last_num + 1, 4, '0', STR_PAD_LEFT);
                } else {
                    $new_num = '0001';
                }
                $ref_code = $ref_prefix . $ref_date . $new_num;
                $stmt_check->close();
                
                // Insert payable (store full amounts; payments handled as separate payment records)
                $due_date = !empty($_POST['due_date']) ? $_POST['due_date'] : date('Y-m-d', strtotime($date . ' +30 days'));
                $stmt_payable = $conn->prepare("INSERT INTO payables (ref_code, supplier_id, supplier_name, description, total_amount, paid_amount, remaining_amount, due_date, status, created_by, category) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $initial_paid = 0.0; // we'll record DP as a payment record below so paid_amount starts at 0
                $initial_remaining = $total_amount;
                $initial_status = ($total_amount <= 0) ? 'lunas' : 'belum_lunas';
                $stmt_payable->bind_param("sissdddssis", $ref_code, $supplier_id, $supplier_name, $description, $total_amount, $initial_paid, $initial_remaining, $due_date, $initial_status, $user_id, $category);
                $stmt_payable->execute();
                $payable_id = $stmt_payable->insert_id;
                $stmt_payable->close();

                // Auto-approve if supervisor
                if (isSupervisor()) {
                    $stmt_approve = $conn->prepare("UPDATE payables SET approved_by = ?, approved_at = NOW() WHERE id = ?");
                    $stmt_approve->bind_param("ii", $user_id, $payable_id);
                    $stmt_approve->execute();
                    $stmt_approve->close();
                }

                // If a DP was provided, create a payment record and its journal now so DP is recorded
                if ($dp_amount > 0) {
                    // Start a local transaction to create the payment and update payable
                    $conn->begin_transaction();
                    try {
                        // Insert payment
                        $payment_date = $date;
                        $payment_method_for_dp = 'tunai';
                        $notes = 'DP pada pembuatan hutang dari transaksi ' . $transaction_id;
                        $stmt_pay = $conn->prepare("INSERT INTO payable_payments (payable_id, payment_date, amount, payment_method, notes, created_by) VALUES (?, ?, ?, ?, ?, ?)");
                        $stmt_pay->bind_param("isdssi", $payable_id, $payment_date, $dp_amount, $payment_method_for_dp, $notes, $user_id);
                        $stmt_pay->execute();
                        $payment_id = $conn->insert_id;

                        // Update payable paid/remaining/status
                        $new_paid = ($initial_paid) + $dp_amount;
                        $new_remaining = $initial_remaining - $dp_amount;
                        if ($new_remaining < 0) $new_remaining = 0;
                        $new_status = $new_remaining <= 0 ? 'lunas' : ($new_paid > 0 ? 'sebagian' : 'belum_lunas');

                        $stmt_upd = $conn->prepare("UPDATE payables SET paid_amount = ?, remaining_amount = ?, status = ? WHERE id = ?");
                        $stmt_upd->bind_param("ddsi", $new_paid, $new_remaining, $new_status, $payable_id);
                        $stmt_upd->execute();

                        // Create payment journal
                        $description = "Pembayaran DP hutang ke " . $supplier_name . " - " . $ref_code;
                        $stmt = $conn->prepare("INSERT INTO general_journal (journal_date, description, reference_id, reference_type) VALUES (?, ?, ?, 'payable_payment')");
                        $stmt->bind_param("ssi", $payment_date, $description, $payable_id);
                        $stmt->execute();
                        $journal_id = $conn->insert_id;

                        // Update payment with journal_id
                        $stmt = $conn->prepare("UPDATE payable_payments SET journal_id = ? WHERE id = ?");
                        $stmt->bind_param("ii", $journal_id, $payment_id);
                        $stmt->execute();

                        // Debit: Hutang Usaha
                        $account_code = '2-2100';
                        $account_name = 'Hutang Usaha';
                        $stmt = $conn->prepare("INSERT INTO journal_entries (journal_id, account_code, account_name, debit, credit) VALUES (?, ?, ?, ?, 0)");
                        $stmt->bind_param("issd", $journal_id, $account_code, $account_name, $dp_amount);
                        $stmt->execute();

                        // Credit: Kas
                        $account_code = '1-1100';
                        $account_name = 'Kas';
                        $stmt = $conn->prepare("INSERT INTO journal_entries (journal_id, account_code, account_name, debit, credit) VALUES (?, ?, ?, 0, ?)");
                        $stmt->bind_param("issd", $journal_id, $account_code, $account_name, $dp_amount);
                        $stmt->execute();

                        $conn->commit();
                    } catch (Exception $e) {
                        $conn->rollback();
                        // Log error but continue — we already created the payable; notify user
                        $_SESSION['error'] = 'Gagal mencatat DP: ' . $e->getMessage();
                    }
                }
            }
            
            // Auto-generate journal if supervisor
            if (isSupervisor()) {
                $stmt_journal = $conn->prepare("INSERT INTO general_journal (journal_date, description, reference_id, reference_type) VALUES (?, ?, ?, 'transaction')");
                $stmt_journal->bind_param("ssi", $date, $description, $transaction_id);
                $stmt_journal->execute();
                $journal_id = $stmt_journal->insert_id;
                $stmt_journal->close();
                
                // Journal entries based on type
                if ($type == 'masuk') {
                    if ($payment_method == 'piutang') {
                        // Debit Kas (DP)
                        if ($dp_amount > 0) {
                            $stmt_je = $conn->prepare("INSERT INTO journal_entries (journal_id, account_code, account_name, debit, credit) VALUES (?, ?, ?, ?, 0)");
                            $acc_code = '1-1100';
                            $acc_name = 'Kas';
                            $stmt_je->bind_param("issd", $journal_id, $acc_code, $acc_name, $dp_amount);
                            $stmt_je->execute();
                        }
                        
                        // Debit Piutang (Sisa)
                        if ($outstanding_amount > 0) {
                            $stmt_je = $conn->prepare("INSERT INTO journal_entries (journal_id, account_code, account_name, debit, credit) VALUES (?, ?, ?, ?, 0)");
                            $acc_code = '1-1200';
                            $acc_name = 'Piutang Usaha';
                            $stmt_je->bind_param("issd", $journal_id, $acc_code, $acc_name, $outstanding_amount);
                            $stmt_je->execute();
                        }
                    } else {
                        // Tunai - Debit Kas
                        $stmt_je = $conn->prepare("INSERT INTO journal_entries (journal_id, account_code, account_name, debit, credit) VALUES (?, ?, ?, ?, 0)");
                        $acc_code = '1-1100';
                        $acc_name = 'Kas';
                        $stmt_je->bind_param("issd", $journal_id, $acc_code, $acc_name, $amount);
                        $stmt_je->execute();
                    }
                    
                    // Credit Pendapatan berdasarkan COA (category adalah account_code)
                    $credit_amount = ($payment_method == 'piutang') ? $total_amount : $amount;
                    $rev_code = $category;
                    $rev_name = $coa_map[$rev_code] ?? null;
                    if ($rev_name === null) {
                        // default pendapatan dari COA
                        $stmt_def = $conn->prepare("SELECT account_code, account_name FROM chart_of_accounts WHERE account_type = 'pendapatan' ORDER BY account_code ASC LIMIT 1");
                        if ($stmt_def) {
                            $stmt_def->execute();
                            $res_def = $stmt_def->get_result();
                            $def = $res_def ? $res_def->fetch_assoc() : null;
                            $stmt_def->close();
                            $rev_code = $def['account_code'] ?? '4101';
                            $rev_name = $def['account_name'] ?? 'Pendapatan';
                        } else {
                            $rev_code = '4101';
                            $rev_name = 'Pendapatan';
                        }
                    }
                    $stmt_je = $conn->prepare("INSERT INTO journal_entries (journal_id, account_code, account_name, debit, credit) VALUES (?, ?, ?, 0, ?)");
                    $stmt_je->bind_param("issd", $journal_id, $rev_code, $rev_name, $credit_amount);
                    $stmt_je->execute();
                    
                } else {
                    // Pengeluaran
                        // Asset categories (debit to asset accounts)
                        $asset_map = [
                            'peralatan' => ['1-1400', 'Peralatan'],
                            'perlengkapan' => ['1-1300', 'Perlengkapan']
                        ];

                        // When purchase is on credit, the journal should reflect the TOTAL payable
                        $journal_amount = ($payment_method === 'hutang') ? $total_amount : $amount;

                        if (isset($asset_map[$category])) {
                            // Debit Asset
                            $acc_code = $asset_map[$category][0];
                            $acc_name = $asset_map[$category][1];
                            $stmt_je = $conn->prepare("INSERT INTO journal_entries (journal_id, account_code, account_name, debit, credit) VALUES (?, ?, ?, ?, 0)");
                            $stmt_je->bind_param("issd", $journal_id, $acc_code, $acc_name, $journal_amount);
                            $stmt_je->execute();
                        } else {
                            // Debit Beban dari COA (category adalah account_code)
                            $exp_code = $category;
                            $exp_name = $coa_map[$exp_code] ?? null;
                            if ($exp_name === null) {
                                // default beban dari COA
                                $stmt_def = $conn->prepare("SELECT account_code, account_name FROM chart_of_accounts WHERE account_type = 'beban' ORDER BY account_code ASC LIMIT 1");
                                if ($stmt_def) {
                                    $stmt_def->execute();
                                    $res_def = $stmt_def->get_result();
                                    $def = $res_def ? $res_def->fetch_assoc() : null;
                                    $stmt_def->close();
                                    $exp_code = $def['account_code'] ?? '5-5400';
                                    $exp_name = $def['account_name'] ?? 'Beban Lain-lain';
                                } else {
                                    $exp_code = '5-5400';
                                    $exp_name = 'Beban Lain-lain';
                                }
                            }
                            $stmt_je = $conn->prepare("INSERT INTO journal_entries (journal_id, account_code, account_name, debit, credit) VALUES (?, ?, ?, ?, 0)");
                            $stmt_je->bind_param("issd", $journal_id, $exp_code, $exp_name, $journal_amount);
                            $stmt_je->execute();
                        }

                        // Determine credit account: Hutang if purchase on credit, otherwise Kas
                        if ($payment_method === 'hutang') {
                            $credit_code = '2-2100';
                            $credit_name = 'Hutang Usaha';
                        } else {
                            $credit_code = '1-1100';
                            $credit_name = 'Kas';
                        }

                        $stmt_je = $conn->prepare("INSERT INTO journal_entries (journal_id, account_code, account_name, debit, credit) VALUES (?, ?, ?, 0, ?)");
                        $stmt_je->bind_param("issd", $journal_id, $credit_code, $credit_name, $journal_amount);
                        $stmt_je->execute();
                }
            }
            
            $_SESSION['success'] = 'Transaksi berhasil ditambahkan!';
        }
    } catch (Exception $e) {
        $_SESSION['error'] = 'Gagal menambahkan transaksi: ' . $e->getMessage();
    }
    
    header('Location: cashflow.php');
    exit();
}

// Get transactions
$query = "SELECT t.*, u.full_name as creator_name, 
          (SELECT full_name FROM users WHERE id = t.approved_by) as approver_name
          FROM transactions t
          LEFT JOIN users u ON t.created_by = u.id
          ORDER BY t.transaction_date DESC, t.created_at DESC";
$transactions = $conn->query($query);

// Get customers for autocomplete
$customers_list = @$conn->query("SELECT DISTINCT name FROM customers ORDER BY name ASC");
$customers = [];
if ($customers_list && $customers_list->num_rows > 0) {
    while ($row = $customers_list->fetch_assoc()) {
        $customers[] = $row['name'];
    }
}

// Get suppliers for autocomplete
$suppliers_list = @$conn->query("SELECT DISTINCT name FROM suppliers ORDER BY name ASC");
$suppliers = [];
if ($suppliers_list && $suppliers_list->num_rows > 0) {
    while ($row = $suppliers_list->fetch_assoc()) {
        $suppliers[] = $row['name'];
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Cashflow - Sistem Informasi Akuntansi</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 pt-6">
    <?php include __DIR__ . '/includes/header.php'; ?>
    
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-2 pb-6">
        <div class="mb-6 flex items-center justify-between">
            <h2 class="text-2xl font-bold text-gray-800">Manajemen Cashflow</h2>
            <button onclick="toggleInputForm()" 
                    class="bg-blue-600 text-white px-6 py-2.5 rounded-lg hover:bg-blue-700 font-medium transition-colors">
                Tambah Transaksi Baru
            </button>
        </div>
        
        <!-- Success/Error Messages -->
        <?php if ($success): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                <?php echo htmlspecialchars($success); ?>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>
        
        <!-- Input Form (Hidden by default) -->
        <div id="inputForm" class="hidden mb-6">
            <div class="max-w-2xl mx-auto bg-white rounded-lg shadow-md p-6">
                <h3 class="text-xl font-semibold text-gray-800 mb-6">Form Input Transaksi</h3>
                <form method="POST" class="space-y-4">
                    <!-- Row 1: Tanggal & Tipe -->
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Tanggal</label>
                            <input type="date" name="transaction_date" required 
                                   value="<?php echo date('Y-m-d'); ?>"
                                   class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Tipe</label>
                            <select name="transaction_type" id="trans-type" required onchange="updateCategories()"
                                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                                <option value="masuk">Pemasukan</option>
                                <option value="keluar">Pengeluaran</option>
                            </select>
                        </div>
                    </div>
                    
                    <!-- Row 2: Kategori & Metode -->
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Kategori</label>
                            <!-- Form Input Transaksi (bagian Kategori) -->
                            <select name="category" id="category" required
                                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                                <option value="pendapatan">Pendapatan</option>
                            </select>
                        </div>
                        <div id="payment-method-field">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Metode</label>
                            <select name="payment_method" id="payment-method" required onchange="togglePaymentFields()"
                                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                                <option value="tunai">Tunai</option>
                                <option value="piutang">Piutang</option>
                            </select>
                        </div>
                    </div>
                    
                    <!-- Row 2.5: Customer/Supplier Input (Autocomplete) -->
                    <div id="customer-field" class="hidden">
                        <label class="block text-sm font-medium text-gray-700 mb-2">Customer</label>
                        <input type="text" name="customer_name" id="customer-input" list="customer-list"
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                               placeholder="Ketik nama customer (akan dibuat otomatis jika belum ada)">
                        <datalist id="customer-list">
                            <?php foreach ($customers as $cust): ?>
                                <option value="<?php echo htmlspecialchars($cust); ?>">
                            <?php endforeach; ?>
                        </datalist>
                        <p class="text-xs text-gray-500 mt-1">Ketik untuk mencari atau buat customer baru</p>
                    </div>
                    <div id="customer-address-field" class="hidden">
                        <label class="block text-sm font-medium text-gray-700 mb-2">Alamat Customer</label>
                        <input type="text" name="customer_address" id="customer-address-input"
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                               placeholder="Alamat lengkap customer">
                        <p class="text-xs text-gray-500 mt-1">Alamat akan disimpan ke data customer</p>
                    </div>

                    <!-- Baru: Maksimal cicilan (tampil jika metode=piutang) -->
                    <div id="installment-field" class="hidden">
                        <label class="block text-sm font-medium text-gray-700 mb-2">Maksimal Cicilan</label>
                        <select name="max_installments" id="max-installments"
                                class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                            <?php for ($i=1; $i<=24; $i++): ?>
                                <option value="<?php echo $i; ?>"><?php echo $i; ?> kali</option>
                            <?php endfor; ?>
                        </select>
                        <p class="text-xs text-gray-500 mt-1">Jumlah maksimal angsuran untuk piutang ini</p>
                    </div>
                    <div id="supplier-field" class="hidden">
                        <label class="block text-sm font-medium text-gray-700 mb-2">Supplier</label>
                        <input type="text" name="supplier_name" id="supplier-input" list="supplier-list"
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                               placeholder="Ketik nama supplier (akan dibuat otomatis jika belum ada)">
                        <datalist id="supplier-list">
                            <?php foreach ($suppliers as $supp): ?>
                                <option value="<?php echo htmlspecialchars($supp); ?>">
                            <?php endforeach; ?>
                        </datalist>
                        <p class="text-xs text-gray-500 mt-1">Ketik untuk mencari atau buat supplier baru</p>
                    </div>

                    <!-- Baru: Tanggal Jatuh Tempo (dipindah ke atas Deskripsi) -->
                    <div id="due-date-field" class="hidden">
                        <label class="block text-sm font-medium text-gray-700 mb-2">Tanggal Jatuh Tempo</label>
                        <input type="date" name="due_date" id="due-date"
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                        <p class="text-xs text-gray-500 mt-1">Wajib diisi untuk piutang/hutang</p>
                    </div>
                    
                    <!-- Row 3: Deskripsi -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Deskripsi</label>
                        <textarea name="description" required rows="2"
                                  class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                  placeholder="Detail transaksi..."></textarea>
                    </div>
                    
                    <!-- Row 4: Nominal Tunai (Default) -->
                    <div id="tunai-field">
                        <label class="block text-sm font-medium text-gray-700 mb-2">Nominal</label>
                        <input type="number" name="amount" id="amount-tunai" step="0.01" min="0"
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                               placeholder="0">
                    </div>
                    
                    <!-- Row 5-7: Field Piutang/Hutang (Hidden) -->
                    <div id="credit-fields" class="hidden space-y-4">
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    <span id="label-total">Total</span>
                                </label>
                                <input type="number" name="total_amount" id="total-amount" step="0.01" min="0"
                                       oninput="calculateOutstanding()"
                                       class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                       placeholder="Total">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    <span id="label-dp">DP/Dibayar</span>
                                </label>
                                <input type="number" name="dp_amount" id="dp-amount" step="0.01" min="0"
                                       oninput="calculateOutstanding()"
                                       class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                       placeholder="DP">
                            </div>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">
                                <span id="label-outstanding">Sisa Belum Terbayar</span>
                            </label>
                            <input type="number" id="outstanding-amount" readonly
                                   class="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-100"
                                   placeholder="0">
                            <p class="text-xs text-gray-500 mt-1">Otomatis: Total - DP</p>
                        </div>

                        <!-- Hapus: due-date-field dari sini (sudah dipindah ke atas Deskripsi) -->
                    </div>
                    
                    <!-- Submit Buttons -->
                    <div class="flex gap-3 pt-2">
                        <button type="submit" name="add_transaction"
                                class="flex-1 bg-blue-600 text-white py-2.5 rounded-lg hover:bg-blue-700 font-medium">
                            Simpan
                        </button>
                        <button type="button" onclick="toggleInputForm()"
                                class="px-6 bg-gray-200 text-gray-700 py-2.5 rounded-lg hover:bg-gray-300 font-medium">
                            Batal
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Transaction List -->
        <div class="bg-white rounded-lg shadowmd overflow-hidden">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tanggal</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tipe</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Kategori</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Deskripsi</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nominal</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Metode</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Dibuat Oleh</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Action</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php if ($transactions->num_rows > 0): ?>
                            <?php while ($row = $transactions->fetch_assoc()): ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                                        <?php echo formatTanggal($row['transaction_date']); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm">
                                        <span class="px-2 py-1 text-xs font-medium rounded-full <?php echo $row['transaction_type'] == 'masuk' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>">
                                            <?php echo ucfirst($row['transaction_type']); ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                                        <?php
                                        $cat = $row['category'];
                                        if (isset($coa_map[$cat])) {
                                            echo htmlspecialchars($cat . ' - ' . $coa_map[$cat]);
                                        } else {
                                            echo ucfirst(str_replace('_', ' ', $cat));
                                        }
                                        ?>
                                    </td>
                                    <td class="px-6 py-4 text-sm text-gray-800">
                                        <?php echo htmlspecialchars($row['description']); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                        <?php echo formatRupiah($row['amount']); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                                        <?php echo ucfirst($row['payment_method']); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm">
                                        <?php
                                        $status_badges = [
                                            'pending' => '<span class="px-2 py-1 text-xs font-medium rounded-full bg-yellow-100 text-yellow-800">Pending</span>',
                                            'approved' => '<span class="px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800">Approved</span>',
                                            'rejected' => '<span class="px-2 py-1 text-xs font-medium rounded-full bg-red-100 text-red-800">Rejected</span>',
                                            'returned' => '<span class="px-2 py-1 text-xs font-medium rounded-full bg-orange-100 text-orange-800">Returned</span>'
                                        ];
                                        echo $status_badges[$row['status']] ?? $row['status'];
                                        ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                                        <?php echo htmlspecialchars($row['creator_name']); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm">
                                        <?php if (isSupervisor() && $row['status'] == 'pending'): ?>
                                            <div class="flex gap-1">
                                                <!-- Approve Button -->
            <form method="POST" action="handlers/approve_handler.php" class="inline">
                                                    <input type="hidden" name="action" value="approve">
                                                    <input type="hidden" name="type" value="transaction">
                                                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                                    <input type="hidden" name="redirect" value="cashflow.php">
                                                    <button type="submit" onclick="return confirm('Approve transaksi ini?')"
                                                            class="px-2 py-1 text-xs bg-green-600 text-white rounded hover:bg-green-700"
                                                            title="Approve">
                                                        âœ“
                                                    </button>
                                                </form>
                                                
                                                <!-- Return Button -->
                                                <button onclick="showReturnModalCashflow(<?php echo $row['id']; ?>)"
                                                        class="px-2 py-1 text-xs bg-yellow-600 text-white rounded hover:bg-yellow-700"
                                                        title="Return untuk Revisi">
                                                    ðŸ”„
                                                </button>
                                                
                                                <!-- Reject Button -->
                                                <button onclick="showRejectModalCashflow(<?php echo $row['id']; ?>)"
                                                        class="px-2 py-1 text-xs bg-red-600 text-white rounded hover:bg-red-700"
                                                        title="Reject">
                                                    âœ•
                                                </button>
                                            </div>
                                        <?php elseif ($row['status'] == 'approved'): ?>
                                            <span class="text-xs text-gray-500">Approved</span>
                                        <?php elseif ($row['status'] == 'rejected'): ?>
                                            <span class="text-xs text-gray-500">Rejected</span>
                                        <?php elseif ($row['status'] == 'returned'): ?>
                                            <div class="flex items-center gap-2">
                                                <span class="text-xs text-yellow-600">Returned</span>
                                                <?php if ($row['created_by'] == $_SESSION['user_id']): ?>
                                                    <button onclick="showEditModalCashflow(<?php echo htmlspecialchars(json_encode($row)); ?>)"
                                                            class="px-2 py-1 text-xs bg-orange-600 text-white rounded hover:bg-orange-700"
                                                            title="Edit & Resubmit">
                                                        âœï¸
                                                    </button>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="8" class="px-6 py-8 text-center text-gray-500">
                                    Belum ada transaksi
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <script>
        const incomeAccountsData = <?php echo json_encode($income_accounts); ?>;
        const expenseAccountsData = <?php echo json_encode($expense_accounts); ?>;
        function toggleInputForm() {
            const formWrap = document.getElementById('inputForm');
            formWrap.classList.toggle('hidden');
            // Inisialisasi saat form dibuka pertama kali
            if (!formWrap.classList.contains('hidden')) {
                updateCategories();
                togglePaymentFields();
                const categorySelect = document.getElementById('category');
                if (categorySelect && categorySelect.options.length > 0) {
                    categorySelect.selectedIndex = 0;
                }
                formWrap.scrollIntoView({ behavior: 'smooth', block: 'start' });
            } else {
                resetTransactionForm();
            }
        }

        function updateCategories() {
            const type = document.getElementById('trans-type').value;
            const categorySelect = document.getElementById('category');
            const paymentMethodSelect = document.getElementById('payment-method');

            // Reset categories
            categorySelect.innerHTML = '';

            if (type === 'masuk') {
                // Populate income accounts from COA
                incomeAccountsData.forEach(acc => {
                    const opt = document.createElement('option');
                    opt.value = acc.account_code;
                    opt.textContent = `${acc.account_code} - ${acc.account_name}`;
                    categorySelect.appendChild(opt);
                });
                paymentMethodSelect.innerHTML = `
                    <option value="tunai">Tunai</option>
                    <option value="piutang">Piutang</option>
                `;
            } else {
                // Populate expense accounts from COA
                expenseAccountsData.forEach(acc => {
                    const opt = document.createElement('option');
                    opt.value = acc.account_code;
                    opt.textContent = `${acc.account_code} - ${acc.account_name}`;
                    categorySelect.appendChild(opt);
                });
                // Asset options remain available
                const assetOptions = [
                    { value: 'perlengkapan', text: 'Perlengkapan (Aset)' },
                    { value: 'peralatan', text: 'Peralatan (Aset)' }
                ];
                assetOptions.forEach(a => {
                    const opt = document.createElement('option');
                    opt.value = a.value;
                    opt.textContent = a.text;
                    categorySelect.appendChild(opt);
                });
                paymentMethodSelect.innerHTML = `
                    <option value="tunai">Tunai</option>
                    <option value="hutang">Hutang</option>
                `;
            }
            // ensure payment-specific fields update
            togglePaymentFields();
        }

        function togglePaymentFields() {
            const paymentMethod = document.getElementById('payment-method').value;
            const tunaiField = document.getElementById('tunai-field');
            const creditFields = document.getElementById('credit-fields');
            const customerField = document.getElementById('customer-field');
            const supplierField = document.getElementById('supplier-field');
            const amountTunai = document.getElementById('amount-tunai');
            const totalAmount = document.getElementById('total-amount');
            const dpAmount = document.getElementById('dp-amount');
            const customerInput = document.getElementById('customer-input');
            const supplierInput = document.getElementById('supplier-input');
            const installmentField = document.getElementById('installment-field');
            const maxInstallments = document.getElementById('max-installments');
            // Baru: referensi jatuh tempo yang dipindah
            const dueDateField = document.getElementById('due-date-field');
            const dueDateInput = document.getElementById('due-date');

            if (paymentMethod === 'piutang') {
                tunaiField.classList.add('hidden');
                creditFields.classList.remove('hidden');
                customerField.classList.remove('hidden');
                supplierField.classList.add('hidden');
                amountTunai.removeAttribute('required');
                totalAmount.setAttribute('required', 'required');
                dpAmount.setAttribute('required', 'required');
                customerInput.setAttribute('required', 'required');
                supplierInput.removeAttribute('required');
                document.getElementById('label-total').textContent = 'Total Piutang';
                document.getElementById('label-dp').textContent = 'DP/Dibayar';
                document.getElementById('label-outstanding').textContent = 'Sisa Belum Terbayar';
                installmentField.classList.remove('hidden');
                maxInstallments.setAttribute('required', 'required');
                // Tampilkan due date
                dueDateField.classList.remove('hidden');
                dueDateInput.setAttribute('required', 'required');
            } else if (paymentMethod === 'hutang') {
                tunaiField.classList.add('hidden');
                creditFields.classList.remove('hidden');
                customerField.classList.add('hidden');
                supplierField.classList.remove('hidden');
                amountTunai.removeAttribute('required');
                totalAmount.setAttribute('required', 'required');
                dpAmount.setAttribute('required', 'required');
                customerInput.removeAttribute('required');
                supplierInput.setAttribute('required', 'required');
                document.getElementById('label-total').textContent = 'Total Hutang';
                document.getElementById('label-dp').textContent = 'DP/Dibayar';
                document.getElementById('label-outstanding').textContent = 'Sisa Belum Terbayar';
                installmentField.classList.add('hidden');
                maxInstallments.removeAttribute('required');
                // Tampilkan due date
                dueDateField.classList.remove('hidden');
                dueDateInput.setAttribute('required', 'required');
            } else {
                tunaiField.classList.remove('hidden');
                creditFields.classList.add('hidden');
                customerField.classList.add('hidden');
                supplierField.classList.add('hidden');
                amountTunai.setAttribute('required', 'required');
                totalAmount.removeAttribute('required');
                dpAmount.removeAttribute('required');
                customerInput.removeAttribute('required');
                supplierInput.removeAttribute('required');
                installmentField.classList.add('hidden');
                maxInstallments.removeAttribute('required');
                // Sembunyikan due date
                dueDateField.classList.add('hidden');
                dueDateInput.removeAttribute('required');
                dueDateInput.value = '';
            }
        }

        function calculateOutstanding() {
            const total = parseFloat(document.getElementById('total-amount').value) || 0;
            const dp = parseFloat(document.getElementById('dp-amount').value) || 0;
            const outstanding = total - dp;
            document.getElementById('outstanding-amount').value = outstanding.toFixed(2);
        }

        // Reset the input form back to add-mode (called when closing form)
        // Reset form ke default add-mode
        function resetTransactionForm() {
            const form = document.querySelector('#inputForm form');
            if (!form) return;

            // Clear hidden edit inputs
            const actionInput = form.querySelector('input[name="action"][value="edit_transaction"]');
            if (actionInput) actionInput.remove();
            const idInput = form.querySelector('input[name="id"]');
            if (idInput) idInput.remove();

            // Reset form action
            form.action = '';

            // Reset visible fields to defaults
            form.querySelector('input[name="transaction_date"]').value = new Date().toISOString().slice(0,10);
            form.querySelector('select[name="transaction_type"]').value = 'masuk';
            updateCategories();
            // Pastikan kategori memilih opsi pertama dari hasil populate
            const categoryEl = form.querySelector('select[name="category"]');
            if (categoryEl && categoryEl.options.length > 0) {
                categoryEl.selectedIndex = 0;
            }
            form.querySelector('textarea[name="description"]').value = '';
            form.querySelector('select[name="payment_method"]').value = 'tunai';

            const amountTunai = document.getElementById('amount-tunai'); if (amountTunai) amountTunai.value = '';
            const total = document.getElementById('total-amount'); if (total) total.value = '';
            const dp = document.getElementById('dp-amount'); if (dp) dp.value = '';
            const outstanding = document.getElementById('outstanding-amount'); if (outstanding) outstanding.value = '';
            const maxInst = document.getElementById('max-installments'); if (maxInst) maxInst.value = '1';
            const supplier = document.getElementById('supplier-input'); if (supplier) supplier.value = '';
            const customer = document.getElementById('customer-input'); if (customer) customer.value = '';
            const custAddrInput = document.getElementById('customer-address-input'); if (custAddrInput) custAddrInput.value = '';
            // reset due date
            const dueDateInput = document.getElementById('due-date'); if (dueDateInput) dueDateInput.value = '';

            // Pastikan UI kembali ke keadaan default (tunai)
            togglePaymentFields();
        }

        // Open the dedicated Edit & Resubmit modal for returned transactions
        function showEditModalCashflow(transaction) {
            try {
                document.getElementById('edit_cashflow_id').value = transaction.id;
                document.getElementById('edit_transaction_date').value = transaction.transaction_date || '';
                document.getElementById('edit_amount').value = transaction.amount || '';
                document.getElementById('edit_cashflow_description').value = transaction.description || '';
                document.getElementById('edit_cashflow_return_reason').textContent = transaction.notes || transaction.rejection_reason || 'Tidak ada alasan';
                document.getElementById('editModalCashflow').classList.remove('hidden');
                // focus first field
                document.getElementById('edit_transaction_date').focus();
            } catch (e) {
                console.error('Gagal membuka modal edit:', e);
            }
        }
    </script>
    
    <!-- Edit Modal for Returned Cashflow -->
    <div id="editModalCashflow" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
        <div class="relative top-10 mx-auto p-5 border w-full max-w-2xl shadow-lg rounded-md bg-white">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">Edit & Resubmit Transaksi</h3>
            <form method="POST" action="handlers/approve_handler.php">
                <input type="hidden" name="action" value="resubmit">
                <input type="hidden" name="type" value="transaction">
                <input type="hidden" name="redirect" value="cashflow.php">
                <input type="hidden" name="id" id="edit_cashflow_id">
                
                <div class="mb-4 p-3 bg-yellow-50 border border-yellow-200 rounded">
                    <p class="text-sm font-medium text-yellow-800">ðŸ“ Alasan Pengembalian:</p>
                    <p class="text-sm text-yellow-700 mt-1" id="edit_cashflow_return_reason"></p>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Tanggal Transaksi <span class="text-red-500">*</span></label>
                        <input type="date" name="transaction_date" id="edit_transaction_date" required
                               class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Nominal <span class="text-red-500">*</span></label>
                        <input type="number" name="amount" id="edit_amount" required step="1" min="0"
                               class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500">
                    </div>
                    
                    <div class="md:col-span-2">
                        <label class="block text-sm font-medium text-gray-700 mb-1">Deskripsi <span class="text-red-500">*</span></label>
                        <textarea name="description" id="edit_cashflow_description" required rows="3"
                                  class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"></textarea>
                    </div>
                </div>
                
                <div class="mt-4 flex justify-end gap-2">
                    <button type="button" onclick="closeEditModalCashflow()" 
                            class="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300">
                        Batal
                    </button>
                    <button type="submit" 
                            class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
                        ðŸ’¾ Simpan & Kirim Ulang
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Return Modal for Cashflow -->
    <div id="returnModalCashflow" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
        <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">Return untuk Revisi</h3>
            <form method="POST" action="handlers/approve_handler.php">
                <input type="hidden" name="action" value="return">
                <input type="hidden" name="type" value="transaction">
                <input type="hidden" name="redirect" value="cashflow.php">
                <input type="hidden" name="id" id="return_cashflow_id">
                
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Alasan Pengembalian <span class="text-red-500">*</span>
                    </label>
                    <textarea name="reason" required minlength="10" rows="4"
                              class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-yellow-500"
                              placeholder="Jelaskan apa yang perlu diperbaiki (min. 10 karakter)"></textarea>
                    <p class="text-xs text-gray-500 mt-1">Transaksi akan dikembalikan ke staff untuk diedit</p>
                </div>
                
                <div class="flex justify-end gap-2">
                    <button type="button" onclick="closeReturnModalCashflow()" 
                            class="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300">
                        Batal
                    </button>
                    <button type="submit" 
                            class="px-4 py-2 bg-yellow-600 text-white rounded-md hover:bg-yellow-700">
                        ðŸ”„ Return
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Reject Modal for Cashflow -->
    <div id="rejectModalCashflow" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
        <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">Reject Transaksi</h3>
            <form method="POST" action="handlers/approve_handler.php">
                <input type="hidden" name="action" value="reject">
                <input type="hidden" name="type" value="transaction">
                <input type="hidden" name="redirect" value="cashflow.php">
                <input type="hidden" name="id" id="reject_cashflow_id">
                
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Alasan Penolakan <span class="text-red-500">*</span>
                    </label>
                    <textarea name="reason" required minlength="10" rows="4"
                              class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-red-500"
                              placeholder="Jelaskan alasan penolakan (min. 10 karakter)"></textarea>
                    <p class="text-xs text-red-500 mt-1">Transaksi yang ditolak tidak dapat diedit lagi</p>
                </div>
                
                <div class="flex justify-end gap-2">
                    <button type="button" onclick="closeRejectModalCashflow()" 
                            class="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300">
                        Batal
                    </button>
                    <button type="submit" 
                            class="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700">
                        âœ• Reject
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function showReturnModalCashflow(id) {
            document.getElementById('return_cashflow_id').value = id;
            document.getElementById('returnModalCashflow').classList.remove('hidden');
        }
        function closeReturnModalCashflow() {
            document.getElementById('returnModalCashflow').classList.add('hidden');
        }
        function showRejectModalCashflow(id) {
            document.getElementById('reject_cashflow_id').value = id;
            document.getElementById('rejectModalCashflow').classList.remove('hidden');
        }
        function closeRejectModalCashflow() {
            document.getElementById('rejectModalCashflow').classList.add('hidden');
        }
        function closeEditModalCashflow() {
            document.getElementById('editModalCashflow').classList.add('hidden');
        }
    </script>