<?php
require_once __DIR__ . '/includes/config.php';
checkLogin();
if (isAdmin()) {
    $_SESSION['error'] = 'Admin tidak memiliki akses ke halaman ini.';
    header('Location: manage_users.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Keuangan dan Transaksi - Sistem Informasi Akuntansi</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <?php include __DIR__ . '/includes/header.php'; ?>
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-6">
        <div class="mb-6 flex items-center justify-between">
            <h2 class="text-2xl font-bold text-gray-800">Keuangan dan Transaksi</h2>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <?php if (checkPermission('cashflow', 'view')): ?>
            <div class="bg-white rounded-lg shadow hover:shadow-md transition p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-2">Cashflow</h3>
                <p class="text-sm text-gray-600 mb-4">Kelola arus kas masuk/keluar.</p>
                <a href="cashflow.php" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Buka</a>
            </div>
            <?php endif; ?>

            <?php if (checkPermission('receivables', 'view')): ?>
            <div class="bg-white rounded-lg shadow hover:shadow-md transition p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-2">Piutang</h3>
                <p class="text-sm text-gray-600 mb-4">Pencatatan dan pembayaran piutang.</p>
                <a href="receivables.php" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Buka</a>
            </div>
            <?php endif; ?>

            <?php if (checkPermission('payables', 'view')): ?>
            <div class="bg-white rounded-lg shadow hover:shadow-md transition p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-2">Hutang</h3>
                <p class="text-sm text-gray-600 mb-4">Pencatatan dan pembayaran hutang.</p>
                <a href="payables.php" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Buka</a>
            </div>
            <?php endif; ?>

            <?php if (checkPermission('assets', 'view')): ?>
            <div class="bg-white rounded-lg shadow hover:shadow-md transition p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-2">Aset</h3>
                <p class="text-sm text-gray-600 mb-4">Pengelolaan aset dan perolehan.</p>
                <a href="assets.php" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Buka</a>
            </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>